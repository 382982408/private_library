
final variants files:
1)somatic.filter.final.variants.rp: final variants with mechanism prediction and allele frequency. You should know that different events may have different headers.
	1.1)Format for final variants of different events:
		del, mechanism, cluster id, number of supporting read pairs, number of supporting split reads,chr, range of deletion (2 col), deletion size, homology sizes, annotation of break points
		del_ins, mechanism, cluster id, number of supporting read pairs, number of supporting split reads, chr, range of deletion (2 col), deletion size, chr (donor), range of insertion (2 col), insert size,annotation of break points
		del_inss/o*, mechanism, cluster id, number of supporting read pairs, number of supporting split reads, chr, range of deletion (2 col), deletion size, chr (donor), range of insertion (2 col), insert size, distance of deletion and insertion, homology at break points, annotation of break points
		del_invers, mechanism, cluster id, number of supporting read pairs, number of supporting split reads, chr, range of deletion (2 col), deletion size, chr (donor), range of inversion (2 col), inversion size, distance of inverstion and deletion (2 col), homology at break points, annotation of break points
		inss/o*, mechanism, cluster id, number of supporting read pairs, number of supporting split reads, chr, range of deletion (2 col), deletion size, rchr (donor), ange of insertion (2 col), insert size,distance of deletion and insertion, homology at break points, annotation of break points
		invers, mechanism, cluster id, number of supporting read pairs, number of supporting split reads, chr, inversion left boundary, inversion right boundary, inversion size, homology at break points, annotation of break points
		invers_*, mechanism, cluster id, number of supporting read pairs, number of supporting split reads, chr, inversion left boundary, inversion right boundary, inversion size, homology at break points,annotation of break points
		tandem_dup, mechanism, cluster id, number of supporting read pairs, number of supporting split reads, chr, tandem duplication boundary 1, tandem duplication boundary 2, tandem duplication size, homology at break points, annotation of break points
		del_inss/o, mechanism, cluster id, number of supporting read pairs, number of supporting split reads, chr, range of deletion (2 col), deletion size, chr of insertion donor, range of insertion (2 col),insert size, homology at break points, annotation of break points
		inss/o, mechanism, cluster id, number of supporting read pairs, number of supporting split reads, chr, range of insert site, insert site size, chr of insertion donor, range of insertion (2 col), insert size, homology at break points, annotation of break points
		transl_inter, mechanism, cluster id, number of supporting read pairs, number of supporting split reads, chr of 1st cluster, boundary of 1st cluster, orientation of 1st cluster, chr of 2nd cluster, boundary of 2nd cluster, orientation of 2nd cluster, homology at break points, annotation of break points
	1.2)Event types:
		del: simple deletion, no insertion at break point.
		del_ins: deletion with insertion at the break point with unknown source.
		del_inssd: deletion with insertion at the break point, insertion comes from the same chromosome, same orientation and downstream of deletion.
		del_inssu: deletion with insertion at the break point, insertion comes from the same chromosome, same orientation and upstream of deletion.
		del_insod: deletion with insertion at the break point, insertion comes from the same chromosome, opposite orientation and downstream of deletion.
		del_insou: deletion with insertion at the break point, insertion comes from the same chromosome, opposite orientation and upstream of deletion.
		del_inss: deletion with insertion at the break point, insertion comes from a different chromosome, same orientation.
		del_inso: deletion with insertion at the break point, insertion comes from a different chromosome, opposite orientation.
		del_invers: deletion with inversion at the break point, inversion comes from deleted part.
		inssd: insertion, insertion comes from the same chromosome, same orientation and downstream of deletion.
		inssu: insertion, insertion comes from the same chromosome, same orientation and upstream of deletion.
		insod: insertion, insertion comes from the same chromosome, opposite orientation and downstream of deletion.
		insou: insertion, insertion comes from the same chromosome, opposite orientation and upstream of deletion.
		inss: insertion, insertion comes from a different chromosome, same orientation.
		inso: insertion, insertion comes from a different chromosome, opposite orientation.
		invers: inversion with reciprocal discordant read pair cluster support
		invers_f: unpaired cluster, both end of read pairs mapped to same chromosome, both on forward strand.
		invers_r: unpaired cluster, both end of read pairs mapped to same chromosome, both on reverse strand.
		tandem_dup: tandem duplication.
		transl_inter: inter chromosomal translocation.
	1.3)Types of mechanisms:
		TEI: transposable element insertion, single or multiple TE insertion.
		TEA: Alternative TE, usually a deletion with insertion event is called, deletion is a TE in reference genome and insertion is the same type of TE in reference genome. It should be arisen from sequence divergence of TE.
		VNTR: variable number of tandem repeat, deletion or insertion of satellite repeat, simple repeat or low complexity repeat.
		NAHR: non-allellic homologous recombination, >100bp homology.
		alt-EJ: alternative end joining, 3-100bp homology.
		NHEJ: non-homologous end joining, 0-2bp homology or 1-10bp insertion at deletion breakpoint.
		FoSTeS: fork stalling and template switching, template switch, >10bp insertion at deletion break points.
		NA: unclassified.
	1.4)Each event is given an RP tag with 4 numbers in A_B_C_D format.
		A: number of full length discordant read pairs
		B: number of discordant read pairs from partially mapped reads (clipped reads)
		C: number of concordant read pairs at the first breakpoint
		D: number of concordant read pairs at the second breakpoint
		The number of A+B should be equal to the total number of discordant read pairs given by Meerkat.
		for example: RP:16__29_30,the allele fraction for this event is about 0.35.
		
2)somatic.filter.final.variants.vcf:
	final variants in VCF format.
	

