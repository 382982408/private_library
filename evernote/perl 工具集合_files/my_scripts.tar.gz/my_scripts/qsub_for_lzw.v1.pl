#!/usr/bin/perl -w

=head1 Name

  qsub-sge.pl -- control processes running on linux SGE system

=head1 Usage
  
  perl qsub-sge.pl
  --queue		<essential>:Specify the work queue! <example:sge01>
  --node		<essential>:Specify the work node!  <example:node-0-09>
  --wait		<unessential>:Specify the task delivery interval! <default:30>
  --interval	 	<unessential>:Specify the task check interval! <default:30>
  --maxproc		<unessential>:Set the maximum number of process! <default:20>
  --reqsub		<unessential>:Wehther to reqsub the unfinished jobs untill they are finished? <default:no>
  --resource		<unessential>:Set the required resource used in qsub -l option! <default:vf=3.0G>
  --independent		<unessential>:Wehther to contain other qsub tasks when set the max number of process? <default:no>
  --Check		<unessential>:Wehther to check last qsub uncomplete to continue? <default:yes> 
  --help		<unessential>:help
=cut

use strict;
use Getopt::Long;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname); 
use Data::Dumper;
use lib "$Bin/../pipeline/models/";
use standard_family;
use exon;
################
my $CONF_file="$Bin/../db/Z_lzw_database/CONFIG_ALL.txt";
my %parameters;
&exon::initialize($CONF_file,\%parameters);

############
##get options from command line into variables and set default values
my ($Queue, $Interval,$wait,$Maxjob, $Maxproc,$Secure,$Reqsub,$Resource,$Independent,$check,$node,$Help);
GetOptions(
	"maxproc:i"=>\$Maxproc,
	"interval:i"=>\$Interval,
	"wait:s"=>\$wait,
	"queue:s"=>\$Queue,
	"node:s"=>\$node,
	"reqsub:s"=>\$Reqsub,
	"resource:s"=>\$Resource,
	"independent:s"=>\$Independent,
	"Check=s"=>\$check,
	"help"=>\$Help
);
$Interval ||= 30;
$wait ||= 30;
$Maxproc ||=20;
$Resource ||= "mf=3.0G";
$check ||="yes";
$Independent ||="no";
$Reqsub ||="no";

my $work_shell_file=shift;

die `pod2text $0` if ($Help || (!defined $Queue && !defined $node) || !defined $work_shell_file);

####################################################
##########################################################
$work_shell_file=`readlink -f $work_shell_file`;
chomp $work_shell_file;

&work_check($work_shell_file,$Queue,$node);
############################################

my $Work_dir = $work_shell_file.".qsub";
my $work_shell_file_error=$work_shell_file.".error";

my $work_shell_file_name=basename($work_shell_file);
if ($work_shell_file_name=~m/^\d+/)
{
	print "The shell file name can not begin with a number !\n";
	exit;
};
$work_shell_file_name=~s/\.sh$//;

my $qstatname=$work_shell_file_name; ##add independent by heh 2012-5-16
$qstatname=substr($work_shell_file_name,0,10) if(length$qstatname>10);

my $current_dir=`pwd`;
chomp $current_dir;
my @Shell;

if(($check eq "no") && (-d $Work_dir))
{
	print STDOUT "jobs maybe running !!!!\n";
	exit;
}elsif(($check eq "yes") && (-d $Work_dir))
{
	my @old_shell=glob("$Work_dir/*.sh");
	foreach my $old_shell (sort @old_shell)
	{
				next if (-f "$old_shell.Check");
				push @Shell,$old_shell;
	};
	print "Check last time qsub have ",scalar@Shell," shell uncomplete.\n";
	print "That will continue the uncomplete jobs.\n";
}else
{
	my $Job_mark="00001";
	`mkdir -p $Work_dir` if(!-d $Work_dir);

	open IN, $work_shell_file || die "fail open $work_shell_file";
	while(<IN>)
	{
		chomp;
		next unless($_!~/^$/);

		my $jobsh="$Work_dir/$work_shell_file_name\_$Job_mark.sh";
		push @Shell,"$jobsh";

		open OUT,">$jobsh" || die "\n\tfailed creat $jobsh \n\n";
		print OUT $_." && echo This-Work-is-Completed! >$jobsh.Check\n";
		close OUT;
		$Job_mark++;
	};
	close IN;
	print STDOUT "make the qsub shell files done\n";
};

## run jobs by qsub, until all the jobs are really finished
my $qsub_cycle = 1;
while (@Shell>0)
{

	my %Alljob; ## store all the job IDs of this cycle
	my %Runjob; ## store the real running job IDs of this cycle

	$Resource=~m/mf=(.+)G/;
	my $job_cmd = "qsub -cwd -S /bin/bash  ";  ## -l h_vmem=16G,s_core=8 
	$job_cmd .= "-l $Resource" ; ##set resource
	if (defined $node)
	{
		$job_cmd .=",h=$node";
	}elsif(defined $Queue)
	{
		$job_cmd .=",q=$Queue";
	};

	my $task=0;
	for (my $i=0; $i<@Shell; $i++) 
	{
		while (1) 
		{
			if (&queueJob() < $Maxproc)
			{
				if ($wait>0 && $task>0)
				{
					sleep $wait;
				};

				my $running_check=&running_check("prod",$Shell[$i]);

				if($running_check=~/yes/)
				{
					print STDOUT "job $Shell[$i] is running yet !!!\n";
				}else
				{
					my @error_file=glob("$Shell[$i].{e,o}*");
					`rm @error_file ` if(@error_file>0);

					chdir($Work_dir);
					my $jod_return = `$job_cmd $Shell[$i]`;
					print STDOUT "$job_cmd $Shell[$i] \n";
					my $job_id = $1 if($jod_return =~ /Your job (\d+)/);
					$Alljob{$job_id} = $Shell[$i];  ## job id => shell file name
					print STDOUT "throw job $job_id in the $qsub_cycle cycle\n";
				};
				
				$task++;
				last;
			}else
			{
				print STDOUT "wait for throwing next job in the $qsub_cycle cycle\n";
				sleep $Interval;
			};
		};
	};

	###waiting for all jobs fininshed
	while (1)
	{
		my $run_num = run_count(\%Alljob,\%Runjob);	
		last if($run_num == 0);;
		sleep $Interval;
	};

	print STDOUT "All jobs finished, in the firt cycle in the $qsub_cycle cycle\n";


	##run the secure mechanism to make sure all the jobs are really completed
	open OUT, ">>$work_shell_file_error" || die "fail create $$work_shell_file_error";
	my @Error;
	foreach my $job_id (sort keys %Alljob)
	{
		my $shell_file = $Alljob{$job_id};
		##check whether the job has been killed during running time
		if (!-f "$shell_file\.Check")
		{
			print OUT "In qsub cycle $qsub_cycle, $shell_file may be unfinished\n";
			push @Error,$shell_file;
		};
	};

	if($qsub_cycle > 5)
	{
		print OUT "\n\nProgram stopped because the reqsub cycle number has reached 5, the following jobs unfinished:\n";
		print OUT (join "\n",@Error)."\n";
		print OUT "Please check carefully for what errors happen, and redo the work, good luck!";
		die "\nProgram stopped because the reqsub cycle number has reached 5\n";
	};

	close OUT;

	@Shell = @Error;
	$qsub_cycle++;

	chdir($current_dir); ##return into original directory 

	last unless($Reqsub=~/yes/);
};

print STDOUT "\nqsub-sge.pl finished\n";


####################################################
################### Sub Routines ###################
####################################################
sub running_check	##("prod","$Shell[$i]");
{
	my ($account,$worksh)=@_;
	sleep 5;
	my $info=`qstat -u $account|grep $account`;
	my @jobs=split /\n/,$info;
	my %RUNNING;
	foreach (@jobs)
	{
		my @arr=split /\s+/,$_;
		my @detail=split /\n/,`qstat -j $arr[1]`;
		my $run_shell;
		foreach my $aa(@detail)
		{
			my @AA=split /\s+/,$aa;
			if($aa=~/^cwd/)
			{
				$run_shell=$AA[-1];
			}elsif($aa=~/^job_name/)
			{
				$run_shell.="/$AA[-1]";
			};
		};
#					####edit by wang 20180328
#		if(!-f $run_shell)
#		{
#			`qdel $arr[1]`;
#		}else
#		{
#			$RUNNING{$run_shell}=1;
#		};
#	
		$RUNNING{$run_shell}=1;
	};
	if(exists $RUNNING{$worksh})
	{
		return "yes";
	}else
	{
		return "no";
	};
};
########################################################
sub run_count {
	my $all_p = shift;
	my $run_p = shift;
	my $run_num = 0;

	%$run_p = ();
	my $user = `whoami`; chomp $user;
	my @jobs = split /\n/,`qstat -u $user`;
	foreach my $job_line (@jobs)
	{
		$job_line =~s/^\s+//;
		next if($job_line!~/^\d+/);
		my @job_field = split /\s+/,$job_line;
		next if($job_field[3] ne $user);
		if (exists $all_p->{$job_field[0]})
		{
			my %died;
			died_nodes(\%died);
			my $node_name = "NA";
			if($job_field[7] =~ /.*?\@(.*?)/)
			{
				$node_name = $1 ;
			};

			if (exists $died{$node_name})
			{
				`qdel $job_field[0]`;
			}else{
				$run_p->{$job_field[0]} = $job_field[2];
				$run_num++;
			};
		};
	};
	return $run_num; ##qstat����еĴ�����������״̬�����񣬲�������Щ��������ڵ��ϵĽ�ʬ����
}

##############################################################
sub queueJob
{
	my $user = `whoami`;
	chomp $user;
	my @jobs = split("\n", `qstat -u $user`);

	my $jobnum = @jobs-2;
	if(defined $Independent)
	{
		my $jobs=0;
		for (my $i=2;$i<@jobs ;$i++)
		{
			$jobs[$i]=~s/^\s+//;
			my ($jobid,$jobname,$state)=(split/\s+/,$jobs[$i])[0,2,4];
			if($state eq "Eqw")
			{
				`qdel $jobid ` ;
				next;
			};
			$jobs++ if($jobname=~m/^$qstatname/);
		};
		$jobnum=$jobs;
	};
	return $jobnum;
};
#########################################################
sub died_nodes
{
	my $died_p = shift;

	my @lines = split /\n/,`qhost`;
	shift @lines; shift @lines; shift @lines;  ##remove the first three title lines
	foreach  (@lines)
	{
		my @t = split /\s+/;
		my $node_name = $t[0];
		my $memory_use = $t[5];
		$died_p->{$node_name} = 1 if($memory_use eq '-');
	};
};
#######################################
sub work_check         ##############edit by wang---20180327
{
	my($ID,$Queue,$node)=@_;
	my $ID_dir;
	if (!defined $node)
	{
		$node="NA";
	};
	return "no_check";
	if($ID=~/share\/(.*?)\//)
	{
		$ID_dir=$1;
	}else
	{
		print STDERR "error:data dir is wrong !!!\n";
		die;
	};
	if (exists $parameters{$ID_dir})
	{
		if ($parameters{$ID_dir} eq $Queue)
		{

		}else
		{
			print STDERR "\n\tplease check your work queue and the data dir !\n$ID\n$Queue\n";
			die;
		};
	}else
	{
		print STDERR "\n\tplease check your data dir:$ID!!!\n\n";
		die;
	};
};
#########################################################
