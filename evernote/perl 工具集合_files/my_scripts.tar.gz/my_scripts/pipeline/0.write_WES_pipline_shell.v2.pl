#!/usr/bin/perl -w
use strict;
use File::Basename;
use Getopt::Long;
use FindBin qw($Bin $Script);
use Data::Dumper;
use lib "$Bin/models/";
use standard_family;
use exon;
######################################################
my($conf_file,$output_dir,$only);
my $step=1;
my $link="no";	############不链接
my $del_clean_data="no";	###########不删除
my $sp_od="no";
my $cov="yes";
my $data_conf="NA";
GetOptions
(
	"conf=s"		=> \$conf_file,
	"od=s"			=> \$output_dir,
	"sd=s"			=> \$sp_od,
	"step=s"		=> \$step,
	"link=s"		=> \$link,
	"del=s"			=> \$del_clean_data,
	"cov=s"			=>\$cov,
	"data_conf=s"	=>\$data_conf
);
my $usage="
	perl $0
	-conf		config_file:force
	-data_conf	raw_data_conf_file
	-od		output_dir:force
	-sd		is directory private ???(default:no)
	-link		link to \"/share/ofs1a/prod/sample/\" ? (default:no)
	-del		delete the clean data ? (default:no|yes|predell)
	-cov		wheather to cover the handle info ?
	-step		step_of_pipline (default:1)
			1:	start_from_raw_data
			2:	start_from_clean_data	
			3:	start_from_stat
			4:	start_from_bam
			5:	start_from_vcf
			6:	start_from_qc
";
if(!defined $conf_file or !defined $output_dir)
{
	print STDERR "$usage\n";
	exit;
};

`mkdir -p $output_dir ` if(!-d $output_dir);
$output_dir=&exon::path($output_dir);

my $time=&datetime;
print "\tproject directory:\t$output_dir\t\t$time\n";

####################################################################
if ($step!~/^\d+$/)
{
	$step=~s/\D+//g;
	$only="yes";
};

my %parameters;
$conf_file=&exon::path($conf_file);
&exon::get_parameters($conf_file,\%parameters);

my $file="$Bin/../db/Z_lzw_database/CONFIG_ALL.txt";
&exon::initialize($file,\%parameters);

my $sam_batch_dir=$parameters{D30};
my $sam_dir=$parameters{D52};
my $handlefile=$parameters{D70};
if ($data_conf=~/\//)
{
	$parameters{D28}=$data_conf;
	print "$parameters{D28}\n";
};
my $all_raw=$parameters{D28};
######################
my @config_recheck=split /\_/,$parameters{sample_id};
if (@config_recheck!=3)
{
	my @tmp=split /\s+/,`grep $config_recheck[0] $all_raw|grep $config_recheck[1]|tail -1`;
	$parameters{'sample_id'}=join "_",$tmp[1],$tmp[2],$tmp[3];
};

my $write_anno_pl="$Bin/3.1_anno_from_vcf.v1.pl";

####################################################################
=cut
DIR1    acmg2.0_Shell
DIR2    acmg2.0_STDOUT
DIR3    acmg2.0_STDERR

DIR4    1.2_Merged_bam
DIR5    2.1_map_stat
DIR6    2.2_rmdup_map_stat
DIR7    2.3_function_region_map_stat

DIR8    acmg2.0_3.1_variation_calling
DIR9    acmg2.0_3.2_variation_annotation
DIR10   acmg2.0_3.3_variation_classfication
DIR11   acmg2.0_3.4_variation_stat

DIR12   acmg2.0_4.1_QC
DIR13   5.1_CNV
DIR14   5.3_Batch_EXON_deletion

DIR15   acmg2.0_6.0_other_detected_result
DIR16   acmg2.0_6.1_report

DIR17	5.1_Batch_GENE_deletion
DIR18	5.2_Control_GENE_deletion
DIR19	5.4_SameBatch_EXON_deletion
=cut
##########################################################
my $shell_dir="$output_dir/$parameters{DIR1}";
my $stdout_dir="$output_dir/$parameters{DIR2}";
my $stderr_dir="$output_dir/$parameters{DIR3}";

my $bam_dir="$output_dir/$parameters{DIR4}";
my $stat1_dir="$output_dir/$parameters{DIR5}";
my $stat2_dir="$output_dir/$parameters{DIR6}";
my $stat3_dir="$output_dir/$parameters{DIR7}";

my $call_dir="$output_dir/$parameters{DIR8}";
my $anno_dir="$output_dir/$parameters{DIR9}";
my $result_dir="$output_dir/$parameters{DIR10}";
my $stat_dir="$output_dir/$parameters{DIR11}";

my $qc_dir="$output_dir/$parameters{DIR12}";
my $cnv_dir="$output_dir/$parameters{DIR13}";
my $exon_dir="$output_dir/$parameters{DIR14}";

my $other_info_dir="$output_dir/$parameters{DIR15}";
my $report_dir="$output_dir/$parameters{DIR16}";

my $exon_5_1="$output_dir/$parameters{DIR17}";
my $exon_5_2="$output_dir/$parameters{DIR18}";
my $exon_5_4="$output_dir/$parameters{DIR19}";

system "mkdir -p $shell_dir" if (!-d $shell_dir);	#######最原始的目录结构只有此三个文件目录，以下是正文环节
system "mkdir -p $stdout_dir" if (!-d $stdout_dir);
system "mkdir -p $stderr_dir" if (!-d $stderr_dir);
##################################################################################################################################################
my($sample_name,$program,$cap_bed)=split /\_/,$parameters{'sample_id'};
my $sample_ID=(split /xb|sl|zj|xj|_|\s+/,$sample_name)[0];

if (!defined $parameters{DD_number})
{
	$parameters{DD_number}=$sample_ID;
};
#################################################################################################################################################
if ($cov=~/yes/)
{
	`perl $parameters{T1}/Bin/get_handle.v1.pl $sample_ID $parameters{D92} $output_dir $cov`;
}elsif(!-f "$output_dir/$sample_ID\_handle.txt" || (stat "$output_dir/$sample_ID\_handle.txt")[7]==0)
{
	#`perl $parameters{T1}/Bin/get_handle.v1.pl $sample_ID $output_dir $cov`;
	if (!-f "$output_dir/$sample_ID\_handle.txt" || (`file $output_dir/$sample_ID\_handle.txt` =~/empty/))
	{
		`echo $sample_name > $output_dir/$sample_ID\_handle.txt`;
	};
};

my $prog_type="1:单报告先证者";		#########单报告
my $xzz_num=$sample_ID;
my $xzz_dir=$output_dir;
my $DD_number=$parameters{DD_number};

my $report_proband_txt="$report_dir/report_proband/$DD_number\_$program\_b$parameters{'batch'}A\_Poly_acmg2.0.txt";
my $report_proband_name="$report_dir/report_proband/$DD_number\_$program\_b$parameters{'batch'}A\_Poly_acmg2.0.xlsx";
my $report_proband_qc="$report_dir/report_proband/$DD_number\_$program\_b$parameters{'batch'}A\_Poly_qc.txt";
my ($report_fam_txt,$report_fam_qc,$report_fam_name)=("$report_dir/report_fam/$DD_number\_fam_report.txt","$report_dir/report_fam/$DD_number\_fam_qc.txt","$report_dir/report_fam/$DD_number\_fam_report.xlsx");

if (`cat $output_dir/$sample_ID\_handle.txt`=~/先证者/)
{
	$xzz_num=`grep 先证者 $output_dir/$sample_ID\_handle.txt|head -1|cut -f 1`;
	chomp $xzz_num;
	$xzz_num=(split /xb|sl|zj|xj|_|\s+/,$xzz_num)[0];
	if ($xzz_num ne $sample_ID)
	{
		$xzz_dir=&exon::find_var_dir($sam_dir,$xzz_num,$program);
	};
}elsif(`cat $output_dir/$sample_ID\_handle.txt|wc -l` ==1)
{
	$xzz_num=$sample_ID;
	print STDOUT "\nerror:please check the file:$output_dir/$sample_ID\_handle.txt\n\n";
	##########只有一个样本的时候，默认为先证者
}else
{
	$xzz_num=$sample_ID;
	print STDERR "\nerror:please check the fam_relation file:$output_dir/$sample_ID\_handle.txt !!!\n\n";#########handel文件有问题，先继续跑任务
};

my (%relation);
&exon::read_sinfo("$output_dir/$sample_ID\_handle.txt",\%relation);
my @fam_names=sort keys %relation;
unshift @fam_names,$xzz_num;
for (my $i=0;$i< @fam_names;$i++)
{
	($fam_names[$i])=split /xb|sl|zj|xj|_|\s+/,$fam_names[$i];
};
@fam_names=&exon::get_uniq(@fam_names);
my @sample_dir=&exon::find_arr_dir($sam_dir,\@fam_names,$program);
my $sample_dir=join " ",@sample_dir;

my @other_dir=grep $_!~/$xzz_num/,@sample_dir;
##################################################
if ($program=~/NQB2|NQB3|N2Qe/)
{
	$prog_type="1:单报告先证者:NQB2|NQB3|N2Qe";		#########NQB2|NQB3
}elsif($program=~/F$/ && @fam_names>1)
{
	my %fam_relation;
	&exon::read_hash("$output_dir/$sample_ID\_handle.txt",\%fam_relation,"11,1",0,2);
	($report_fam_txt,$report_fam_name)=&exon::get_outname("$report_dir/report_fam/",\@fam_names,\%fam_relation,$program,$DD_number,$all_raw);
	$report_fam_qc=$report_fam_txt;
	$report_fam_qc=~s/acmg2\.0\.txt/qc\.txt/g;
	if ($xzz_num eq $sample_ID)
	{
		 $prog_type="2:家系报告先证者";		#########家系报告先证者
	}else
	{
		 $prog_type="3:家系报告亲属";		#########家系报告亲属
	};
}elsif($program=~/F$/ && @fam_names==1)
{
	$xzz_dir="err";
	$prog_type="3:家系报告亲属";		#########家系关系文档有问题，跑出g.vcf就行了
	print STDERR "error:handle.txt file is error !!!\n";
}elsif($program!~/F$/ && @fam_names==1)
{
	##########all is ok
}else
{
	print STDERR "error:handle.txt file is error !!!\n";
};

my $sge_only=&exon::dir_sge_check(@sample_dir);

print STDOUT "prog_type:\t$prog_type\t$parameters{sample_id}\nsge:\t\tall samples in single one sge($sge_only)\n";

##################################################################################################################################################
my $run_sh="#!/bin/bash\n";					########$shell_dir/run.sh
my $bwa_sh="#!/bin/bash\n";					########$shell_dir/1.1_get.merge.bam.sh
my $stat_1_sh="#!/bin/bash\n";
my $stat_2_sh="#!/bin/bash\n";
my $stat_3_sh="#!/bin/bash\n";
my $link_sh="#!/bin/bash\n";
my $qc_sh="#!/bin/bash\n";
my $exon_sh="#!/bin/bash\n";
my $exon_run_sh="#!/bin/bash\n";
my $report_work_sh="#!/bin/bash\n";
my $report_fam_fresh_sh="#!/bin/bash\n";
my $report_proband_fresh_sh="#!/bin/bash\n";
my $report_prepare_sh="#!/bin/bash\n";
my $shell_fam_other="#!/bin/bash\n";
my $shell_fresh="#!/bin/bash\n";
##################################################################################################################################################

$run_sh="#!/bin/bash\n";
my $node;
if ($sp_od=~/yes/i)
{
}elsif((-f "$output_dir/LOG") && `grep $parameters{sge_key} $output_dir/LOG` && $step>=2)   ########edit by wang 20180327
{
	$node=`grep $parameters{sge_key} $output_dir/LOG |tail -1|cut -d ' ' -f 1`;
	chomp $node;
	$run_sh.= "ssh $node \'\n";
}elsif(-f "$output_dir/LOG")
{
#	`mv $output_dir/LOG $output_dir/LOG.bak`;
};

$run_sh.= "time=\$(date) && echo \t\t\$time ===================================================Pipeline_start >>$output_dir/LOG \n";
$run_sh.= "node=\$(hostname)&& echo \t\t\$node =================================================== work_in_node>>$output_dir/LOG \n";

my $FSD_DIR;
my $TMP_DIR;
if ($sp_od=~/yes/i)
{
	$FSD_DIR=$output_dir;
	$TMP_DIR=$output_dir;
}else
{
	$FSD_DIR="$parameters{D35}/b$parameters{batch}/$parameters{sample_id}";
	$TMP_DIR="$parameters{D51}/b$parameters{batch}/$parameters{sample_id}";
	$run_sh.= "if [ -d \"$TMP_DIR/$parameters{DIR4}\" ]\n\tthen rm -rf $TMP_DIR/$parameters{DIR4}\nfi\n \n";
	$run_sh.= "if [ -d \"$FSD_DIR/$parameters{DIR4}\" ]\n\tthen rm -rf $FSD_DIR/$parameters{DIR4}\nfi\n \n";

	$run_sh.= "mkdir -p $TMP_DIR/$parameters{DIR4} $FSD_DIR/$parameters{DIR4} \n";
};

print STDOUT "od:\t$output_dir\nfsd:\t$FSD_DIR\nrhd:\t$TMP_DIR\n";
##########################################################################################################
if($link ne "no")
{
	my $batch=$parameters{'batch'};
	{
		my $head=substr($sample_ID,0,((length$sample_ID)-3));
		my $dir_link_name=basename $output_dir;

		my $head_dir="$parameters{D52}/${head}000\-${head}999/";
		$link_sh= "if [ ! -d $head_dir ] \n\tthen mkdir -p $head_dir \nfi\n\n";

		$link_sh.= "rm $head_dir/$sample_name*$cap_bed*\n";
		$link_sh.= "ln -s $output_dir $head_dir/$dir_link_name\_b$batch \n";
		
		my $batch_dir="$parameters{D53}/b$batch/";
		$link_sh.= "if [ ! -d $batch_dir ] \n\tthen mkdir -p $batch_dir \nfi \n\n";

		$link_sh.= "rm $batch_dir/$sample_name*$cap_bed*\n";
		$link_sh.= "ln -s $output_dir $batch_dir/$dir_link_name\_b$batch \n\n";
	};

	{
		$link_sh.= "node_name=\$\(echo \$(hostname)|sed \'s/chigene2\-/cg-rhd/g\'\)\n";
		$link_sh.= "real_dir=\$(echo $TMP_DIR\|sed \'s/mnt\\\/rhd/share\\\/\'\$node_name\'/\')\n";

		my $head=substr($sample_ID,0,((length$sample_ID)-3));
		my $head_dir="$parameters{D54}/${head}000\-${head}999/";
		my $dir_link_name=basename $TMP_DIR;

		$link_sh.= "if [ ! -d $head_dir ] \n\tthen mkdir -p $head_dir \nfi\n";
		$link_sh.= "rm $head_dir/$sample_name*$cap_bed*\n";
		if($del_clean_data=~/predel/)
		{
			`rm -rf $head_dir/$sample_name*/* `;
		};
		$link_sh.= "ln -s \$real_dir $head_dir/$dir_link_name\_b$batch \n";
			my $batch_dir="$parameters{D55}/b$batch/";

			$link_sh.= "if [ ! -d $batch_dir ] \n\tthen mkdir -p $batch_dir \nfi \n";
		if($del_clean_data=~/predel/)
		{
			`rm -rf $head_dir/$sample_name*/* `;
			print STDOUT "clean_data_rm:\t$head_dir/$sample_name* !!!\n";
		};
		$link_sh.= "rm $batch_dir/$sample_name*$cap_bed*\n";
		$link_sh.= "ln -s \$real_dir $batch_dir/$dir_link_name\_b$batch \n";
	};
	$run_sh.= "\nsh $shell_dir/7.1_link.sh 1>$stdout_dir/7.1_link.sh.out 2>$stderr_dir/7.1_link.sh.err \n\n";
};
##########################################################
#print "\n\tfrom_step:$step \n";
my (@clean_1,@clean_2);
if ($step<=2)						##########step1 从比对到bam文件的获得
{
	$bwa_sh= "#!/bin/bash\n";
	$bwa_sh.= &exon::dir_bak("$bam_dir");
	$bwa_sh.= "time=\$(date) && echo \t\t\$time ===================================================1.0_raw_fq_data_filter >>$output_dir/LOG \n";
	if (exists $parameters{'fq1'} && exists $parameters{'fq2'})
	{
		my @fq1_files=split /\s+/,$parameters{'fq1'};
		my @fq2_files=split /\s+/,$parameters{'fq2'};
		if(@fq1_files!=@fq2_files)
		{
			print STDERR "The numbers of fastq1 and fastq2 are not equal!\n";
			exit;
		};
		for(my $i=0;$i<@fq1_files;$i++)
		{
			my $fq1_name=basename$fq1_files[$i];
			my $fq2_name=basename$fq2_files[$i];

			`ln -s $fq1_files[$i] $output_dir` if(!-f "$output_dir/$fq1_name");
			`ln -s $fq2_files[$i] $output_dir` if(!-f "$output_dir/$fq2_name");
	
#			print W "$parameters{S10} -r $fq1_files[$i] -p $fq2_files[$i] -a $parameters{D50} -ao 5 -t $TMP_DIR/clean_$i\_time -u 5 -q 20 -m 35 -f i1.8 -x 3 -z GZ > $TMP_DIR/log \n" if ($step<=1);
			if ($step<=1)
			{
				$bwa_sh.= "\n\nperl $parameters{T1}/Bin/memory_monitoring.v1.pl 4G  trimomatic\n";
				$bwa_sh.= "echo \"start_trimomatic !!!\"";
#				$bwa_sh.=&exon::sh_recheck("java -jar $parameters{S11} PE -phred33 -threads 4 $fq1_files[$i] $fq2_files[$i] $TMP_DIR/clean_$i\_time_1.fastq.gz $TMP_DIR/clean_$i\_time_1_unpaired.fastq.gz $TMP_DIR/clean_$i\_time_2.fastq.gz $TMP_DIR/clean_$i\_time_2_unpaired.fastq.gz ILLUMINACLIP:$parameters{D50}\:2:30:8:1:true TRAILING:20 HEADCROP:5 AVGQUAL:25 SLIDINGWINDOW:4:20 MINLEN:50 > $TMP_DIR/log","trimmomatic","2000");
#
				$bwa_sh.=&exon::sh_recheck("$parameters{S13} -i $fq1_files[$i] -I $fq2_files[$i] -o $TMP_DIR/clean_$i\_time_1.fastq.gz -O $TMP_DIR/clean_$i\_time_2.fastq.gz -f 5 -F 5 -3 -W 8 -M 25 -q 20 -u 25 -n 3 -l 50 -c -g --poly_g_min_len 6 -x -y -Y 20 -j $TMP_DIR/$sample_name\.json -h $TMP_DIR/$sample_name\.html --adapter_sequence GATCGGAAGAGCACACGTCTGAACTCCAGTCAC --adapter_sequence_r2 AGATCGGAAGAGCGTCGTGTAGGGAAAGAGTGT \> $TMP_DIR/fastp.log","fastq","2000");
			};

			push @clean_1,"$TMP_DIR/clean_$i\_time_1.fastq.gz";
			push @clean_2,"$TMP_DIR/clean_$i\_time_2.fastq.gz";
			$bwa_sh.= "hostname >> $output_dir/LOG && echo $TMP_DIR/clean_$i\_time_1.fastq.gz >>$output_dir/LOG \n";
			$bwa_sh.= "hostname >> $output_dir/LOG && echo $TMP_DIR/clean_$i\_time_2.fastq.gz >>$output_dir/LOG \n";
		};
		foreach my $AA (@clean_1,@clean_2)
		{
			$bwa_sh.= &exon::file_recheck("$AA");
		};
	};
	
	$bwa_sh.= "\n\ntime=\$(date) && echo \t\t\$time ===================================================1.1_bwa_to_bam_start >>$output_dir/LOG \n";
	#########################################
	$bwa_sh.= "toolsbwa=\"$parameters{T2}/BWA/bwa\" \n";
	$bwa_sh.= "toolssam=\"$parameters{T2}/samtools\" \n";
	$bwa_sh.= "toolsbed=\"$parameters{T2}/bedtools\" \n";
	######################################
	if (@clean_1 >0)
	{
			for(my $i=0;$i<@clean_1;$i++)
			{
				$bwa_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 4G  bwa \n";
				$bwa_sh.= "echo \"start_bwa_mem !!!\"";
				$bwa_sh.= &exon::sh_recheck("\$toolsbwa mem -M -t 4 -B 8 -O 12 -L 15 -U 20 -T 50 -d 75 -r 1.3 -E 4 -k 32 -Y $parameters{D1} -R \'\@RG\\tID\:$sample_name\\tLB:b$parameters{'batch'}\\tPL:illumina\\tSM\:$sample_name\' $clean_1[$i] $clean_2[$i] >$TMP_DIR/$parameters{DIR4}/$i.sam","bwa","2000");

				$bwa_sh.= &exon::file_recheck("$TMP_DIR/$parameters{DIR4}/$i.sam");
			};
			$bwa_sh.= "time=\$(date) && echo \t\t\$time ===================================================1.1_bwa_end_and_sort_start! >>$output_dir/LOG \n";##########step1.4 sam文件转换格式为bam文件（多个bam文件则进行合并）
			my @all_bam;
			for(my $i=0;$i<@clean_1;$i++)
			{
				$bwa_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 8G  samtool_view \n";
				$bwa_sh.= "echo \"start_samtools_view !!!\"";
				$bwa_sh.= &exon::sh_recheck("\$toolssam view -bS $TMP_DIR/$parameters{DIR4}/$i.sam >$FSD_DIR/$parameters{DIR4}/$i.bam","bwa","2000");
				$bwa_sh.= &exon::file_recheck("$FSD_DIR/$parameters{DIR4}/$i.bam");

				push(@all_bam,"$FSD_DIR/$parameters{DIR4}/$i.bam");
				$bwa_sh.= "rm $TMP_DIR/$parameters{DIR4}/$i.sam\* \n";
			};
			my $bam_str=join(" ",@all_bam);
			if(@all_bam>=2)
			{
				$bwa_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G  bwa \n";
				$bwa_sh.= "echo \"start_bam_cat !!!\"";
				$bwa_sh.= &exon::sh_recheck("\$toolssam cat $bam_str >$FSD_DIR/$parameters{DIR4}/Tot.bam","samtools cat","2000");
				$bwa_sh.= "echo \"start_bam_sort !!!\"";
				$bwa_sh.= &exon::sh_recheck("\$toolssam sort $FSD_DIR/$parameters{DIR4}/Tot.bam >$FSD_DIR/$parameters{DIR4}/sum_merged.bam","samtools sort","2000");

				$bwa_sh.= "rm $FSD_DIR/$parameters{DIR4}/Tot.bam \n";
			}else
			{
				$bwa_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G bam_sort \n";
				$bwa_sh.= "echo \"start_bam_sort !!!\"";
				$bwa_sh.= &exon::sh_recheck("\$toolssam sort $bam_str  >$FSD_DIR/$parameters{DIR4}/sum_merged.bam","samtools sort","2000");
			};
			$bwa_sh.= "rm $bam_str \n";
	}elsif(exists $parameters{'bam'})
	{
			$bwa_sh.= "ln -s $parameters{'bam'} $output_dir/ \n";
			$bwa_sh.= "echo \"start_bam_add_group !!!\"";
			$bwa_sh.= &exon::sh_recheck("java -jar $parameters{S1} I=$parameters{'bam'} O=$FSD_DIR/$parameters{DIR4}/0.bam ID=$sample_name LB=b$parameters{'batch'} PL=illumina PU=NA SM=$sample_name","bam add group","2000");
			$bwa_sh.= "echo \"start_bam_sort !!!\"";
			$bwa_sh.= &exon::sh_recheck("\$toolssam sort $FSD_DIR/$parameters{DIR4}/0.bam >$FSD_DIR/$parameters{DIR4}/sum_merged.bam","samtools sort","2000");
	}else
	{
			print STDERR "\n\tno_fqs_and_bam\n";
			die;
	};
	$bwa_sh.= &exon::file_recheck("$FSD_DIR/$parameters{DIR4}/sum_merged.bam");
	$bwa_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G bam_index \n";
	$bwa_sh.= "echo \"start_bam_index !!!\"";
	$bwa_sh.= &exon::sh_recheck("\$toolssam index $FSD_DIR/$parameters{DIR4}/sum_merged.bam","bam samtool index","2000");

	$bwa_sh.= "time=\$(date) && echo \t\t\$time ===================================================1.1_bwa_to_bam_end and rmdup_bam_start >>$output_dir/LOG \n";

	$bwa_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 20G MarkDuplicates \n";
	$bwa_sh.= "echo \"start_bam_index !!!\"";
	$bwa_sh.= &exon::sh_recheck("java -Xms10G -Xmx12G -jar $parameters{T2}/picard.jar MarkDuplicates I=$FSD_DIR/$parameters{DIR4}/sum_merged.bam O=$FSD_DIR/$parameters{DIR4}/sum_merged.rmdup.bam M=$FSD_DIR/$parameters{DIR4}/rmdup_stat.txt REMOVE_DUPLICATES=true","MarkDuplicates","2000");

	$bwa_sh.= &exon::file_recheck("$FSD_DIR/$parameters{DIR4}/sum_merged.rmdup.bam");

	$bwa_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G rmdup_bam_index \n";
	$bwa_sh.= "echo \"start_rmdup_bam_index !!!\"";
	$bwa_sh.= &exon::sh_recheck("\$toolssam index $FSD_DIR/$parameters{DIR4}/sum_merged.rmdup.bam","rmdupbam samtool index","2000");
	$bwa_sh.= "echo rmdup_OK > $FSD_DIR/$parameters{DIR4}/rmdup.done \n";

	if ($sp_od=~/yes/i)
	{
	}else
	{
		$bwa_sh.= &exon::sh_recheck("cp $FSD_DIR/$parameters{DIR4}/\* $bam_dir/","$parameters{DIR4} cp","2000");
	};

	$bwa_sh.= "wait \n"; 
	$bwa_sh.= "time=\$(date) && echo \t\t\$time ===================================================1.1_rmdup_bam_end >>$output_dir/LOG \n";
	$bwa_sh.= "echo >>$output_dir/LOG \n ";

	$run_sh.= "\nsh $shell_dir/1.1_get.merge.bam.sh 1>$stdout_dir/1.1_get.merge.bam.sh.out 2>$stderr_dir/1.1_get.merge.bam.sh.err \n\n";
	$run_sh.= &exon::file_recheck("$output_dir/$parameters{DIR4}/sum_merged.bam");
	$run_sh.= &exon::file_recheck("$output_dir/$parameters{DIR4}/sum_merged.rmdup.bam");
};
########################################################################################################

if(((defined $only) && $step==3) || ((!defined $only) && $step<=3))
{
	my @for_array;
	push @for_array,"$FSD_DIR/$parameters{DIR4}/sum_merged.bam",$parameters{cap_bed},"$FSD_DIR/$parameters{DIR5}";
	push @for_array,"$FSD_DIR/$parameters{DIR4}/sum_merged.rmdup.bam",$parameters{cap_bed},"$FSD_DIR/$parameters{DIR6}";
	push @for_array,"$FSD_DIR/$parameters{DIR4}/sum_merged.bam",$parameters{target_bed},"$FSD_DIR/$parameters{DIR7}";

#	print ST "if [ ! -f \"$FSD_DIR/1.2_Merged_bam/rmdup_stat.txt\" ] && [ -f \"$output_dir/1.2_Merged_bam/rmdup_stat.txt\" ]\n\tthen mkdir -p $FSD_DIR && cp -r $output_dir/1.2_Merged_bam $FSD_DIR/ \nfi\n";

	for my $i (0,3,6)
	{
		 my $bam=$for_array[$i];
		 my $bed=$for_array[$i+1];
		 my $ana_dir=$for_array[$i+2];
		 my $stat_dir_name=(split /\//,$ana_dir)[-1];

			if ($ana_dir=~/$parameters{DIR5}/)
			{
				$stat_1_sh.= "toolsbwa=\"$parameters{T2}/BWA/bwa\" \n";
				$stat_1_sh.= "toolssam=\"$parameters{T2}/samtools\" \n";
				$stat_1_sh.= "toolsbed=\"$parameters{T2}/bedtools\" \n";
				$stat_1_sh.= &exon::dir_bak("$FSD_DIR/$stat_dir_name");
				$stat_1_sh.= "time=\$(date) && echo \t\t\$time ===================================================$stat_dir_name\_start >>$output_dir/LOG \n";


				$stat_1_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G CollectHsMetrics \n";
				$stat_1_sh.= "echo \"start_CollectHsMetrics !!!\"";
				$stat_1_sh.= &exon::sh_recheck("java -jar $parameters{T2}/picard.jar CollectHsMetrics BI=$bed\_Picard_Interval_list MQ=0 Q=0 TI=$bed\_Picard_Interval_list I=$FSD_DIR/$parameters{DIR4}/sum_merged.bam O=$ana_dir/coverage_stat.txt COVMAX=500000 R=$parameters{D1} CLIP_OVERLAPPING_READS=false >$stderr_dir/coverage_stat.err","CollectHsMetrics","2000");

				$stat_1_sh.= &exon::file_recheck("$bam");

				$stat_1_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G flagstat \n";
				$stat_1_sh.= "echo \"start_flagstat !!!\"";
				$stat_1_sh.= &exon::sh_recheck("\$toolssam flagstat $bam >$ana_dir/map_rate.txt","flagstat","2000");

				$stat_1_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G depth \n";
				$stat_1_sh.= "echo \"start_depth !!!\"";
				$stat_1_sh.= &exon::sh_recheck("\$toolssam depth -b $parameters{dep_bed} $bam >$ana_dir/bed_depth.txt","samtool depth","2000");
				$stat_1_sh.= "echo done > $ana_dir/bed_depth.txt.done\n";

				$stat_1_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G bed_depth2ave_depth_coverage \n";
				$stat_1_sh.= "echo \"start_bed_depth2ave_depth_coverage !!!\"";
				$stat_1_sh.= &exon::sh_recheck("perl $parameters{T1}/Bin/2.3.bed_depth2ave_depth_coverage.v1.pl $parameters{T2}/bedtools $ana_dir/bed_depth.txt $bed $ana_dir/bed_depth_coverage.txt >$stderr_dir/bed_depth_coverage.err","bed_depth2ave_depth_coverage","2000");

				$stat_1_sh.= "perl $parameters{T1}/Bin/2.5.average_depth_ditribution.pl $ana_dir/bed_depth_coverage.txt >$ana_dir/bed_depth.average.txt.percentage \n";
				$stat_1_sh.= "perl $parameters{T1}/Bin/2.8.Mapstat.pl -tool $parameters{T2}/samtools -i $bam -o $ana_dir/insert_size.txt \n";
				$stat_1_sh.= "perl $parameters{T1}/Bin/2.10.capture_rate.pl $parameters{T2}/samtools $bam $bed $ana_dir/capture_rate.txt \n";
				
				$stat_1_sh.= "wait\n";
				$stat_1_sh.= "perl $parameters{T1}/Bin/2.11.write_stat_report.pl $parameters{T2}/bedtools $ana_dir $output_dir >$ana_dir/stat_report.txt \n";

				if($parameters{cap_bed}=~/NT09/i)
				{
 					my $marker_bed="$parameters{T3}/I_sex_marker_bed/NT09Plus_marker.bed";
					$stat_1_sh.= "perl $parameters{T1}/Bin/2.13.1.sex_method1.v1.pl $marker_bed $ana_dir/bed_depth_coverage.txt $ana_dir/sex.method1.txt \n";
				}elsif($parameters{cap_bed}=~/NT01/)
				{
					my $marker_bed="$parameters{T3}/I_sex_marker_bed//NT01\_marker.bed";
					$stat_1_sh.= "perl $parameters{T1}/Bin/2.13.1.sex_method1.v1.pl $marker_bed $ana_dir/bed_depth_coverage.txt $ana_dir/sex.method1.txt \n";
				}elsif($parameters{cap_bed}=~/NT02A/)
				{
					my $marker_bed="$parameters{T3}/I_sex_marker_bed/NT02\_marker.bed";
					$stat_1_sh.= "perl $parameters{T1}/Bin/2.13.1.sex_method1.v1.pl $marker_bed $ana_dir/bed_depth_coverage.txt $ana_dir/sex.method1.txt \n";
				}else
				{
					my $temp_base_dir=(split /\//,$output_dir)[-1];
					$stat_1_sh.= "echo $temp_base_dir $parameters{'sex'} NA 1 >$ana_dir/sex.method1.txt \n";
				};
				my $input;
				my @fq1_files=split /\s+/,$parameters{'fq1'};
				for (my $i=0;$i<@fq1_files ;$i++)
				{
						$input.="$TMP_DIR/clean_$i\_time_1.fastq.gz $TMP_DIR/clean_$i\_time_2.fastq.gz ";
				};
				my $out="$ana_dir/$sample_ID";
				$stat_1_sh.= "$parameters{T1}/Bin/4.2.gzGCqual_Q33 $input $out \n";
				$stat_1_sh.=&exon::sh_recheck("cp -r $ana_dir $output_dir/","stat cp") if ($sp_od!~/yes/i);
				$stat_1_sh.= "wait\ntime=\$(date) && echo \t\t\$time ===================================================$stat_dir_name\_end ! >>$output_dir/LOG \n";
				$run_sh.= "sh $shell_dir/$stat_dir_name\.sh 1>$stdout_dir/$stat_dir_name\.sh.out 2>$stderr_dir/$stat_dir_name\.sh.err \& \n\n";
			}elsif ($ana_dir=~/$parameters{DIR6}/)
			{
				$stat_2_sh.= "toolsbwa=\"$parameters{T2}/BWA/bwa\" \n";
				$stat_2_sh.= "toolssam=\"$parameters{T2}/samtools\" \n";
				$stat_2_sh.= "toolsbed=\"$parameters{T2}/bedtools\" \n";
				$stat_2_sh.= &exon::dir_bak("$FSD_DIR/$stat_dir_name");
				$stat_2_sh.= "time=\$(date) && echo \t\t\$time ===================================================$stat_dir_name\_start >>$output_dir/LOG \n";

				$stat_2_sh.= &exon::file_wait("$output_dir/$parameters{DIR4}/rmdup.done","10800");

				$stat_2_sh.= &exon::file_recheck("$output_dir/$parameters{DIR4}/rmdup.done");

				$stat_2_sh.= &exon::file_recheck("$bam");

				$stat_2_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G flagstat \n";
				$stat_2_sh.= "echo \"start_flagstat !!!\"";
				$stat_2_sh.= &exon::sh_recheck("\$toolssam flagstat $bam >$ana_dir/map_rate.txt","flagstat","2000");

				$stat_2_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G depth \n";
				$stat_2_sh.= "echo \"start_depth !!!\"";
				$stat_2_sh.= &exon::sh_recheck("\$toolssam depth -b $parameters{dep_bed} $bam >$ana_dir/bed_depth.txt","samtool depth","2000");
				$stat_2_sh.= "echo done > $ana_dir/bed_depth.txt.done \n";

				$stat_2_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G bed_depth2ave_depth_coverage \n";
				$stat_2_sh.= "echo \"start_bed_depth2ave_depth_coverage !!!\"";
				$stat_2_sh.= &exon::sh_recheck("perl $parameters{T1}/Bin/2.3.bed_depth2ave_depth_coverage.v1.pl $parameters{T2}/bedtools $ana_dir/bed_depth.txt $bed $ana_dir/bed_depth_coverage.txt >$stderr_dir/rmdup_bed_depth_coverage.err","bed_depth2ave_depth_coverage");

				$stat_2_sh.= "perl $parameters{T1}/Bin/2.5.average_depth_ditribution.pl $ana_dir/bed_depth_coverage.txt >$ana_dir/bed_depth.average.txt.percentage \n";
				$stat_2_sh.= "perl $parameters{T1}/Bin/2.8.Mapstat.pl -tool $parameters{T2}/samtools -i $bam -o $ana_dir/insert_size.txt \n";
				$stat_2_sh.= "perl $parameters{T1}/Bin/2.10.capture_rate.pl $parameters{T2}/samtools $bam $bed $ana_dir/capture_rate.txt \n";
				$stat_2_sh.= "perl $parameters{T1}/Bin/2.11.write_stat_report.pl $parameters{T2}/bedtools $ana_dir $output_dir >$ana_dir/stat_report.txt \n";
				$stat_2_sh.=&exon::sh_recheck("cp -r $ana_dir $output_dir/","stat cp") if ($sp_od!~/yes/i);
				$stat_2_sh.= "wait\ntime=\$(date) && echo \t\t\$time ===================================================$stat_dir_name\_end ! >>$output_dir/LOG \n";
				$run_sh.= "sh $shell_dir/$stat_dir_name\.sh 1>$stdout_dir/$stat_dir_name\.sh.out 2>$stderr_dir/$stat_dir_name\.sh.err \& \n\n";
			}elsif($ana_dir=~/$parameters{DIR7}/)
			{
				$stat_3_sh.= "toolsbwa=\"$parameters{T2}/BWA/bwa\" \n";
				$stat_3_sh.= "toolssam=\"$parameters{T2}/samtools\" \n";
				$stat_3_sh.= "toolsbed=\"$parameters{T2}/bedtools\" \n";
				$stat_3_sh.= &exon::dir_bak("$FSD_DIR/$stat_dir_name");
				$stat_3_sh.= "time=\$(date) && echo \t\t\$time ===================================================$stat_dir_name\_start >>$output_dir/LOG \n";

				$stat_3_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G CollectHsMetrics \n";
				$stat_3_sh.= "echo \"start_CollectHsMetrics !!!\"";
				$stat_3_sh.= &exon::sh_recheck("java -jar $parameters{T2}/picard.jar CollectHsMetrics BI=$bed\_Picard_Interval_list MQ=0 Q=0 TI=$bed\_Picard_Interval_list I=$FSD_DIR/$parameters{DIR4}/sum_merged.bam O=$ana_dir/coverage_stat.txt COVMAX=500000 R=$parameters{D1} CLIP_OVERLAPPING_READS=false >$stderr_dir/2.3_coverage_stat.err","CollectHsMetrics");


				$stat_3_sh.= &exon::file_wait("$output_dir/$parameters{DIR5}/bed_depth.txt.done","10800");
				$stat_3_sh.= &exon::file_recheck("$output_dir/$parameters{DIR5}/bed_depth.txt.done");

				$stat_3_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G bed_depth2ave_depth_coverage \n";
				$stat_3_sh.= "echo \"start_bed_depth2ave_depth_coverage !!!\"";
				$stat_3_sh.= &exon::sh_recheck("perl $parameters{T1}/Bin/2.3.bed_depth2ave_depth_coverage.v1.pl $parameters{T2}/bedtools $FSD_DIR/$parameters{DIR5}/bed_depth.txt $bed $ana_dir/bed_depth_coverage.txt >$stderr_dir/2.3_bed_depth_coverage.err","2.3.bed_depth2ave_depth_coverage");
				$stat_3_sh.= "perl $parameters{T1}/Bin/2.5.average_depth_ditribution.pl $ana_dir/bed_depth_coverage.txt >$ana_dir/bed_depth.average.txt.percentage \n";

				$stat_3_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G bed_depth2ave_depth_coverage \n";
				$stat_3_sh.= "echo \"start_bed_depth2ave_depth_coverage !!!\"";
				$stat_3_sh.= &exon::sh_recheck("perl $parameters{T1}/Bin/2.3.bed_depth2ave_depth_coverage.v1.pl $parameters{T2}/bedtools $FSD_DIR/$parameters{DIR5}/bed_depth.txt $bed $ana_dir/bed_depth_coverage_bg10X.txt 10 >$stderr_dir/2.3_bg10X_bed_depth_coverage.err","bed_depth2ave_depth_coverage");

				$stat_3_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G gene_coverage_depth \n";
				$stat_3_sh.= "echo \"start_gene_coverage_depth !!!\"";
				$stat_3_sh.= &exon::sh_recheck("perl $parameters{T1}/Bin/2.14.get_gene_coverage_depth.pl $bed $ana_dir/bed_depth_coverage.txt $ana_dir/bed_depth_coverage_bg10X.txt $ana_dir/gene_coverage_depth.txt >$stderr_dir/2.3_gene_depth_coverage.err","gene coverage stat");

				$stat_3_sh.= &exon::file_wait("$output_dir/$parameters{DIR6}/bed_depth.txt.done","10800");
				$stat_3_sh.= &exon::file_recheck("$output_dir/$parameters{DIR6}/bed_depth.txt.done");

				$stat_3_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G bed_depth2ave_depth_coverage \n";
				$stat_3_sh.= "echo \"start_bed_depth2ave_depth_coverage !!!\"";
				$stat_3_sh.= &exon::sh_recheck("perl $parameters{T1}/Bin/2.3.bed_depth2ave_depth_coverage.v1.pl $parameters{T2}/bedtools $FSD_DIR/$parameters{DIR6}/bed_depth.txt $bed $ana_dir/rmdup_bed_depth_coverage.txt >$stderr_dir/2.3_rmdup_bed_depth_coverage.err","bed_depth2ave_depth_coverage");

				$stat_3_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G bed_depth2ave_depth_coverage \n";
				$stat_3_sh.= "echo \"start_bed_depth2ave_depth_coverage !!!\"";
				$stat_3_sh.= &exon::sh_recheck("perl $parameters{T1}/Bin/2.3.bed_depth2ave_depth_coverage.v1.pl $parameters{T2}/bedtools $FSD_DIR/$parameters{DIR6}/bed_depth.txt $bed $ana_dir/rmdup_bed_depth_coverage_bg10X.txt 10 >$stderr_dir/2.3_rmdup_bg10X_bed_depth_coverage.err","bed_depth2ave_depth_coverage");

				$stat_3_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G bed_depth2ave_depth_coverage \n";
				$stat_3_sh.= "echo \"start_bed_depth2ave_depth_coverage !!!\"";
				$stat_3_sh.= &exon::sh_recheck("perl $parameters{T1}/Bin/2.3.bed_depth2ave_depth_coverage.v1.pl $parameters{T2}/bedtools $FSD_DIR/$parameters{DIR6}/bed_depth.txt $bed\_10bp $ana_dir/rmdup_10bp_bed_depth_coverage.txt >$stderr_dir/2.3_rmdup_10bp_bed_depth_coverage.err","bed_depth2ave_depth_coverage");

				$stat_3_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 6G gene_coverage_depth \n";
				$stat_3_sh.= "echo \"start_gene_coverage_depth !!!\"";
				$stat_3_sh.= &exon::sh_recheck("perl $parameters{T1}/Bin/2.14.get_gene_coverage_depth.pl $bed $ana_dir/rmdup_bed_depth_coverage.txt $ana_dir/rmdup_bed_depth_coverage_bg10X.txt $ana_dir/gene_coverage_depth_rmdup.txt >$stderr_dir/2.3_rmdup_gene_depth_coverage.err","rmdup gene coverage stat");

				$stat_3_sh.= "wait\n";
				$stat_3_sh.= "perl $parameters{T1}/Bin/2.11.write_stat_report.pl $parameters{T2}/bedtools $ana_dir $output_dir >$ana_dir/stat_report.txt \n";

				$stat_3_sh.= "echo bed_depth_coverage_OK > $ana_dir/bed_depth_coverage.txt.done \n";
				$stat_3_sh.= "echo gene_coverage_depth_OK > $ana_dir/gene_coverage_depth.txt.done \n";
				$stat_3_sh.= "perl $parameters{T1}/Bin/5.5.0_get_gene_depth.pl  $ana_dir  $ana_dir/rmdup_gene_bed_depth.txt \n";
				$stat_3_sh.=&exon::sh_recheck("cp -r $ana_dir $output_dir/","stat cp","2000") if ($sp_od!~/yes/i);
				$stat_3_sh.= "wait\ntime=\$(date) && echo \t\t\$time ===================================================$stat_dir_name\_end ! >>$output_dir/LOG \n";
				$run_sh.= "sh $shell_dir/$stat_dir_name\.sh 1>$stdout_dir/$stat_dir_name\.sh.out 2>$stderr_dir/$stat_dir_name\.sh.err \& \n\n";
			}else
			{
				print STDERR "error:$ana_dir\n";
				die;
			};
	};
};

###############################################################################################################################################

if(((defined $only) && $step==5) || ((!defined $only) && $step<=5))
{
	my $want_tool_dir=$parameters{T2};
	my $want=basename($parameters{'var_bed'});
	if ($step<=4)
	{
		$run_sh.=&exon::dir_bak("$call_dir");
		$run_sh.=&exon::dir_bak("$anno_dir");
		$run_sh.=&exon::dir_bak("$result_dir");

		$run_sh.= "perl $parameters{T1}/Bin/memory_monitoring.v1.pl 4G GATK \n";
		$run_sh.= "echo \"start_to_call_snvs !!!\"";
		$run_sh.= &exon::sh_recheck("perl $parameters{T1}/Bin/3.1.SNP_calling.v2.pl $output_dir/$parameters{DIR4}/sum_merged.rmdup.bam $parameters{D29}/$want $call_dir 9 $parameters{'SNP_call_T'} 1>$stdout_dir/snp_calling.out 2>$stderr_dir/snp_calling.err","call_snvs","2000");
	};

	$run_sh.="\nwait\n\n";
	$run_sh.= &exon::file_recheck("$call_dir/All_variation.vcf","100");
	$run_sh.="perl $parameters{T1}/Bin/3.1.1.get_vcf_depth.v1.pl $call_dir/All_variation.vcf $call_dir/All_variation.vcf.annoformat \n";
	$run_sh.="perl $parameters{T1}/Bin/snp_clean_from_vcf.v1.pl $call_dir/All_variation.vcf.annoformat $call_dir/All_variation.vcf.annoformat.stat \n";

	`perl $write_anno_pl $call_dir/All_variation.vcf.annoformat $output_dir/conf.txt $output_dir/ no no `;

	if ($prog_type=~/^1/)
	{
#		print "perl $write_anno_pl $call_dir/All_variation.vcf.annoformat $output_dir/conf.txt $output_dir/ no no\n";
		`perl $write_anno_pl $call_dir/All_variation.vcf.annoformat $output_dir/conf.txt $output_dir/ no no `;
		$run_sh.= "\n\nif [ -f \"$call_dir/All_variation.vcf.annoformat\" ]\n\tthen sh $shell_dir/3.2_variation_annotation.sh 1>$stdout_dir/3.2_variation_annotation.sh.out 2>$stderr_dir/3.2_variation_annotation.sh.err\nfi\n\n";
	}elsif ($prog_type=~/^2/)
	{
		`perl $write_anno_pl $report_dir/report_fam/$sample_ID\_fam.vcf_table $output_dir/conf.txt $output_dir/ no no `;
		$run_sh.= "\n\nif [ -f \"$report_dir/report_fam/$sample_ID\_fam.vcf_table\" ]\n\tthen sh $shell_dir/3.2_variation_annotation.sh 1>$stdout_dir/3.2_variation_annotation.sh.out 2>$stderr_dir/3.2_variation_annotation.sh.err\nelse\n\tsh $shell_dir/3.1_fam_member_var_anno.sh 1>$stdout_dir/3.1_fam_member_var_anno.sh.out 2>$stderr_dir/3.1_fam_member_var_anno.sh.err\nfi\n\n";

		$shell_fam_other.="\nmkdir -p $call_dir $anno_dir $result_dir $stat_dir\n";
		$shell_fam_other.=&exon::file_recheck("$call_dir/All_variation.vcf.annoformat");
		$shell_fam_other.=&exon::sh_recheck("perl $parameters{T2}/VarAnnotation_v1.2.pl -conf $conf_file -f table -i $call_dir/All_variation.vcf.annoformat -o $call_dir/snp_splice","snp_anno",1800);
		$shell_fam_other.="perl $parameters{T1}/Bin/3.1.3.variation_format_change.v1.pl $call_dir/snp_splice $call_dir/All_variation.vcf.annoformat $call_dir/snp_splice_preformat \n";
		$shell_fam_other.="perl $parameters{T1}/Bin/2.13.2.sex_method2.v1.pl $call_dir/All_variation.vcf.annoformat $call_dir/sex.method2.txt \n";
		$shell_fam_other.="perl $parameters{T1}/Bin/3.3.2.get_sex_qc.v1.pl $output_dir $result_dir/sex_test.txt \n";
		$shell_fam_other.="java -jar $parameters{T1}/Bin/omimjar/omimjar.jar $anno_dir/C_omim.txt \n";
		$shell_fam_other.="if [[ \$\(file $anno_dir/C_omim.txt\) =~ \"empty\" ]]\n\tthen cp $parameters{T3}/B_disease_database/C_omim.txt  $anno_dir/C_omim.txt\nfi\n\n";
		#$shell_fam_other.="cp /share/chigenefs1a/EXdev/WES_pipe_v3/db/B_disease_database/C_omim.txt $anno_dir/C_omim.txt \n";
	}else
	{
		$shell_fam_other.="\nmkdir -p $call_dir $anno_dir $result_dir $stat_dir\n";
		$shell_fam_other.=&exon::file_recheck("$call_dir/All_variation.vcf.annoformat");
		$shell_fam_other.=&exon::sh_recheck("perl $parameters{T2}/VarAnnotation_v1.2.pl -conf $conf_file -f table -i $call_dir/All_variation.vcf.annoformat -o $call_dir/snp_splice","snp_anno",1800);
		$shell_fam_other.="perl $parameters{T1}/Bin/3.1.3.variation_format_change.v1.pl $call_dir/snp_splice $call_dir/All_variation.vcf.annoformat $call_dir/snp_splice_preformat \n";
		$shell_fam_other.="perl $parameters{T1}/Bin/2.13.2.sex_method2.v1.pl $call_dir/All_variation.vcf.annoformat $call_dir/sex.method2.txt \n";
		$shell_fam_other.="perl $parameters{T1}/Bin/3.3.2.get_sex_qc.v1.pl $output_dir $result_dir/sex_test.txt \n";
		$shell_fam_other.="java -jar $parameters{T1}/Bin/omimjar/omimjar.jar $anno_dir/C_omim.txt \n";
		$shell_fam_other.="if [[ \$\(file $anno_dir/C_omim.txt\) =~ \"empty\" ]]\n\tthen cp $parameters{T3}/B_disease_database/C_omim.txt  $anno_dir/C_omim.txt\nfi\n\n";
		#$shell_fam_other.="cp /share/chigenefs1a/EXdev/WES_pipe_v3/db/B_disease_database/C_omim.txt $anno_dir/C_omim.txt \n";
		################################
		$run_sh.= "\nsh $shell_dir/3.1_fam_member_var_anno.sh 1>$stdout_dir/3.1_fam_member_var_anno.sh.out 2>$stderr_dir/3.1_fam_member_var_anno.sh.err \n\n";
		############家系亲属就不需要进行突变注释了
	};
};

##################################################################################################
if($step<=6)
{
	$qc_sh.="#!/bin/sh\n";
	$qc_sh.="time=\$\(date\|sed \'s\/ \/\\_\/g\'\) \n";
	$qc_sh.="mkdir -p $qc_dir\n";
	$qc_sh.="time=\$(date) && echo \t\t\$time ===================================================4.1_QC_start ! >>$output_dir/LOG \n";
	####################################
	$qc_sh.="perl $parameters{T1}//Bin/4.4.get_QC_report.v1.pl $output_dir $qc_dir/QC_report.txt \n";
	$qc_sh.="time=\$(date) && echo \t\t\$time ===================================================4.1_QC_end ! >>$output_dir/LOG \n";
	$qc_sh.="echo >>$output_dir/LOG \n";
};
##################################################################################################

$run_sh.= "wait\nsh $shell_dir/4.1.QC.sh 1>$stdout_dir/4.1.QC.sh.out 2>$stderr_dir/4.1.QC.sh.err \n\n";
$run_sh.= "\n\n\n";

$run_sh.= "echo \"start_to_call_gene_CNV !!!\"";
$run_sh.= &exon::sh_recheck("perl $parameters{T1}/Bin/5.5.1_Control_gene_del.pl $output_dir $output_dir/$parameters{DIR18} 1>$stdout_dir/5.2_Control_GENE_deletion.out 2>$stderr_dir/5.2_Control_GENE_deletion.err","call_CNV","2000");

$run_sh.= "echo \"start_to_call_CNV !!!\"";
$run_sh.= &exon::sh_recheck("perl $parameters{T1}/Bin/5.5.1_Control_CNV_del.pl $output_dir $output_dir/$parameters{DIR20} 1>$stdout_dir/5.2_Control_CNV.out 2>$stderr_dir/5.2_Control_CNV.err","call_CNV_Control2","2000");

$run_sh.= "wait\nsh $shell_dir/4.1.QC.sh 1>$stdout_dir/4.1.QC.sh.out 2>$stderr_dir/4.1.QC.sh.err \n\n";
##############################################################
##############################################################
if($step<=7)
{
	my $cnvsh="$output_dir/$parameters{DIR1}/5.1.get_cnv.sh";
	my $qcdir="$output_dir/$parameters{DIR12}";

	$exon_sh.= "#!/bin/sh\n";
	$exon_sh.= "time=\$(date) && echo \t\t\$time ===================================================5.1_exon_analysis_start ! >>$output_dir/LOG \n";

	$exon_sh.= &exon::dir_bak("$output_dir/$parameters{DIR17}");
	$exon_sh.= &exon::dir_bak("$output_dir/$parameters{DIR14}");
	$exon_sh.= &exon::dir_bak("$output_dir/$parameters{DIR19}");

	$exon_sh.= &exon::file_recheck("$output_dir/$parameters{DIR12}/QC_report.txt");
	$exon_sh.= &exon::file_recheck("$output_dir/$parameters{DIR10}/sex_test.txt");
	$exon_sh.= &exon::file_recheck("$output_dir/$parameters{DIR7}/rmdup_bed_depth_coverage.txt");

	$exon_sh.= "perl $parameters{T1}/Bin/5.5.1_get_gene_database_result.pl  $output_dir $output_dir/$parameters{DIR17} \n";
	$exon_sh.= "perl $parameters{T1}/Bin/5.5.1_gene_inter.pl $output_dir/$parameters{DIR18}/Results/positive_control_gene $output_dir/$parameters{DIR20}/Results/positive_control_gene \n ";
	$exon_sh.= "perl $parameters{T1}/Bin/5.5.1_exactly_samebatch_exon_result.pl $output_dir $output_dir/$parameters{DIR19} \n";
	$exon_sh.= "perl $parameters{T1}/Bin/5.5.2_get_exon_database_result.pl $output_dir $output_dir/$parameters{DIR14} \n";

	$exon_sh.= "perl $parameters{T1}/Bin/5.5.2.2.exon.merge.pl $output_dir/$parameters{DIR14} $output_dir/$parameters{DIR19} $output_dir/$parameters{DIR14}/positive_cnv_region_exon_reliable_revise \n";

#	$exon_sh.= "perl $parameters{T1}/Bin/5.5.3_cnv_anno.v1.pl $output_dir/$parameters{DIR14}/positive_cnv_region_exon_reliable $parameters{'sample_id'} $output_dir/$parameters{DIR14}/positive_cnv_region_exon_reliable_anno \n";
#	$exon_sh.= "perl $parameters{T1}/Bin/5.7_exon_qc.v1.pl $output_dir/ $output_dir/$parameters{DIR14} \n";
#	$exon_sh.= "perl $parameters{T1}/Bin/5.7_samebatch_exon_qc.v1.pl $output_dir/ $output_dir/$parameters{DIR19} \n";

	$exon_sh.= "wait \n"; 
	$exon_sh.="time=\$(date) && echo \t\t\$time ===================================================5.1_CNV\\\|exon_analysis_end ! >>$output_dir/LOG \n";
	$exon_sh.="echo >>$output_dir/LOG \n";

	$exon_run_sh.= "sh $cnvsh 1>$output_dir/$parameters{DIR2}/5.1.get_cnv.sh.out 2>$output_dir/$parameters{DIR3}/5.1.get_cnv.sh.err \n";
};

#########################################
$report_prepare_sh="mkdir -p $other_info_dir $qc_dir\n\n";

$report_prepare_sh.= "perl $parameters{T1}/Bin/4.4.get_QC_report.v1.pl $output_dir $qc_dir/QC_report.txt \n";
$report_prepare_sh.=&exon::field_match("$qc_dir/QC_report.txt","rmdup_ave_depth","NO");
$report_prepare_sh.=&exon::field_match("$qc_dir/QC_report.txt","sex_test","NO");

$report_prepare_sh.= "perl $parameters{T1}/Bin/5.5.3_exon_fam.pl $exon_dir/positive_cnv_region_exon_reliable_revise $other_info_dir/exon_fam.txt &\nwait\n";
#$report_prepare_sh.= "perl $parameters{T1}/Bin/5.5.4_cnv_proband.pl $output_dir/$parameters{DIR18}/Results/T1/FastCallResults_T1.txt $output_dir/$parameters{DIR18}/Results/proband_gt1M_cnv.txt \n";
$report_prepare_sh.= "perl $parameters{T1}/Bin/5.5.4_cnv_proband_inter.pl $output_dir/$parameters{DIR18}/Results/T1/FastCallResults_T1.txt $output_dir/$parameters{DIR20}/Results/T1/FastCallResults_T1.txt $output_dir/$parameters{DIR18}/Results/proband_gt1M_cnv.txt \n"; ####edit 20180412
$report_prepare_sh.= "perl $parameters{T1}/Bin/5.5.4_cnv_fam.pl $output_dir/$parameters{DIR18}/Results/T1/FastCallResults_T1.txt $other_info_dir/cnv_fam.txt &\nwait\n\n";

$report_prepare_sh.= "perl $parameters{T1}/Bin/5.7.1_get_chr_gain_or_loss.v1.pl $output_dir $other_info_dir/chr_gain_or_loss.txt \n";

$report_prepare_sh.= "perl $parameters{T1}/Bin/5.7.2_get_chr_gene_UPD.v1.pl $call_dir/snp_splice_preformat $result_dir/sex_test.txt $other_info_dir/UPD \n";

if($prog_type=~/^2/)
{
	$report_prepare_sh.= "perl $parameters{T1}/Bin/get_family_upd.v1.pl -if $output_dir/$sample_ID\_handle.txt -table $xzz_dir/$parameters{DIR16}/report_fam/$xzz_num\_fam.vcf_table -o $other_info_dir/UPD_chr_res.txt &\nwait\n";
};

$report_prepare_sh.= "perl $parameters{T1}/Bin/5.7.3_get_smn1_del.v1.pl $bam_dir/sum_merged.rmdup.bam $other_info_dir/SMN1_res.txt \n";

if($prog_type=~/^3/)
{
	$report_prepare_sh.= "perl $parameters{T1}/Bin/5.7.4_get_gene_gain_or_loss.v1.pl $other_info_dir/exon_fam.txt $result_dir/sex_test.txt $other_info_dir/gene_gain_or_loss.txt 2 no \n";
}else
{
	$report_prepare_sh.= "perl $parameters{T1}/Bin/5.7.4_get_gene_gain_or_loss.v1.pl $other_info_dir/exon_fam.txt $result_dir/sex_test.txt $other_info_dir/gene_gain_or_loss.txt 2 yes \n";
};

$report_prepare_sh.= "perl $parameters{T1}/Bin/5.7.5_get_mut_tag.v1.pl $other_info_dir $other_info_dir/mut \n";
$report_prepare_sh.= "perl $parameters{T1}/Bin/5.7.6_get_other_info_report.v1.pl $output_dir/ $other_info_dir/tot_other_report.txt.bak \n";

$report_prepare_sh.= "perl $parameters{T1}/Bin/5.7.7_get_ACMG_and_genetic_info.v1.pl $other_info_dir/tot_other_report.txt.bak $sample_name $other_info_dir \n";
$report_prepare_sh.= "perl $parameters{T1}/Bin/get_ACMG_tot.v1.pl -id $output_dir/ -o $other_info_dir/tot_ACMG_add_cnv.txt \n";
$report_prepare_sh.= "perl $parameters{T1}/Bin/5.7.8_get_other_info_revise.v1.pl $other_info_dir/ $other_info_dir/tot_other_report.txt \n";

$report_prepare_sh.= "perl $parameters{T1}/Bin/4.4.get_QC_report.v1.pl $output_dir $qc_dir/QC_report.txt \n";

#########################################生成单报告
my $want=basename($parameters{'var_bed'});

$report_proband_fresh_sh= "time=\$(date) && echo \t\t\$time ===================================================report_proband_refresh_start ! >>$output_dir/LOG \n";
$report_proband_fresh_sh.= "mkdir -p $call_dir $anno_dir $result_dir $stat_dir $report_dir/report_proband $qc_dir\n";
$report_proband_fresh_sh.= "perl $parameters{T1}/Bin/4.4.get_QC_report.v1.pl $output_dir $qc_dir/QC_report.txt \n";
$report_proband_fresh_sh.=&exon::field_match("$qc_dir/QC_report.txt","rmdup_ave_depth","NO");
$report_proband_fresh_sh.=&exon::field_match("$qc_dir/QC_report.txt","sex_test","NO");


$report_proband_fresh_sh.= "\n\nif [ ! -f \"$call_dir/variation_in_chrall.g.vcf.gz\" ] && [ -f \"$call_dir/../3.1_variation_calling/variation_in_chrall.g.vcf.gz.tbi\" ]\n\tthen cp -r $call_dir/../3.1_variation_calling/variation_in_chrall.g.vcf.gz* $call_dir/\nelif [ ! -f \"$call_dir/variation_in_chrall.g.vcf.gz\" ] && [ ! -f \"$call_dir/../3.1_variation_calling/variation_in_chrall.g.vcf.gz.tbi\" ]\n\tthen perl $parameters{T1}/Bin/3.1.SNP_calling.v2.pl $output_dir/$parameters{DIR4}/sum_merged.rmdup.bam $parameters{D29}/$want $call_dir 9 $parameters{'SNP_call_T'} \&\n\twait\n\nelse\n\techo g.vcf.gz file is ok\nfi\n\n";
$report_proband_fresh_sh.= "\n\nif [ ! -f \"$call_dir/All_variation.vcf\" ] && [ -f \"$call_dir/../3.1_variation_calling/All_variation.vcf\" ]\n\tthen cp -r $call_dir/../3.1_variation_calling/All_variation.vcf $call_dir/\nelif [ ! -f \"$call_dir/All_variation.vcf\" ] && [ ! -f \"$call_dir/../3.1_variation_calling/All_variation.vcf\" ]\n\tthen echo vcf file is error !!!\n\texit;\nelse\n\techo vcf file is ok\nfi\n\n";


#`perl $write_anno_pl $call_dir/All_variation.vcf.annoformat $output_dir/conf.txt $output_dir/ no no `;
$report_proband_fresh_sh.= "\n\nif [ -f \"$result_dir/all_information.txt_ACMG\" ]\n\tthen echo annoation is finished !!!\nelif [ -f \"$call_dir/All_variation.vcf.annoformat\" ]\n\tthen sh $shell_dir/3.2_variation_annotation.sh 1>$stdout_dir/3.2_variation_annotation.sh.out 2>$stderr_dir/3.2_variation_annotation.sh.err\nelse\n\techo anno error !!!\n\texit\nfi\n\n";

$report_proband_fresh_sh.= &exon::file_recheck("$result_dir/all_information.txt_ACMG");
$report_proband_fresh_sh.= &exon::file_recheck("$other_info_dir/tot_other_report.txt");

my $vcf_all;
foreach my $sam_dir (@sample_dir)
{
	$vcf_all.=" $sam_dir/$parameters{DIR8}/All_variation.vcf ";
};
$report_proband_fresh_sh.= "perl $parameters{T1}/Bin/fam_baseline_reliability.pl -vcfs $vcf_all -info $result_dir/all_information.txt -od $result_dir/all_information.txt_mutReliability \&\nwait\n\n";


$report_proband_fresh_sh.= "perl $parameters{T1}/Bin/3.3.5.variation_prefilter.v1.pl $result_dir/all_information.txt_ACMG $output_dir/conf.txt $result_dir/all_information.txt_ACMG.filter \n";
$report_proband_fresh_sh.= "perl $parameters{T1}/Bin/3.3.4.choose_best_NM.v1.pl $result_dir/all_information.txt_ACMG $result_dir/all_information.txt_ACMG_bestNM \n";
$report_proband_fresh_sh.= "perl $parameters{T1}/Bin/3.3.5.variation_prefilter.v1.pl $result_dir/all_information.txt_ACMG_bestNM $output_dir/conf.txt $result_dir/all_information.txt_ACMG_bestNM.filter \n";

$report_proband_fresh_sh.= "perl $parameters{T1}/Bin/3.3.6.get_genetic_format.v2.pl $output_dir $result_dir/genetic_format.txt \n";
$report_proband_fresh_sh.= "perl $parameters{T1}/Bin/get_genetic_score.v1.pl $result_dir/genetic_format.txt $result_dir/genetic_format.txt_determination \n";

$report_proband_fresh_sh.= "perl $parameters{T1}/Bin/3.3.8.get_tot_5_report.v2.pl $output_dir $result_dir/$sample_ID\_tot_5_level.report.txt \n";

$report_proband_fresh_sh.= &exon::file_recheck("$result_dir/$sample_ID\_tot_5_level.report.txt");

$report_proband_fresh_sh.= "perl $parameters{T1}/Bin/get_gene_stat.v1.pl $result_dir/$sample_ID\_tot_5_level.report.txt $stat_dir/gene_stat.txt \n";
$report_proband_fresh_sh.= "perl $parameters{T1}/Bin/4.1.stat_VCF_SNP_in_different_chr.pl $result_dir/$sample_ID\_tot_5_level.report.txt_all.txt $stat_dir/variation_in_different_chr.txt \n\n\n";
$report_proband_fresh_sh.= "\nperl $parameters{T1}/Bin/mutation_check.v1.pl -id $output_dir -o $stat_dir/variation_QC.txt \n\n";

if($prog_type=~/^1/)
{
	$report_proband_fresh_sh.= "$parameters{T2}/Convert2Excel -i $result_dir/$sample_ID\_tot_5_level.report.txt $result_dir/$sample_ID\_tot_5_level.report.txt_QC -n Mutation Quality -code utf-8 -null -o $result_dir/$sample_ID\_tot_5_level.report.xlsx \n";
	$report_proband_fresh_sh.= "$parameters{T2}/Convert2Excel -i $result_dir/$sample_ID\_tot_5_level.report.txt_all.txt $result_dir/$sample_ID\_tot_5_level.report.txt_all.txt_QC -n Mutation Quality -code utf-8 -null -o $result_dir/$sample_ID\_tot_5_level.report.xlsx_all.xlsx \n\n";
};

$report_proband_fresh_sh.= "ln -s $result_dir/*_tot_5_level.report.txt $report_proband_txt \n";
$report_proband_fresh_sh.= "ln -s $result_dir/*_tot_5_level.report.txt_level5.txt $report_proband_txt\_level5.txt \n";
$report_proband_fresh_sh.= "ln -s $result_dir/*_tot_5_level.report.txt_fig_variant ${report_proband_txt}_fig_variant \n";

if($prog_type=~/^1/)
{
	$report_proband_fresh_sh.= "ln -s $result_dir/*_tot_5_level.report.xlsx $report_proband_name \n";
};

$report_proband_fresh_sh.= "ln -s $result_dir/*_tot_5_level.report.txt_QC $report_proband_qc \n\n\n";

$report_proband_fresh_sh.= "time=\$(date) && echo \t\t\$time ===================================================report_proband_refresh_end ! >>$output_dir/LOG \n";
$report_proband_fresh_sh.= "perl $parameters{T1}/Bin/4.4.get_QC_report.v1.pl $output_dir $qc_dir/QC_report.txt \n";

#######################################生成家系报告

if($prog_type=~/^2/)
{
	$report_fam_fresh_sh.= "time=\$(date) && echo \t\t\$time ===================================================report_fam_refresh_start ! >>$output_dir/LOG \n";
	$report_fam_fresh_sh.= "mkdir -p $call_dir $anno_dir $result_dir $stat_dir $report_dir/report_fam $qc_dir \n";

	$report_fam_fresh_sh.= "perl $parameters{T1}/Bin/4.4.get_QC_report.v1.pl $output_dir $qc_dir/QC_report.txt \n";
	$report_fam_fresh_sh.=&exon::field_match("$qc_dir/QC_report.txt","rmdup_ave_depth","NO");
	$report_fam_fresh_sh.=&exon::field_match("$qc_dir/QC_report.txt","sex_test","NO");

	$report_fam_fresh_sh.= "\n\nif [ ! -f \"$call_dir/variation_in_chrall.g.vcf.gz\" ] && [ -f \"$call_dir/../3.1_variation_calling/variation_in_chrall.g.vcf.gz\" ]\n\tthen cp -r $call_dir/../3.1_variation_calling/variation_in_chrall.g.vcf.gz* $call_dir/\nelif [ ! -f \"$call_dir/variation_in_chrall.g.vcf.gz\" ] && [ ! -f \"$call_dir/../3.1_variation_calling/variation_in_chrall.g.vcf.gz\" ]\n\tthen perl $parameters{T1}/Bin/3.1.SNP_calling.v2.pl $output_dir/$parameters{DIR4}/sum_merged.rmdup.bam $parameters{D29}/$want $call_dir 9 $parameters{'SNP_call_T'} \&\n\twait\nelse\n\techo g.vcf.gz file is ok\nfi\n\n";
	$report_fam_fresh_sh.= "\n\nif [ ! -f \"$call_dir/All_variation.vcf\" ] && [ -f \"$call_dir/../3.1_variation_calling/All_variation.vcf\" ]\n\tthen cp -r $call_dir/../3.1_variation_calling/All_variation.vcf $call_dir/\nelif [ ! -f \"$call_dir/All_variation.vcf\" ] && [ ! -f \"$call_dir/../3.1_variation_calling/All_variation.vcf\" ]\n\tthen echo vcf file is error !!!\n\texit;\nelse\n\techo vcf file is ok\nfi\n\n";

	$report_fam_fresh_sh.= "\nperl $parameters{T1}/Bin/get_family_group_depth.v1.pl $output_dir/$sample_ID\_handle.txt $output_dir/conf.txt $report_dir/report_fam/$sample_ID\_fam.vcf &\nwait\n";

	$report_fam_fresh_sh.= &exon::file_recheck("$report_dir/report_fam/$sample_ID\_fam.vcf");
	
	$report_fam_fresh_sh.= "perl $parameters{T1}/Bin/3.1.1.get_vcf_depth.v1.pl $report_dir/report_fam/$sample_ID\_fam.vcf $report_dir/report_fam/$sample_ID\_fam.vcf_table \n";

#	if ($parameters{sample_id}=~/JF/)	####加急项目不再分AB批，2018-03-27
#	{
#		$report_fam_fresh_sh.="\ncp $report_dir/report_fam/$sample_ID\_fam.vcf_table $report_dir/report_fam/$sample_ID\_fam_JF.vcf_table \n";
#		$report_fam_fresh_sh.="perl $parameters{T1}/Bin/get_NT01JF_group_depth.v1.pl -i $report_dir/report_fam/$sample_ID\_fam_JF.vcf_table -o $report_dir/report_fam/$sample_ID\_fam.vcf_table -p $sample_name \n\n";
#	};

	`perl $write_anno_pl $report_dir/report_fam/$sample_ID\_fam.vcf_table $output_dir/conf.txt $output_dir/ no no `;
	$report_fam_fresh_sh.= "\n\nif [ -f \"$result_dir/all_information.txt_ACMG\" ]\n\tthen echo annoation is finished !!!\nelif [ -f \"$report_dir/report_fam/$sample_ID\_fam.vcf_table\" ]\n\tthen sh $shell_dir/3.2_variation_annotation.sh 1>$stdout_dir/3.2_variation_annotation.sh.out 2>$stderr_dir/3.2_variation_annotation.sh.err\nelse\n\techo error,exit !!!\n\texit\nfi\n\n";

	$report_fam_fresh_sh.= &exon::file_recheck("$result_dir/all_information.txt_ACMG");

	$report_fam_fresh_sh.= "sh $shell_dir/report_prepare.sh 1>$stdout_dir/report_prepare.sh.out 2>$stderr_dir/report_prepare.sh.err \n\n";

	foreach my $tmp_dir (@other_dir)
	{
		print "$output_dir\t$tmp_dir\n";
		$sge_only=&exon::dir_sge_check($output_dir,$tmp_dir);
		if ($tmp_dir=~/error/)
		{
			print STDERR "error:lack some family members !!!\n";
			$report_fam_fresh_sh.="\n\necho error:lack some family members !!!\nexit\n\n"
		}elsif ($sge_only!~/yes/)
		{
			my $other_work_node=$parameters{sge_all};
			$report_fam_fresh_sh.= "ssh -T -n $other_work_node \'sh $tmp_dir/$parameters{DIR1}/report_prepare.sh 1>$tmp_dir/$parameters{DIR2}/report_prepare.sh.out 2>$tmp_dir/$parameters{DIR3}/report_prepare.sh.err \' \&\nwait \n\n";
		}else
		{
			$report_fam_fresh_sh.= "sh $tmp_dir/$parameters{DIR1}/report_prepare.sh 1>$tmp_dir/$parameters{DIR2}/report_prepare.sh.out 2>$tmp_dir/$parameters{DIR3}/report_prepare.sh.err \n\n";
		};
	};

	$report_fam_fresh_sh.= "sh $shell_dir/report_proband_fresh.sh 1>$stdout_dir/report_proband_fresh.sh.out 2>$stderr_dir/report_proband_fresh.sh.err \n\n";
	$report_fam_fresh_sh.= &exon::file_recheck("$result_dir/$sample_ID\_tot_5_level.report.txt");

	$report_fam_fresh_sh.= "perl $parameters{T1}/Bin/get_family_genetic_score.v1.pl -id $output_dir -if $output_dir/$sample_ID\_handle.txt -table $report_dir/report_fam/$sample_ID\_fam.vcf_table -o $report_dir/report_fam/$sample_ID\_fam_genetic_score &\nwait\n";
	$report_fam_fresh_sh.= "perl $parameters{T1}/Bin/fam_relationship_check.v1.pl -if $output_dir/$sample_ID\_handle.txt -table $report_dir/report_fam/$sample_ID\_fam.vcf_table -o $report_dir/report_fam/$sample_ID\_fam_relation &\nwait\n";


	$report_fam_fresh_sh.= &exon::file_recheck("$report_dir/report_fam/$sample_ID\_fam_genetic_score");

	$report_fam_fresh_sh.= "perl $parameters{T1}/Bin/get_ACMG_fam.v1.pl $report_dir/report_fam/$sample_ID\_fam_genetic_score $result_dir \n";
	$report_fam_fresh_sh.= "perl $parameters{T1}/Bin/get_ACMG_fam_add_upd.v1.pl $report_dir/report_fam/$sample_ID\_fam_genetic_score $other_info_dir \n";

	$report_fam_fresh_sh.= "perl $parameters{T1}/Bin/get_ACMG_tot.v1.pl -id $output_dir/ -o $report_dir/report_fam/tot_ACMG_add_fam.txt \n";
	$report_fam_fresh_sh.= &exon::file_recheck("$report_dir/report_fam/tot_ACMG_add_fam.txt");


	$report_fam_fresh_sh.= &exon::file_recheck("$result_dir/all_information.txt_ACMG");
	$report_fam_fresh_sh.= "perl $parameters{T1}/Bin/get_ACMG_result.v1.pl $result_dir/all_information.txt $report_dir/report_fam/tot_ACMG_add_fam.txt $result_dir/all_information.txt_ACMG\n";
	$report_fam_fresh_sh.= "ln -s $result_dir/all_information.txt_ACMG $report_dir/report_fam/ \n";
	$report_fam_fresh_sh.= &exon::file_recheck("$result_dir/all_information.txt_ACMG");

	$report_fam_fresh_sh.= "sh $shell_dir/report_proband_fresh.sh 1>$stdout_dir/report_proband_fresh.sh.out 2>$stderr_dir/report_proband_fresh.sh.err \n\n";

	$report_fam_fresh_sh.= "perl $parameters{T1}/Bin/get_fam_report.v1.pl $report_dir/report_fam/ $report_fam_txt yes &\nwait\n\n";
	
	$report_fam_fresh_sh.= &exon::file_recheck("$report_fam_txt");
	
	$report_fam_fresh_sh.= "$parameters{T2}/Convert2Excel -i $report_fam_txt $report_fam_txt\_QC -n Mutation Quality -code utf-8 -null -o $report_fam_name \n";
	$report_fam_fresh_sh.= "$parameters{T2}/Convert2Excel -i $report_fam_txt\_all.txt $report_fam_txt\_all.txt_QC -n Mutation Quality -code utf-8 -null -o $report_fam_name\_all.xlsx \n\n\n";
	$report_fam_fresh_sh.= "ln -s $report_fam_txt\_QC $report_fam_qc \n\n";

	$report_fam_fresh_sh.= "perl $parameters{T1}/Bin/4.4.get_QC_report.v1.pl $output_dir $qc_dir/QC_report.txt \n";
	$report_fam_fresh_sh.= "time=\$(date) && echo \t\t\$time ===================================================report_fam_refresh_end ! >>$output_dir/LOG \n";
}elsif($prog_type=~/^3/)
{
	$report_fam_fresh_sh.= "\nmkdir -p $call_dir $anno_dir $result_dir $stat_dir\n";
	$report_fam_fresh_sh.= "\n\nif [ ! -f \"$call_dir/variation_in_chrall.g.vcf.gz\" ] && [ -f \"$call_dir/../3.1_variation_calling/variation_in_chrall.g.vcf.gz\" ]\n\tthen cp -r $call_dir/../3.1_variation_calling/variation_in_chrall.g.vcf.gz* $call_dir/\nelif [ ! -f \"$call_dir/variation_in_chrall.g.vcf.gz\" ] && [ ! -f \"$call_dir/../3.1_variation_calling/variation_in_chrall.g.vcf.gz\" ]\n\tthen perl $parameters{T1}/Bin/3.1.SNP_calling.v2.pl $output_dir/$parameters{DIR4}/sum_merged.rmdup.bam $parameters{D29}/$want $call_dir 9 $parameters{'SNP_call_T'} \&\n\twait\nelse\n\techo g.vcf.gz file is ok\nfi\n\n";
	$report_fam_fresh_sh.= "\n\nif [ ! -f \"$call_dir/All_variation.vcf\" ] && [ -f \"$call_dir/../3.1_variation_calling/All_variation.vcf\" ]\n\tthen cp -r $call_dir/../3.1_variation_calling/All_variation.vcf $call_dir/\nelif [ ! -f \"$call_dir/All_variation.vcf\" ] && [ ! -f \"$call_dir/../3.1_variation_calling/All_variation.vcf\" ]\n\tthen echo vcf file is error !!!\n\texit;\nelse\n\techo vcf file is ok\nfi\n\n";
	$report_fam_fresh_sh.= "sh $shell_dir/3.1_fam_member_var_anno.sh 1>$stdout_dir/3.1_fam_member_var_anno.sh.out 2>$stderr_dir/3.1_fam_member_var_anno.sh.err \n\n";
};

##################
$shell_fresh.="ssh -T -n $parameters{sge_all} \'perl $0 -conf $conf_file -od $output_dir -cov no -link yes -data_conf $data_conf\' \&\nwait\n\n";
$report_work_sh.="ssh -T -n $parameters{sge_all} \'perl $parameters{T1}/Bin/revise_handle_file.v1.pl $output_dir/$sample_ID\_handle.txt\' \&\nwait\necho handle_revise_done !!!\n";

if($prog_type=~/^1/)
{
	$report_work_sh.="sh $shell_dir/report_prepare.sh 1>$stdout_dir/report_prepare.sh.out 2>$stderr_dir/report_prepare.sh.err \n\n";
	$report_work_sh.="sh $xzz_dir/$parameters{DIR1}/report_proband_fresh.sh 1>$xzz_dir/$parameters{DIR2}/report_proband_fresh.sh.out 2>$xzz_dir/$parameters{DIR3}/report_proband_fresh.sh.err \n\n";

	$report_work_sh.="echo \"get_snvs_plot !!!\"";
	$report_work_sh.= &exon::sh_recheck("$parameters{S12} $parameters{T2}/bam_drawing.py -b $bam_dir/sum_merged.rmdup.bam -g ${report_proband_txt}_fig_variant -o $report_dir/Fig_variant 1>$stdout_dir/Fig_variant.out 2>$stderr_dir/Fig_variant.err","Fig_variant");
	$report_work_sh.= "perl $parameters{T1}/Bin/4.4.get_QC_report.v1.pl $output_dir $qc_dir/QC_report.txt \n";
}elsif($prog_type=~/^2/)
{

	foreach my $tmp_dir (@sample_dir)
	{
		$sge_only=&exon::dir_sge_check($output_dir,$tmp_dir);
		if ($tmp_dir=~/error/)
		{
			$report_work_sh.="\n\necho error:lack some family members !!!\nexit\n\n";
			last;
		}elsif(!-f "$tmp_dir/$parameters{DIR14}/positive_cnv_region_exon_reliable_revise")
		{
			$report_work_sh.="\n\necho error:lack file $tmp_dir/$parameters{DIR14}/positive_cnv_region_exon_reliable_revise !!!\nexit\n\n";
			last;
		};
	};

	$report_work_sh.="\n\nif [ -f \"$xzz_dir/report_running\" ]\n\tthen echo work_is_running !\n\texit;\nelse\n\ttouch $xzz_dir/report_running\nfi\n\n";

	foreach my $tmp_dir (@other_dir)
	{
		$sge_only=&exon::dir_sge_check($output_dir,$tmp_dir);
		if ($tmp_dir=~/error/)
		{
			$report_work_sh.="\n\necho error:lack some family members !!!\nrm $xzz_dir/report_running\nexit\n\n"
		}elsif ($sge_only!~/yes/)
		{
			my $other_work_node=&exon::get_dir_work_node($tmp_dir);
			$report_work_sh.= "ssh -T -n $parameters{sge_all} \'sh $tmp_dir/$parameters{DIR1}/shell_fresh.sh 1>$tmp_dir/$parameters{DIR2}/shell_fresh.sh.out 2>$tmp_dir/$parameters{DIR3}/shell_fresh.sh.err \' \&\nwait \n\n";
			$report_work_sh.= "ssh -T -n $other_work_node \'sh $tmp_dir/$parameters{DIR1}/report_fam_fresh.sh 1>$tmp_dir/$parameters{DIR2}/report_fam_fresh.sh.out 2>$tmp_dir/$parameters{DIR3}/report_fam_fresh.sh.err \' \&\nwait \n\n";
		}else
		{
			$report_work_sh.= "ssh -T -n $parameters{sge_all} \'sh $tmp_dir/$parameters{DIR1}/shell_fresh.sh 1>$tmp_dir/$parameters{DIR2}/shell_fresh.sh.out 2>$tmp_dir/$parameters{DIR3}/shell_fresh.sh.err \' \&\nwait \n\n";
			$report_work_sh.= "sh $tmp_dir/$parameters{DIR1}/report_fam_fresh.sh 1>$tmp_dir/$parameters{DIR2}/report_fam_fresh.sh.out 2>$tmp_dir/$parameters{DIR3}/report_fam_fresh.sh.err \n\n";
		};
	};

	$report_work_sh.="sh $xzz_dir/$parameters{DIR1}/report_fam_fresh.sh 1>$xzz_dir/$parameters{DIR2}/report_fam_fresh.sh.out 2>$xzz_dir/$parameters{DIR3}/report_fam_fresh.sh.err \n";

	$report_work_sh.="\n\necho \"get_snvs_plot !!!\"";
	$report_work_sh.= &exon::sh_recheck("$parameters{S12}  $parameters{T2}/bam_drawing.py -b $bam_dir/sum_merged.rmdup.bam -g ${report_fam_txt}_fig_variant -o $report_dir/Fig_variant 1>$stdout_dir/Fig_variant.out 2>$stderr_dir/Fig_variant.err","Fig_variant");
	$report_work_sh.= "perl $parameters{T1}/Bin/4.4.get_QC_report.v1.pl $output_dir $qc_dir/QC_report.txt \n";
	$report_work_sh.="\n\nrm $xzz_dir/report_running\n";

}elsif($prog_type=~/^3/)
{
	$sge_only=&exon::dir_sge_check($output_dir,$xzz_dir);
	if ($xzz_dir=~/error/)
	{
		$report_fam_fresh_sh.="\n\necho error:lack some family members !!!\nexit\n\n"
	}elsif ($sge_only!~/yes/)
	{
		my $other_work_node=&exon::get_dir_work_node($xzz_dir);
		$report_work_sh.= "ssh -T -n $parameters{sge_all} \'sh $xzz_dir/$parameters{DIR1}/shell_fresh.sh 1>$xzz_dir/$parameters{DIR2}/shell_fresh.sh.out 2>$xzz_dir/$parameters{DIR3}/shell_fresh.sh.err \' \&\nwait \n\n";
		$report_work_sh.= "ssh -T -n $other_work_node \'sh $xzz_dir/$parameters{DIR1}/report_work.sh 1>$xzz_dir/$parameters{DIR2}/report_work.sh.out 2>$xzz_dir/$parameters{DIR3}/report_work.sh.err \' \&\nwait \n\n";
	}else
	{
		$report_work_sh.= "ssh -T -n $parameters{sge_all} \'sh $xzz_dir/$parameters{DIR1}/shell_fresh.sh 1>$xzz_dir/$parameters{DIR2}/shell_fresh.sh.out 2>$xzz_dir/$parameters{DIR3}/shell_fresh.sh.err \' \&\nwait \n\n";
		$report_work_sh.= "sh $xzz_dir/$parameters{DIR1}/report_work.sh 1>$xzz_dir/$parameters{DIR2}/report_work.sh.out 2>$xzz_dir/$parameters{DIR3}/report_work.sh.err \n";
	};
};

#	$report_work_sh.= "sh $shell_dir/report_prepare.sh 1>$stdout_dir/report_prepare.sh.out 2>$stderr_dir/report_prepare.sh.err \n";
#######################################################

$run_sh.="\nwait\n";

if ($sp_od=~/yes/i)
{
}else
{
	$run_sh.= "if [ -d \"$FSD_DIR\" ]\n\tthen rm -rf $FSD_DIR\nfi\n \n";
	$run_sh.= "if [ -d \"$TMP_DIR/$parameters{DIR4}\" ]\n\tthen rm -rf $TMP_DIR/$parameters{DIR4}\nfi\n \n";
};

if($del_clean_data =~ /yes/)
{
	$run_sh.= "rm $TMP_DIR/clean*gz \n";
};

$run_sh.= $shell_fresh;
$exon_run_sh.=$shell_fresh;

$run_sh.= "time=\$(date) && echo \t\t\$time ===================================================Pipeline_end ! >>$output_dir/LOG \n";

if ($sp_od=~/yes/i)
{
}elsif((-f "$output_dir/LOG") && `grep node $output_dir/LOG` && $step>=2)
{
	$run_sh.= "\n\'\n";
};



&exon::write_out("$shell_dir/run.sh",$run_sh);
&exon::write_out("$shell_dir/1.1_get.merge.bam.sh",$bwa_sh);

&exon::write_out("$shell_dir/2.1_map_stat.sh",$stat_1_sh);
&exon::write_out("$shell_dir/2.2_rmdup_map_stat.sh",$stat_2_sh);
&exon::write_out("$shell_dir/2.3_function_region_map_stat.sh",$stat_3_sh);

&exon::write_out("$shell_dir/7.1_link.sh",$link_sh);

&exon::write_out("$shell_dir/4.1.QC.sh",$qc_sh);

&exon::write_out("$shell_dir/5.1.get_cnv.sh",$exon_sh);
&exon::write_out("$shell_dir/run_exon.sh",$exon_run_sh);

&exon::write_out("$shell_dir/3.1_fam_member_var_anno.sh",$shell_fam_other);
&exon::write_out("$shell_dir/report_prepare.sh",$report_prepare_sh);
&exon::write_out("$shell_dir/report_proband_fresh.sh",$report_proband_fresh_sh);
&exon::write_out("$shell_dir/report_fam_fresh.sh",$report_fam_fresh_sh);
&exon::write_out("$shell_dir/report_work.sh",$report_work_sh);

&exon::write_out("$shell_dir/shell_fresh.sh",$shell_fresh);

####################################################################################
sub path{ #$pavfile=&ABSOLUTE_DIR($pavfile);
        my $cur_dir=`pwd`;chomp($cur_dir);
        my ($in)=@_;
        my $return="";

        if(-f $in){
                my $dir=dirname($in);
                my $file=basename($in);
                chdir $dir;$dir=`pwd`;chomp $dir;
                $return="$dir/$file";
        }elsif(-d $in){
                chdir $in;$return=`pwd`;chomp $return;
        }else{
                warn "Warning just for file and dir\n";
                exit;
        }
        chdir $cur_dir;
        return $return;
};


sub datetime{#Time calculation subroutine
		my @arr=localtime ();
        my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @arr;
        $wday = $yday = $isdst = 0;
        sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
};

