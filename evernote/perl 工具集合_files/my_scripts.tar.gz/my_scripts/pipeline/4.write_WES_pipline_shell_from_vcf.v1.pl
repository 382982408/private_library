#!/usr/bin/perl -w
use strict;
use File::Basename;
use Getopt::Long;
use FindBin qw($Bin $Script);
######################################################
my($vcf,$table,$output_dir,$sex,$sampid,$batch,$filter);
$sex='NA';
$batch='999';
GetOptions
(
	"vcf=s"		=> \$vcf,
	"table=s"	=> \$table,
	"od=s"		=> \$output_dir,
	"ID=s"		=> \$sampid,
	"batch=s"	=> \$batch,
	"sex=s"		=> \$sex,
	"filter=s"	=> \$filter,
);
my $usage="
	perl $0
	-vcf			snp_vcf_file
	-table			table_file
	-od			output_dir
	-ID			sample_id		eg:28506xbycn1A_NT01
	-batch			batch			eg:520
	-sex			sex			eg:XX || XY || NA
	-filter			filter ??? yes|no

table_format:
	chr1    866511  866512  -       CCCT    rs60722469      60.0000 16/36=0.4444
	chr1    900718  900721  TTAT    -       rs142545439     60.0000 3/6=0.5000
	chr1    900730  900730  G       A       rs3935066       60.0000 4/7=0.5714
";
if((!$vcf && !$table) or !$output_dir or !$sampid){print STDERR "$usage\n";exit};
if (!-d $output_dir){`mkdir -p $output_dir`};
$output_dir=&path($output_dir);
my $time=&datetime;
print "\tproject directory:\t$output_dir\t\t$time\n";

####################################################################
system "mkdir -p $output_dir/Shell" if (!-d "$output_dir/Shell");   #######最原始的目录结构只有此三个文件目录，以下是正文环节
system "mkdir -p $output_dir/STDOUT" if (!-d "$output_dir/STDOUT");
system "mkdir -p $output_dir/STDERR" if (!-d "$output_dir/STDERR");
####################################################################
####################################################################
my %parameters;
$parameters{filter_pcr}='YES';
$parameters{SNP_call_T}='HaplotypeCaller';

$parameters{sample_id}=$sampid;
$parameters{batch}=$batch;
$parameters{sex}=$sex;

my $conf_file="$output_dir/conf.txt";
open Z,">$conf_file" or die;
foreach my $key (sort keys %parameters)
{
	print Z "$key\t\t$parameters{$key}\n";
};

my $file="$Bin/../db/Z_lzw_database/CONFIG_ALL.txt";
&initialize($file,\%parameters);

foreach my $key (sort keys %parameters)
{
	next if($key!~/filter/);
	print Z "$key\t\t$parameters{$key}\n";
};
close Z;

my $addheader=$parameters{GATK_addheader};
my $localdir=$parameters{local_tool_dir};
my $All_RAW=$parameters{ALL_RAW};
##################################################################################################################################################
##################################################################################################################################################
open S,">$output_dir/Shell/3.2_variation_annotation.sh" or die "$!";			##########step3 variation_Annoation 
	my $call_dir="$output_dir/3.1_variation_calling";
	my $anno_dir="$output_dir/3.3_variation_annotation";
	my $stat_dir="$output_dir/3.4_variation_stat";
#	my $rmdir="$output_dir/3.2_variation_rmdup";
	my $want_tool_dir=$parameters{D27};

	print S "#!/bin/sh\n";
	print S "time=\$\(date\|sed \'s\/ \/\\_\/g\'\) \n";
	print S "if [ -d \"$call_dir\" ] \n\tthen mv $call_dir $call_dir\.bak.\$time \nfi \n";
	print S "if [ -d \"$anno_dir\" ] \n\tthen mv $anno_dir $anno_dir\.bak.\$time \nfi \n";
	print S "\nmkdir -p $call_dir $anno_dir $stat_dir\n";

	print S "time=\$(date) && echo \t\t\$time ===================================================3.1_SNP_calling_start ! >>$output_dir/LOG \n";

	if($vcf)
	{
		$vcf=`readlink -f $vcf`;chomp $vcf;
		print S "ln -s $vcf $call_dir/All_variation.vcf \n";
		print S "perl $parameters{T1}/Bin/3.1.1.get_vcf_depth.v1.pl $call_dir/All_variation.vcf $call_dir/All_variation.vcf.annoformat \n";
	}elsif($table)
	{
		$table=`readlink -f $table`;chomp $table;
		print S "ln -s $table $call_dir/All_variation.vcf.annoformat \n";
	}else
	{
		print STDERR "\n\tinput_error !!!\n\n";
		die;
	};

		print S "perl $parameters{T2}/VarAnnotation_v1.2.pl -conf $file -f table -i $call_dir/All_variation.vcf.annoformat -o $call_dir/snp_splice \n";
		print S "perl $parameters{T1}/Bin/3.1.3.variation_format_change.v1.pl $call_dir/snp_splice $call_dir/All_variation.vcf.annoformat $call_dir/snp_splice_preformat \n";
		print S "$parameters{T2}/annotools sort -i $call_dir/snp_splice_preformat -o $call_dir/snp_splice_preformat.sorted \n";

		print S "mkdir $anno_dir/M_CUP_predict $anno_dir/REVEL_predict $anno_dir/OMIM_database \n";

		print S "nohup $parameters{T2}/3.4.6.add_MCUP_REVEL_protein_predict.c $call_dir/snp_splice_preformat.sorted $parameters{D39} M_CUP_score $anno_dir/M_CUP_predict/m_cup.txt \> $output_dir/STDERR/m_cup.err \& \n";
		print S "nohup $parameters{T2}/3.4.6.add_MCUP_REVEL_protein_predict.c $call_dir/snp_splice_preformat.sorted $parameters{D40} REVEL_score $anno_dir/REVEL_predict/revel.txt \> $output_dir/STDERR/revel.err \& \n";
		print S "nohup java -jar $parameters{T1}/Bin/omimjar/omimjar.jar $anno_dir/OMIM_database/omim.txt \& \n";

		print S "$parameters{T2}/3.1.4_add_repeat.v1.c $call_dir/snp_splice_preformat.sorted $parameters{D7} $call_dir/snp_splice_preformat.sorted.addrepeat \n";
		print S "$parameters{T2}/3.1.5_add_ssr.v1.c $call_dir/snp_splice_preformat.sorted.addrepeat $parameters{D8} $call_dir/snp_splice_preformat.sorted.addrepeat.ssr \n";

		print S "perl $parameters{T1}/Bin/3.2.5.variation_prefilter.v1.pl $call_dir/snp_splice_preformat.sorted.addrepeat.ssr $conf_file $call_dir/snp_splice_preformat.sorted.addrepeat.ssr.prefilter \n";

		print S "perl $parameters{T1}/Bin/2.13.2.sex_method2.v1.pl $call_dir/snp_splice_preformat $call_dir/sex.method2.txt \n";
		##########################											##########step3.2 variation_anno 
		print S "ln -s $call_dir/snp_splice_preformat.sorted.addrepeat.ssr.prefilter $anno_dir/snp_filter \n";
		print S "$parameters{T2}/3.2.6_add_five_maf.v1.c $anno_dir/snp_filter $parameters{D9} $anno_dir/snp_filter.FiveMAF \n";

		print S "$parameters{T2}/3.2.7_revise_meMAF.v1.c $anno_dir/snp_filter.FiveMAF $parameters{D10} $anno_dir/snp_filter.FiveMAF.Arevise \n";

		print S "perl $parameters{T1}/Bin/3.2.8.add_ESP_MAF.v1.pl $anno_dir/snp_filter.FiveMAF.Arevise $parameters{D24} $anno_dir/snp_filter.FiveMAF.Besp \n";

		print S "$parameters{T2}/3.2.9_add_dbSNP_maf.v1.c $anno_dir/snp_filter.FiveMAF.Besp $parameters{D12} $anno_dir/snp_filter.FiveMAF.dbSNP \n";

		print S "perl $parameters{T1}/Bin/3.3.4.revise_cdsanno.v1.pl $anno_dir/snp_filter.FiveMAF.dbSNP $parameters{D11} $parameters{D25} $parameters{D26}\n";

		print S "perl $parameters{T1}/Bin/3.4.anno_OMIM_and_Swissvar.v1.pl $anno_dir/snp_filter.FiveMAF.dbSNP.Arevise $parameters{D17} $parameters{D14} $parameters{D16} $parameters{D15} $parameters{D41} $anno_dir/snp_filter.FiveMAF.dbSNP.disease \n";

		print S "$parameters{T2}/3.4.3_add_protein_predict.v1.c $anno_dir/snp_filter.FiveMAF.dbSNP.disease $parameters{D20} $anno_dir/snp_filter.FiveMAF.dbSNP.disease.Sift \n";

		print S "$parameters{T2}/3.4.4_add_splice_predict.v1.c $anno_dir/snp_filter.FiveMAF.dbSNP.disease.Sift $parameters{D19} $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice \n";
		
		print S "wait \n";
		print S "perl $parameters{T1}/Bin/3.4.5_revise_add_protein_predict.v1.pl $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice $parameters{D21} $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice_Arevise \n";

		print S "$parameters{T1}/Bin/3.6.primary_classfication.pl $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice_Arevise $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication $parameters{D42} \n";

		print S "perl $parameters{T1}/Bin/3.7.mutation_and_genetic_classfication.v1.pl -i $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication -conf $conf_file -o $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication.genetictype -st $parameters{D43} \n";

		print S "perl $parameters{T1}/Bin/3.8.2.add_mut_depth.v2.pl $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication.genetictype $conf_file $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication.genetictype.rmdepth \n";

		print S "perl $parameters{T1}/Bin/3.8.3.choose_best_NM.v2.pl $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication.genetictype.rmdepth $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication.genetictype.rmdepth.bestNM \n";
		print S "perl $parameters{T1}/Bin/3.8.4.get_disease_hot.v1.pl $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication.genetictype.rmdepth.bestNM $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication.genetictype.rmdepth.bestNM.Aadd_dis_path \n";

	print S "perl $parameters{T1}/Bin/3.9.1.format_5_level_convert.v1.pl $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication.genetictype.rmdepth.bestNM $parameters{'sample_id'} $file\n";
	print S "perl $parameters{T1}/Bin/3.9.2.add_Stop_length.v1.pl $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication.genetictype.rmdepth.bestNM.5_format_convert \n";
#	print S "\nwhile [ ! -f \"$output_dir/2.1_map_stat/sex.method1.txt\" ]\ndo\n\tsleep 30\ndone\nsleep 30\n";
	print S "perl $parameters{T1}/Bin/3.9.3.choose_mut_in_sex.v1.pl $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication.genetictype.rmdepth.bestNM.5_format_convert.addStop $output_dir/conf.txt NA $call_dir/sex.method2.txt $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication.genetictype.rmdepth.bestNM.5_format_convert.addStop.sexchose \n";

	if (defined $filter)
	{
		$parameters{filter_reason}=$filter;
	};
	print S "perl $parameters{T1}/Bin/3.9.3.2.filter_to_normal_report.v1.pl $anno_dir/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication.genetictype.rmdepth.bestNM.5_format_convert.addStop.sexchose  $anno_dir/tot_5_level.report.txt $parameters{filter_reason}  \n";

	print S "perl $parameters{T1}/Bin/3.9.4.get_3_level_report.v1.pl $anno_dir/tot_5_level.report.txt $output_dir/conf.txt $anno_dir/tot_3_level.report.txt\n";
	print S "java -jar $parameters{T2}/mutsjava/mutsjava.jar $anno_dir/tot_5_level.report.txt.mut $anno_dir/tot_5_level.report.txt.muttag \n";

##print "perl $Bin/Bin/3.9.8.variation_stat.v1.pl $output_dir/ $stat_dir/variation_stat.txt \n";die;
	print S "wait \n"; 
	print S "time=\$(date) && echo \t\t\$time ===================================================3.3_SNP_anno_end ! >>$output_dir/LOG \n";
	print S "echo >>$output_dir/LOG \n";
close S;
##################################################################################################################################################

open ST, ">$output_dir/Shell/run.sh" or die;
if (-f "$output_dir/Shell/3.2_variation_annotation.sh"){print ST "sh $output_dir/Shell/3.2_variation_annotation.sh 1>$output_dir/STDOUT/3.2_variation_annotation.sh.out 2>$output_dir/STDERR/3.2_variation_annotation.sh.error \n"};
close ST;

####################################################################################
sub path{ #$pavfile=&ABSOLUTE_DIR($pavfile);
        my $cur_dir=`pwd`;chomp($cur_dir);
        my ($in)=@_;
        my $return="";

        if(-f $in){
                my $dir=dirname($in);
                my $file=basename($in);
                chdir $dir;$dir=`pwd`;chomp $dir;
                $return="$dir/$file";
        }elsif(-d $in){
                chdir $in;$return=`pwd`;chomp $return;
        }else{
                warn "Warning just for file and dir\n";
                exit;
        }
        chdir $cur_dir;
        return $return;
};


sub datetime{#Time calculation subroutine
		my @arr=localtime ();
        my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @arr;
        $wday = $yday = $isdst = 0;
        sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
};

sub get_parameters		##############&get_parameters($model,\%parameters);
{
	my ($file,$hash)=@_;
	open L,"$file" or die;
	while (<L>)
	{
		chomp;
		next if (/^$/ || /^#/);
		my @arr=split /\t/,$_;
		if ($arr[1] eq 'ABS')
		{
			$hash->{$arr[0]}=$arr[2];
		}elsif($arr[1] eq 'BIN')
		{
			$hash->{$arr[0]}=$hash->{TOT_DIR}."$arr[2]";
		}elsif($arr[1] eq 'parameter')
		{
			$hash->{$arr[0]}=$arr[2];
		}else
		{
			my ($key,$value)=split /\t+/,$_,2;
			$hash->{$key}=$value;
		};
	};
	close L;
};

################################################################################
sub initialize
{
	my ($file,$hash)=@_;
	open K,"$file" or die; #######   0.读取所有配置文件与参数信息
	while (<K>)
	{
		chomp;
		next if (/^$/ || /^\#/);
		my @arr=split /\t/,$_;
		if (!defined $arr[2])
		{
			$hash->{$arr[0]}=$arr[1];
		}else
		{
			$arr[2]=~s/\#//g;
			$hash->{$arr[0]}="$arr[1] $arr[2]";
		};
	};
	close K;
};
####################################################################
