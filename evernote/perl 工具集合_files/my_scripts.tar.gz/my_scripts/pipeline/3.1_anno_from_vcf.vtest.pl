#!/usr/bin/perl -w
=head1 Usage

	perl 3.1_anno_from_vcf.v1.pl <vcf/table> <conf.txt> <output_dir> <run:yes/no> <cov_handle>

	####1>: annotate mutations from vcf/table

	chr1    916549  916549  A       G       chr1_916549_916549_A_G  NA      60.00   57/57=1.0000;Homo 
	chr1    935222  935222  C       A       chr1_935222_935222_C_A  NA      60.00   47/48=0.9792;Homo 
	chr1    935459  935459  A       G       chr1_935459_935459_A_G  NA      60.00   17/17=1.0000;Homo 
	chr1    935492  935492  G       T       chr1_935492_935492_G_T  NA      60.00   13/13=1.0000;Homo 
	chr1    948846  948847  -       A       chr1_948846_948847_-_A  NA      60.00   10/10=1.0000;Homo 
	chr1    948870  948870  C       G       chr1_948870_948870_C_G  NA      60.00   10/10=1.0000;Homo 
	chr1    948921  948921  T       C       chr1_948921_948921_T_C  NA      60.00   14/14=1.0000;Homo 
	chr1    949608  949608  G       A       chr1_949608_949608_G_A  NA      60.00   0/52=0.0000;Wild  
	chr1    949654  949654  A       G       chr1_949654_949654_A_G  NA      59.96   63/63=1.0000;Homo 
	chr1    949925  949925  C       T       chr1_949925_949925_C_T  NA      60.00   31/33=0.9394;Homo 
	chr1    955597  955597  G       T       chr1_955597_955597_G_T  NA      60.00   0/27=0.0000;Wild  

=cut;
use strict;
use File::Basename;
use Getopt::Long;
use FindBin qw($Bin $Script);
use Data::Dumper;
use lib "$Bin/Family_report/9.0_models/";
use standard_family;
use lib "$Bin/models/";
use exon;
######################################################
my $vcf=shift;
my $conf_file=shift;
my $output_dir=shift;
my $run=shift;
my $cov=shift;
die `pod2text $0` if(!defined $vcf || !defined $output_dir || !defined $conf_file);
#################################
$run ="no" if(!defined $run);
$cov ="yes" if(!defined $cov);

my %parameters;
&exon::get_parameters($conf_file,\%parameters);

my $par_file="$Bin/../db/Z_lzw_database/CONFIG_ALL.txt";
&exon::initialize($par_file,\%parameters);

my $all_raw=$parameters{D28};
my $sam_dir=$parameters{D30};
my $want_tool_dir=$parameters{D27};
my $want=basename($parameters{'var_bed'});
my $ssrbed="$parameters{T3}/ssr_bed/NT01_ssr.bed";
my $handlefile=$parameters{D70};
#############################################
my @config_recheck=split /\_/,$parameters{'sample_id'};
if (@config_recheck!=3)
{
	my @tmp=split /\s+/,`grep $config_recheck[0] $all_raw|grep $config_recheck[1]|tail -1`;
	$parameters{'sample_id'}=join "_",$tmp[1],$tmp[2],$tmp[3];
	print STDOUT "revise sample_id:\t".$parameters{'sample_id'}."\n";
};
####################################
my ($sample_name,$type,$prog)=split /\_/,$parameters{sample_id};
my ($sample_ID)=split /xb|zj|sl|xj/,$sample_name;

$output_dir=&exon::path($output_dir) if(-d $output_dir);
$vcf=&exon::path($vcf) if(-f $vcf);
###################################
my $shell_dir="$output_dir/$parameters{DIR1}";
my $stdout_dir="$output_dir/$parameters{DIR2}";
my $stderr_dir="$output_dir/$parameters{DIR3}";

my $bam_dir="$output_dir/$parameters{DIR4}";
my $stat1_dir="$output_dir/$parameters{DIR5}";
my $stat2_dir="$output_dir/$parameters{DIR6}";
my $stat3_dir="$output_dir/$parameters{DIR7}";

my $call_dir="$output_dir/$parameters{DIR8}";
my $anno_dir="$output_dir/$parameters{DIR9}";
my $result_dir="$output_dir/$parameters{DIR10}";
my $stat_dir="$output_dir/$parameters{DIR11}";

my $qc_dir="$output_dir/$parameters{DIR12}";
my $cnv_dir="$output_dir/$parameters{DIR13}";

my $other_info_dir="$output_dir/$parameters{DIR15}";
my $report_dir="$output_dir/$parameters{DIR16}";

system "mkdir -p $shell_dir" if (!-d $shell_dir);   #######��ԭʼ��Ŀ¼�ṹֻ�д������ļ�Ŀ¼�����������Ļ���
system "mkdir -p $stdout_dir" if (!-d $stdout_dir);
system "mkdir -p $stderr_dir" if (!-d $stderr_dir);
################################################
#if(!-f "$output_dir/conf.txt")
{
	open CONF,">$output_dir/conf.txt" or die"error:can not open file:$output_dir/conf.txt \n";
	foreach my $key( sort keys %parameters)
	{
		print CONF "$key\t\t$parameters{$key}\n";
	};
	close CONF;
};

#####################################

if ($cov=~/yes/)
{
	`perl $parameters{T1}/Bin/get_handle.v1.pl $sample_ID $output_dir $cov`;
}elsif(!-f "$output_dir/$sample_ID\_handle.txt" || (stat "$output_dir/$sample_ID\_handle.txt")[7]==0)
{
	`perl $parameters{T1}/Bin/get_handle.v1.pl $sample_ID $output_dir $cov`;

	if (!-f "$output_dir/$sample_ID\_handle.txt" || (`file $output_dir/$sample_ID\_handle.txt` =~/empty/))
	{
		`echo $sample_name > $output_dir/$sample_ID\_handle.txt`;
	};
};

########################################

open S,">$shell_dir/3.2_variation_annotation.sh" or die "error:can not open file:$shell_dir/3.2_variation_annotation.sh\n\n";
open OUT,">$shell_dir/report_proband_fresh.sh" or die "error:can not open file:$shell_dir/report_proband_fresh.sh\n\n";

print S "#!/bin/sh\n";
print S "\nmkdir -p $call_dir $anno_dir $result_dir $stat_dir\n";

print S "time=\$(date) && echo \t\t\$time ===================================================3.2_SNP_anno_start ! >>$output_dir/LOG \n";

if ($vcf=~/vcf$/)
{
	print S "cp $vcf $call_dir/anno_variation.vcf \n";
	print S "perl $parameters{T1}/Bin/3.1.1.get_vcf_depth.v1.pl $call_dir/anno_variation.vcf $call_dir/anno_variation.vcf.annoformat \n";
}else
{
	print S "cp $vcf $call_dir/anno_variation.vcf.annoformat \n";
};

print S &exon::file_recheck("$call_dir/anno_variation.vcf.annoformat","10");

print S &exon::sh_recheck("perl $parameters{T2}/VarAnnotation_v1.2.pl -conf $conf_file -f table -i $call_dir/anno_variation.vcf.annoformat -o $call_dir/snp_splice","snp_anno",1800);

print S &exon::file_recheck("$call_dir/snp_splice","10");

print S "perl $parameters{T1}/Bin/3.1.3.variation_format_change.v1.pl $call_dir/snp_splice $call_dir/anno_variation.vcf.annoformat $call_dir/snp_splice_preformat \n";


print S "perl $parameters{T1}/Bin/3.1.5.get_anno_format.v1.pl $call_dir/snp_splice_preformat $call_dir/snp_splice_preformat_rsrevise \n";
print S "sort -u $call_dir/snp_splice_preformat_rsrevise_format1 >$call_dir/snp_splice_preformat_rsrevise_format1_uniq \n";
print S "$parameters{T2}/annotools sort -i $call_dir/snp_splice_preformat_rsrevise_format1_uniq -o $call_dir/snp_splice_preformat_rsrevise_format1_uniq_sorted \n";
print S "ln -s $call_dir/snp_splice_preformat_rsrevise_format1_uniq_sorted $anno_dir/anno_format1 \n";
print S "$parameters{T2}/annotools anno -i $anno_dir/anno_format1 -d $parameters{D12} -o $anno_dir/B_dbSNP \n\n\n";

print S "perl $parameters{T1}/Bin/3.1.4.revise_cdsanno.v1.pl $call_dir/snp_splice_preformat $anno_dir/B_dbSNP $parameters{D11} $parameters{D25} $call_dir/snp_splice_preformat_rsrevise \n";
print S "perl $parameters{T1}/Bin/3.1.5.get_anno_format.v1.pl $call_dir/snp_splice_preformat_rsrevise $call_dir/snp_splice_preformat_rsrevise \n";

print S "sort -u $call_dir/snp_splice_preformat_rsrevise_format1 >$call_dir/snp_splice_preformat_rsrevise_format1_uniq \n";
print S "sort -u $call_dir/snp_splice_preformat_rsrevise_format2 >$call_dir/snp_splice_preformat_rsrevise_format2_uniq \n";
print S "sort -u $call_dir/snp_splice_preformat_rsrevise_muttag >$call_dir/snp_splice_preformat_rsrevise_muttag_uniq \n";

print S &exon::sh_recheck("java -jar $parameters{T2}/mutsjava/mutsjava.jar $call_dir/snp_splice_preformat_rsrevise_muttag_uniq $call_dir/snp_splice_preformat_rsrevise_muttag_uniq_compile","mut_compile",1800);

print S "$parameters{T2}/annotools sort -i $call_dir/snp_splice_preformat_rsrevise_format1_uniq -o $call_dir/snp_splice_preformat_rsrevise_format1_uniq_sorted \n";


print S "ln -s $call_dir/snp_splice_preformat_rsrevise_format2_uniq $anno_dir/anno_format2 \n";
print S "perl $parameters{T1}/Bin/2.13.2.sex_method2.v1.pl $call_dir/anno_variation.vcf.annoformat $call_dir/sex.method2.txt \n";

print S &exon::file_recheck("$anno_dir/anno_format1");
print S &exon::file_recheck("$anno_dir/anno_format2");

print S "$parameters{T2}/annotools intersect -i $anno_dir/anno_format1 -d $parameters{D7} -o $anno_dir/A_repeat.txt \n";
print S "$parameters{T2}/annotools intersect -i $anno_dir/anno_format1 -d $parameters{D8} -o $anno_dir/A_ssr.txt \n";


print S "$parameters{T2}/annotools anno -i $anno_dir/anno_format1 -d $parameters{D81} -o $anno_dir/B_EXAC & \n";
print S "$parameters{T2}/annotools anno -i $anno_dir/anno_format1 -d $parameters{D82} -o $anno_dir/B_krCHB & \n";
print S "$parameters{T2}/annotools anno -i $anno_dir/anno_format1 -d $parameters{D83} -o $anno_dir/B_krCHS & \n";

print S "$parameters{T2}/annotools anno -i $anno_dir/anno_format1 -d $parameters{D84} -o $anno_dir/B_gnomad & \n";


print S "$parameters{T2}/annotools anno -i $anno_dir/anno_format1 -d $parameters{D10} -o $anno_dir/B_meMAF \n";
print S "$parameters{T2}/annotools anno -i $anno_dir/anno_format1 -d $parameters{D24} -o $anno_dir/B_ESP \n";


print S "java -jar $parameters{T1}/Bin/omimjar/omimjar.jar $anno_dir/C_omim.txt \n";
print S "if [[ \$\(file $anno_dir/C_omim.txt\) =~ \"empty\" ]]\n\tthen cp $parameters{T3}/B_disease_database/C_omim.txt  $anno_dir/C_omim.txt\nfi\n\n";

print S "$parameters{T2}/annotools anno -i $anno_dir/anno_format1 -d $parameters{D16} -o $anno_dir/C_HGMD \n";
print S "perl $parameters{T1}/Bin/anno_gene_amino_info.v1.pl $anno_dir/anno_format2 $parameters{D31} AMINO $anno_dir/C_HGMD_amino \n";
print S "$parameters{T2}/annotools anno -i $anno_dir/anno_format1 -d $parameters{D15} -o $anno_dir/C_CLINVAR \n";
print S "perl $parameters{T1}/Bin/anno_gene_amino_info.v1.pl $anno_dir/anno_format2 $parameters{D27} AMINO $anno_dir/C_CLINVAR_amino \n";
print S "perl $parameters{T1}/Bin/anno_gene_amino_info.v1.pl $anno_dir/anno_format2 $parameters{D14} AMINO $anno_dir/C_OMIM \n";
print S "perl $parameters{T1}/Bin/anno_gene_amino_info.v1.pl $anno_dir/anno_format2 $parameters{D17} AMINO $anno_dir/C_SWISS \n";
print S "$parameters{T2}/annotools anno -i $anno_dir/anno_format1 -d $parameters{D57} -o $anno_dir/C_clinvitae \n";
print S "perl $parameters{T1}/Bin/anno_gene_amino_info.v1.pl $anno_dir/anno_format2 $parameters{D58} AMINO $anno_dir/C_clinvitae_amino \n";

print S "$parameters{T2}/annotools anno -i $anno_dir/anno_format1 -d $parameters{D20} -o $anno_dir/E_protein_predict & \n";
print S "perl $parameters{T1}/Bin/anno_gene_amino_info.v1.pl $anno_dir/anno_format2 $parameters{D21} AMINO $anno_dir/E_protein_predict_SIFTINDEL \n";

print S "$parameters{T2}/annotools anno -i $anno_dir/anno_format1 -d $parameters{D39} -o $anno_dir/F_splice_dbscSNV \n";
print S "$parameters{T2}/annotools anno -i $anno_dir/anno_format1 -d $parameters{D40} -o $anno_dir/F_splice_MaxEntscan \n";
print S "perl $parameters{T1}/Bin/get_splice_GTAG.v1.pl $call_dir/snp_splice_preformat_rsrevise $anno_dir/F_splice_GTAG \n\n";

print S "$parameters{T2}/annotools intersect -i $anno_dir/anno_format1 -d $parameters{D34} -o $anno_dir/G_disease_hotspots \n";

print S "perl $parameters{T1}/Bin/anno_gene_amino_info.v1.pl $anno_dir/anno_format2 $parameters{D33} GENE $anno_dir/H_RNA_expression_GTEx \n";
print S "perl $parameters{T1}/Bin/anno_gene_amino_info.v1.pl $anno_dir/anno_format2 $parameters{D32} GENE $anno_dir/H_RNA_expression_Tiger \n";


print S "wait \n";
print S "perl $parameters{T1}/Bin/3.3.2.get_sex_qc.v1.pl $output_dir $result_dir/sex_test.txt \n";
print S "perl $parameters{T1}/Bin/3.3.1.information_integration.v1.pl $output_dir $result_dir/all_information.txt \n";

print S &exon::file_recheck("$result_dir/all_information.txt");

print S "perl $parameters{T1}/Bin/get_ACMG_PA.v1.pl $result_dir/all_information.txt $result_dir/ACMG_PA.txt \n";
print S "perl $parameters{T1}/Bin/get_ACMG_PVS.v1.pl $result_dir/all_information.txt $result_dir/ACMG_PVS.txt \n";
print S "perl $parameters{T1}/Bin/get_ACMG_PS.v1.pl $result_dir/all_information.txt $result_dir/ACMG_PS.txt \n";
print S "perl $parameters{T1}/Bin/get_ACMG_PM.v1.pl $result_dir/all_information.txt $result_dir/ACMG_PM.txt \n";
print S "perl $parameters{T1}/Bin/get_ACMG_PP.v1.pl $result_dir/all_information.txt $result_dir/ACMG_PP.txt \n";

print S "perl $parameters{T1}/Bin/get_ACMG_BA.v1.pl $result_dir/all_information.txt $result_dir/ACMG_BA.txt \n";
print S "perl $parameters{T1}/Bin/get_ACMG_BS.v1.pl $result_dir/all_information.txt $result_dir/ACMG_BS.txt \n";
print S "perl $parameters{T1}/Bin/get_ACMG_BP.v1.pl $result_dir/all_information.txt $result_dir/ACMG_BP.txt \n";
print S "perl $parameters{T1}/Bin/get_ACMG_tot.v1.pl -id $output_dir -o $result_dir/tot_ACMG.txt \n";
print S &exon::file_recheck("$result_dir/tot_ACMG.txt");
print S "perl $parameters{T1}/Bin/get_ACMG_result.v1.pl $result_dir/all_information.txt  $result_dir/tot_ACMG.txt $result_dir/all_information.txt_ACMG\n";

print S "cp $parameters{D62} $result_dir/gene_list_all.txt \n";
if ($type=~/e$|eF$/)
{
	$type=~s/F//g;
	print S "wget http://192.168.6.150:8080/omim/panel/find2.do?panelName=$type -O $result_dir/gene_list_filter.txt \n";
}else
{
	print S "cp $parameters{D62} $result_dir/gene_list_filter.txt \n";
};

print S "cp $parameters{D63} $result_dir/gene_filter_list_all\.txt \n";


print OUT "perl $parameters{T1}/Bin/3.3.4.choose_best_NM.v1.pl $result_dir/all_information.txt_ACMG $result_dir/all_information.txt_ACMG_bestNM \n";
print OUT "perl $parameters{T1}/Bin/3.3.5.variation_prefilter.v1.pl $result_dir/all_information.txt_ACMG_bestNM $output_dir/conf.txt $result_dir/all_information.txt_ACMG_bestNM.filter \n";
print OUT "perl $parameters{T1}/Bin/3.3.6.get_genetic_format.v1.pl $output_dir $result_dir/genetic_format.txt \n";
print OUT "perl $parameters{T1}/Bin/get_genetic_score.v1.pl $result_dir/genetic_format.txt $result_dir/genetic_format.txt_determination \n";

print OUT "perl $parameters{T1}/Bin/3.3.8.get_tot_5_report.v2.pl $output_dir $result_dir/$sample_ID\_tot_5_level.report.txt \n";
print OUT "perl $parameters{T1}/Bin/get_gene_stat.v1.pl $result_dir/$sample_ID\_tot_5_level.report.txt $stat_dir/gene_stat.txt \n";
print OUT "perl $parameters{T1}/Bin/4.1.stat_VCF_SNP_in_different_chr.pl $result_dir/$sample_ID\_tot_5_level.report.txt_all.txt $stat_dir/variation_in_different_chr.txt \n";
print OUT "\nperl $parameters{T1}/Bin/mutation_check.v1.pl -id $output_dir -o $stat_dir/variation_QC.txt \n\n";

print OUT "$parameters{T2}/Convert2Excel -i $result_dir/$sample_ID\_tot_5_level.report.txt $result_dir/$sample_ID\_tot_5_level.report.txt_QC -n Mutation Quality -code utf-8 -null -o $result_dir/$sample_ID\_tot_5_level.report.xlsx \n";
print OUT "$parameters{T2}/Convert2Excel -i $result_dir/$sample_ID\_tot_5_level.report.txt_all.txt $result_dir/$sample_ID\_tot_5_level.report.txt_all.txt_QC -n Mutation Quality -code utf-8 -null -o $result_dir/$sample_ID\_tot_5_level.report.xlsx_all.xlsx \n";

print S "wait \n"; 
print S "time=\$(date) && echo \t\t\$time ===================================================3.2_SNP_anno_end ! >>$output_dir/LOG \n";
print S "echo >>$output_dir/LOG \n";
close S;
close OUT;

if (defined $run && $run=~/yes/i)
{
	print STDOUT "work is running!!!\tsh $output_dir/$parameters{DIR1}/3.2_variation_annotation.sh\n";

	`sh $output_dir/$parameters{DIR1}/3.2_variation_annotation.sh 1>$output_dir/$parameters{DIR2}/3.2_variation_annotation.sh.out 2>$output_dir/$parameters{DIR3}/3.2_variation_annotation.sh.err `;
	`sh $output_dir/$parameters{DIR1}/report_proband_fresh.sh 1>$output_dir/$parameters{DIR2}/report_proband_fresh.sh.out 2>$output_dir/$parameters{DIR3}/report_proband_fresh.sh.err `;
};
