#!/usr/bin/perl -w
use strict;
use Cwd;
use Getopt::Long;
use Data::Dumper;
use Spreadsheet::WriteExcel;
use Excel::Writer::XLSX;
use Encode;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);
my $indir;
my $batch=999;
my $outdir;
GetOptions
(
        "id=s"          => \$indir,
	"batch=s"	=> \$batch,
        "od=s"          => \$outdir,
);
my $usage="
		perl $0 -id <indir> -od <outdir> -batch <batch>
		-id		batch_dir
		-batch		batch
		-od		outdir
";
if(!defined $indir or !defined $outdir){ print "$usage";exit};
mkdir($outdir)if(!-d $outdir);
$indir=&path ($indir);
$outdir=&path ($outdir);
####################################################################Time
my @stat_reports1 = glob "$indir\/*/2.1_map_stat";
my @stat_reports2;
foreach (@stat_reports1)
{
	my $A="$_/stat_report.txt";
	if (-f $A)
	{
		push (@stat_reports2,$A);
	}else
	{
		print "NOfile:$A\n";
	};
};
####print Dumper \@stat_reports1;die;
##############################
my $MaxRow=1048576;
my $MaxLine=16384;
my $book1=Excel::Writer::XLSX->new("$outdir\/b${batch}_mapstat.xlsx");
my $row1=0;my $line1=0;
my $code='utf-8';
my $sheet_code="utf-8";
my $sheet1 = $book1->add_worksheet(decode("$sheet_code","b${batch}"));
my @head;
push @head,decode ($code,"样本名"),decode ($code,"reads双端比对率"),decode ($code,"reads单端比对率"),decode ($code,'插入片段平均值(bp)'),decode ($code,'插入片段中值(bp)');
push @head,decode ($code,'平均深度'),decode ($code,"覆盖度"),decode ($code,"捕获率"),decode ($code,'>=2X'),decode ($code,'>=5X');
push @head,decode ($code,'>=10X'),decode ($code,'>=20X'),decode ($code,'>=30X'),decode ($code,'总数据量(G)'),decode ($code,'双端比对reads数(M)'),decode ($code,'GC含量'),decode ($code,'Q20'),decode ($code,'Q30');
$sheet1->write(0,0,\@head,&Format_1($book1));
$sheet1->freeze_panes(1,0);
++$row1;
foreach my $A (@stat_reports2) 
{
	my $sam_name=(split /\//,$A)[-3];
	my %hash;
	open L,"$A" or die;
	while (<L>) 
	{
		next if (/^$/);
		chomp;
		my @arr=split /\t/,$_;
		$hash{$arr[0]}=$arr[1];	
	};
	close L;
	my $samdir=dirname ($A);
	my $qcstat=(glob "$samdir/*.stat")[0];
	if (-f $qcstat)
	{
		my $tmp=`tail -1 $qcstat`;chomp $tmp;
		my @arr1=split /\s+/,$tmp;
		$arr1[2]=$arr1[2]/1000000;$arr1[2]=sprintf ("%.2f",$arr1[2]);
		$hash{'pair_reads'}=$arr1[2];
		$arr1[3]=$arr1[3]/1000000000;$arr1[3]=sprintf ("%.2f",$arr1[3]);
		$hash{'base_num'}=$arr1[3];
		$hash{'GC'}=$arr1[4];
		$hash{'Q20'}=$arr1[5];
		$hash{'Q30'}=$arr1[6];
	};
	my @result;
	push @result, "$sam_name","$hash{'Percentage of proper PE map(%)'}","$hash{'Percentage of SE map(%)'}","$hash{'Mean Insertsize'}","$hash{'Median Insertsize'}";
	push @result,"$hash{'Average depth of Target region'}","$hash{'Coverage on Target region(%)'}","$hash{'Capture rate of Target region(%)'}";
	push @result, "$hash{'Size of Target region(>=2X)(%)'}","$hash{'Size of Target region(>=5X)(%)'}","$hash{'Size of Target region(>=10X)(%)'}","$hash{'Size of Target region(>=20X)(%)'}","$hash{'Size of Target region(>=30X)(%)'}";
	if (exists $hash{'pair_reads'})
	{
		push @result,$hash{'base_num'},$hash{'pair_reads'},$hash{'GC'},$hash{'Q20'},$hash{'Q30'}
	};
	my $com1=join "\t",@result;
	$com1=decode ($code,$com1);
	my @last2=split /\t/,$com1;
	map {delete $last2[$_] if($last2[$_] && $last2[$_] =~ /^NA$|^NULL$/i);} 0..@last2-1;
	$sheet1->write($row1,0,\@last2,&Format_2($book1));
	++$row1;
};
$sheet1->autofilter(0,0,$row1,$line1);
$sheet1->set_column(0,$line1,10);
$book1->close();
#####################################################Time

sub path{ #$pavfile=&ABSOLUTE_DIR($pavfile);
	my $cur_dir=`pwd`;chomp($cur_dir);
	my ($in)=@_;
	my $return="";

	if(-f $in){
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;chomp $dir;
		$return="$dir/$file";
	}elsif(-d $in){
		chdir $in;$return=`pwd`;chomp $return;
	}else{
		warn "Warning just for file and dir\n";
		exit;
	}
	chdir $cur_dir;
	return $return;
};

sub Format_1{                   ###################&Format_1($xls);
        my $format1 = $_[0]->add_format();                                      ########for header
        $format1->set_font('Times New Roman');
        $format1->set_bold();
        $format1->set_size('9');
        $format1->set_align('center');
        return $format1;
};

sub Format_2{
        my $format2 = $_[0]->add_format();
        $format2->set_font('Times New Roman');
        $format2->set_size('9');
        $format2->set_align('center');
        return $format2;
};

