package report;
{
	$Path::report::VERSION = '0.1';
};
#!/usr/bin/perl -w
use strict;
use Cwd;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);
my $samtools="/share/ofs1a/EXdev/WES_pipe_v2/bin/samtools";
my $bedtools="/share/ofs1a/EXdev/WES_pipe_v2/bin/bedtools";

###############################################################################################
#
#以下是注释部分
#
###############################################################################################
##########################################################################
sub path
{
	my ($dir)=@_;
	$dir=`readlink -f $dir`;
	chomp $dir;
	return $dir;
};
##########################################################################
sub NC2chr
{
	my $chr=(split /0{4,5}|\./,$_[0])[1];
	if ($chr eq '23')
	{
		$chr='X';
	}elsif($chr eq '24')
	{
		$chr='Y'
	};
	return "chr$chr";
};
##########################################################################
sub get_uniq
{
	my @TMP=@_;
	my (%uniq,@tmp);
	foreach my $A (@TMP)
	{
		if (not exists $uniq{$A})
		{
			push @tmp,$A;
			$uniq{$A}=1;
		};
	};
	return @tmp;
};
##########################################################################
sub get_ACMG		###################&standard_family::get_ACMG(\@bestNM,$cds,$pm1,\%acmg11);
{
	my ($bestnms,$cds,$pm1,$mut_genetic,$hash,$dis_hot,$mq,$sampname)=@_;
	my (%PM1,%cds,%reference);
	open (CDS,"$cds") || die ;
	while (<CDS>) 
	{
		chomp;	next if (/^$/);
		my @line=split "\t",$_;
		push @{$cds{$line[0]}},"$line[2]\-$line[3]";
	};
	close CDS;
	open (PM1,"$pm1") || die ;
	while (<PM1>) 
	{
		chomp;	next if (/^$/); 
		my @line=split "\t",$_;
		$PM1{$line[0]}{$line[1]}=$_;
	};
	close PM1;
	my (%path,%data,%ACMG);
	for (my $i=0;$i<@{$bestnms} ;$i++)
	{
			open (IN,"$$bestnms[$i]") || die ;
			while (<IN>) 
			{
				chomp;
				next if (/^$/ || /^Chr/);
##				next if ($_!~/124605505/);
				
				my @line=split "\t",$_;
				if ($line[0]=~/NC/)
				{
					$line[0]=&chr_convert($line[0]);####$line[0]=~s/chr//g;
				};

			my $key=&get_mut_compile("$line[0]:$line[1]-$line[2]",$line[8],$line[6]);

			if ($key=~/err/)
			{
				print STDERR "error: get mut tag !\t $key\n";
				die;
			};

				my @omim=split /\|/,$line[22];
				my $omimid='NA';$omimid=$omim[1] if(defined $omim[1]);

				next if (not exists $mut_genetic->{$key}{$omimid});

				$data{$key}{$omimid}=\@line;
				if (($omim[0] eq "OMIM") || ($line[24] eq "SWISS") || ($line[26] eq "HGMD") || ($line[29]=~/Pathogenic/i))
				{
					$path{$line[6]}{$key}{$omimid}=1;
				};
			};
			close IN;
	};

			foreach my $KEY (keys %data)
			{
				foreach my $omimid (keys %{$data{$KEY}})
				{
						my @line=@{$data{$KEY}{$omimid}};
								my $ref=$line[3];
								my $mut=$line[4];
								my $nm=(split ":",$line[8])[0];
								my @omim=split /\|/,$line[22];

								my $signal=0;
								if (exists $cds{$nm})
								{
										my @beds=@{$cds{$nm}};
								OUT:foreach (@beds)
										{
												my ($start,$end)=split /\-/,$_;
												if ($start<=$line[2] && $end>=$line[1])
												{
														$signal=1;
														last OUT;
												}
										}
								};
								if ($mut_genetic->{$KEY}{$omimid}=~/NA/)
								{
										$mut_genetic->{$KEY}{$omimid}=10000;
								};

								if ($line[7]=~/stopgain/i && $signal==0 && ($mut_genetic->{$KEY}{$omimid}==1 || $mut_genetic->{$KEY}{$omimid}==4))
								{
												push @{$ACMG{$KEY}{$omimid}},"PVS1(无义截断变异)";
								};
								if ($line[7]=~/^frameshift/i && $signal==0 && ($mut_genetic->{$KEY}{$omimid}==1 || $mut_genetic->{$KEY}{$omimid}==4))
								{
												push @{$ACMG{$KEY}{$omimid}},"PVS1(移码变异)";
								};


								my @class=split /\|/,$line[32];
								my @splice=("16104","16304","16404","16204","2310","2320","2330","2340");
								if ($class[0]~~@splice && $signal==0 && ($mut_genetic->{$KEY}{$omimid}==1 || $mut_genetic->{$KEY}{$omimid}==4))
								{
									push @{$ACMG{$KEY}{$omimid}},"PVS1(经典剪切位点上的变异)";
								}elsif(($line[31]!~/^Deleterious/i) && ($line[5]=~/^intronic/i))
								{
									push @{$ACMG{$KEY}{$omimid}},"BP7(不影响剪切的内含子变异)";
								};

								if ($line[7]=~/initiation/i && $signal==0 && ($mut_genetic->{$KEY}{$omimid}==1 || $mut_genetic->{$KEY}{$omimid}==4))
								{
										my $insdel=$line[32];
										if (($insdel=~/^1/ && ($line[8]!~/p\.M1M/i)) || ($insdel=~/^2/))
										{
														push @{$ACMG{$KEY}{$omimid}},"PVS1(起始密码子变异)";
										};
								};

								if (exists $path{$line[6]})
								{
									if(exists $path{$line[6]}{$KEY}{$omimid})
									{
										push @{$ACMG{$KEY}{$omimid}},"PS1(有疾病报道变异)";
									}else
									{
										push @{$ACMG{$KEY}{$omimid}},"BP5(该基因发现致病变异则其他变异获得BP5)";
									};
								};
								my $gene_name=(split /\|/,$line[6])[0];
								if ($line[8]=~m/.*p.\D+(\d+)\D+.*/) 
								{
									my $psite="p.".$1;
									if ((exists $PM1{$gene_name}{$psite}) && ($line[7]=~/nonsynonymous/i || $line[7]=~/frameshift/i)) 
									{
										push @{$ACMG{$KEY}{$omimid}},"PM1(致病氨基酸左右的变异)";
									};
								};
								$line[19]=~s/NA/0/g;
								my ($east,$esp)=(split /[|;]/,$line[19])[0,3];
								if ($line[15] eq "NA"){$line[15]=0}; 
								if ($line[20] eq "NA"){$line[20]=0}; 
								if ($line[9]!~/rs/i && $line[21]!~/rs/i) 
								{
									push @{$ACMG{$KEY}{$omimid}},"PM2(无rs号的变异)";
								}elsif($line[15]<0.05 && $east<0.05 && $esp<0.05 && $line[20]<0.05)
								{
									push @{$ACMG{$KEY}{$omimid}},"PM2(有rs号的低频变异)";
								};

								if($line[15]>=0.05 || $east>=0.05 || $esp>=0.05 || $line[20]>=0.05)
								{
									push @{$ACMG{$KEY}{$omimid}},"BA1(千人/ExAC东亚/ESP/dbSNP数据库中任一MAF>5%)";
								};
								#####################
								my @maf=split /\s+|\||\;/,(join "|",@line[15..20]);
								my $meMAF_dis=(split /\|/,$line[18])[1];
								my $big="NA";
								foreach my $tmp_maf(@maf)
								{
									if ($tmp_maf=~/\d+/ && $big=~/NA/)
									{
										$big=$tmp_maf;
									}elsif($tmp_maf=~/\d+/ && $tmp_maf>$big)
									{
										$big=$tmp_maf;
									};
								};
								if($big=~/\d+/ && $big==0)
								{
								}elsif (defined $meMAF_dis && $meMAF_dis=~/\d+/ && $big=~/\d+/ && ($meMAF_dis/$big > 1.5))
								{
									push @{$ACMG{$KEY}{$omimid}},"PS4(患者频率>>普通人频率)";
								};
								#################################
								if ($line[7]=~/non-frameshift/i) 
								{
									push @{$ACMG{$KEY}{$omimid}},"PM4(非移码变异)";
								};
								if ($line[7]=~/stoploss/i) 
								{
									push @{$ACMG{$KEY}{$omimid}},"PM4(终止密码子变异导致的蛋白延长)";
								};
								if ($line[32]=~/a/) 
								{
									push @{$ACMG{$KEY}{$omimid}},"PM5(已报道致病位点上的其它类型变异)";
								};
								##############################
								my $rubish="NA";
								my $jielun="NA";
								&get_sift($line[30],$rubish,\$jielun,\$rubish);
						########&get_sift($arr[32],$type12,\$protein_predict,\$construct_path);
								if($jielun=~/有害/)
								{
									push @{$ACMG{$KEY}{$omimid}},"PP3(至少2个软件预测有害)";
								}elsif($jielun=~/无害/)
								{
									push @{$ACMG{$KEY}{$omimid}},"BP4(至少2个软件预测无害)";
								};

								my @ssr=split /[=\|]/,$line[14];
								if (($line[13] eq "YES" || $ssr[1]>7) && ($line[32]=~/^2/)) 
								{
									push @{$ACMG{$KEY}{$omimid}},"BP3(重复区域/ssr>7区域的indel)"
								};
								if ($line[29]=~/Benign/i) 
								{
									push @{$ACMG{$KEY}{$omimid}},"BP6(Clinvar为benign)";
								};
								if ($line[7]=~/^synonymous/i && ($line[31]!~/^Deleterious/i))
								{
									push @{$ACMG{$KEY}{$omimid}},"BP7(不影响剪切的同义变异)";
								};
								if ($line[45]=~/Y/ && $line[9]!~/rs/i && $line[21]!~/rs/i)
								{
									push @{$ACMG{$KEY}{$omimid}},"PM1(位于多次被报道过存在致病变异的外显子上的新发突变)";	##########by lzw 20160707
								};
								$hash->{$KEY}{$omimid}=\@{$ACMG{$KEY}{$omimid}};
								################################################################
								if ($line[44]=~/Y/){$line[44]="是"}else{$line[44]="否"};
								if ($line[45]=~/Y/){$line[45]="是"}else{$line[45]="否"};
								my @dishot=@line[40..45];
								foreach my $AA (@dishot)
								{
									$AA=~s/\s+//g;
									if ($AA=~/^$/)
									{
										$AA="NA";
									};
								};
								$dis_hot->{$KEY}=\@dishot;
				};
			};
};
######################################################################################################################################
######################################################################################################################################
sub get_acmg_value		####################&standard_family::get_acmg_value(\@relys,\$acmgre);
{
	my ($acmg,$result,$tag)=@_;
	my ($pvs1,$ps,$pm,$pp,$ba,$bs,$bp,$sig_path,$sig_beni,$class)=(0,0,0,0,0,0,0,0,0,0,0);
	for (my $i=0;$i<@{$acmg};$i++) 
	{
		next if ($$acmg[$i]=~/Y/ && $tag==0);
		if ($$acmg[$i]=~/PVS1/)
		{
			$pvs1++;
		}elsif ($$acmg[$i]=~/^PS/)
		{
			$ps++;
		}elsif ($$acmg[$i]=~/^PM/)
		{
			$pm++;
		}elsif ($$acmg[$i]=~/^PP/)
		{
			$pp++;
		}elsif ($$acmg[$i]=~/^BA/)
		{
			$ba++;
		}elsif ($$acmg[$i]=~/^BS/)
		{
			$bs++;
		}elsif ($$acmg[$i]=~/^BP/)
		{
			$bp++;
		};
	};
	if ($pvs1==1)
	{
		$sig_path=1;
		if ($ps>=1)
		{
			$$result="致病突变|Pathogenic(I)(a)";
		}elsif($pm>=2)
		{
			$$result="致病突变|Pathogenic(I)(b)";
		}elsif($pm==1 and $pp==1)
		{
			$$result="致病突变|Pathogenic(I)(c)";
		}elsif($pp>=2)
		{
			$$result="致病突变|Pathogenic(I)(d)";
		}else
		{
			$sig_path=0;
		};
	}elsif ($ps>=2)
	{
		$sig_path=1;
		$$result="致病突变|Pathogenic(II)";
	}elsif ($ps==1)
	{
		$sig_path=1;
		if ($pm>=3)
		{
			$$result="致病突变|Pathogenic(III)(a)";
		}elsif($pm==2 and $pp>=2)
		{
			$$result="致病突变|Pathogenic(III)(b)";
		}elsif($pm==1 and $pp>=4)
		{
			$$result="致病突变|Pathogenic(III)(c)";
		}else
		{
			$sig_path=0;
		};
	};
	if ($ba==1)
	{
		$sig_beni=1;
		$$result="良性突变|Benign(I)";
	}elsif($bs>=2)
	{
		$sig_beni=1;
		$$result="良性突变|Benign(II)";
	};
	if ($sig_path==1 && $sig_beni==1) 
	{
		$$result="不确定致病性|Uncertain significance(II)";
	}elsif ($sig_path==0 && $sig_beni==0)
	{
		if ($bs==1 and $bp==1)
                {
                        $$result="可能良性突变|Likely benign(I)";
                }elsif($bp>=2)
                {
                        $$result="可能良性突变|Likely benign(II)";
                }elsif ($pvs1==1 and $pm==1)
		{
			$$result="可能致病突变|Likely pathogenic(I)";
		}elsif($ps==1 and ($pm==1 or $pm==2))
		{
			$$result="可能致病突变|Likely pathogenic(II)";
		}elsif($ps==1 and $pp>=2)
		{
			$$result="可能致病突变|Likely pathogenic(III)";
		}elsif($pm>=3)
		{
			$$result="可能致病突变|Likely pathogenic(IV)";
		}elsif($pm==2 and $pp>=2)
		{
			$$result="可能致病突变|Likely pathogenic(V)";
		}elsif($pm==1 and $pp>=4)
		{
			$$result="可能致病突变|Likely pathogenic(VI)";
		}else
		{
			$$result="不确定致病性|Uncertain significance(I)";
		};
	};
};
######################################################################################################

sub get_acmg_result
{
	my($array,$conyes,$conno,$match,$reaYES,$reaNO)=@_;
	my @arr=@{$array};
	my %uniq;
	@arr=grep ++$uniq{$_}<2,@arr;
	my ($tmp,@arr11,@ms11,%arr11,@arr22,@ms22,%arr22);
	$$match=0;
	foreach (@arr)
	{
		if ($_=~/Y/)
		{
			$$match=1;
			$_=~s/Y//g;
			push @arr11,$_;
			if ($_=~m/([a-zA-Z]+)(\d+)\((.*)\)/)
			{
				my $zimu=$1;
				my $shuzi=$2;
				my $ms=$3;
				push @{$arr11{$zimu}},$shuzi;
				push @ms11,$_;
			};
		}else
		{
			push @arr11,$_;
			push @arr22,$_;
			if ($_=~m/([a-zA-Z]+)(\d+)\((.*)\)/)
			{
				my $zimu=$1;
				my $shuzi=$2;
				my $ms=$3;
				push @{$arr11{$zimu}},$shuzi;
				push @{$arr22{$zimu}},$shuzi;
				push @ms11,$_;
				push @ms22,$_;
			};
		};
	};
	&get_acmg_value(\@arr11,\$tmp,1);
	$tmp.="--";
	foreach my $AA (sort keys %arr11)
	{
		my $tmpAA;
		if(@{$arr11{$AA}}==1)
		{
			$tmpAA="$AA"."@{$arr11{$AA}}[0]";
		}else
		{
			my $sum=join ",",sort {$a<=>$b} @{$arr11{$AA}};
			$tmpAA="$AA"."\($sum\)";
		};
		$tmp.="$tmpAA+";
	};
	$tmp=~s/\+$//;
	($$reaYES,$$conyes)=split /\|/,$tmp;
	$$reaYES.="(".(join ",",@ms11).")";
	############################
	&get_acmg_value(\@arr22,\$tmp,0);
	$tmp.="--";
	foreach my $AA (sort keys %arr22)
	{
		my $tmpAA;
		if (@{$arr22{$AA}}==1)
		{
			$tmpAA="$AA"."@{$arr22{$AA}}[0]";
		}else
		{
			my $sum=join ",",sort {$a<=>$b} @{$arr22{$AA}};
			$tmpAA="$AA"."\($sum\)";
		};
		$tmp.="$tmpAA+";
	};
	$tmp=~s/\+$//;
	($$reaNO,$$conno)=split /\|/,$tmp;
	$$reaNO.="(".(join ",",@ms22).")";
};
############################

sub get_genetic_conclusion
{
	my($HOMO,$AD,$uniq,$denovo,$fuhezahe)=@_;
	my $return="ERR";
	if ($denovo=~/YESHETE/)
	{
		if ($AD=~/AD/)
		{
			$return="P30";
		}elsif($AD=~/AR/)
		{
			$return="P31";
		}elsif($AD=~/XD|X-linked|XL/)
		{
			$return="P32";
		}elsif($AD=~/XR/)
		{
			$return="P33";
		};
	}elsif($denovo=~/YES/)
	{
			if($HOMO=~/homo|纯合|1/i)
			{
				if ($AD=~/AD/)
				{
					$return="P19";
				}elsif($AD=~/AR/)
				{
					$return="P20";
				}elsif($AD=~/XD|X-linked|XL/)
				{
					$return="P21";
				}elsif($AD=~/XR/)
				{
					$return="P22";
				};
			}elsif($HOMO=~/hete|杂合|2/i)
			{
				if ($AD=~/AD/)
				{
					$return="P26";
				}elsif($AD=~/AR/)
				{
					$return="P27";
				}elsif($AD=~/XD|X-linked|XL/)
				{
					$return="P28";
				}elsif($AD=~/XR/)
				{
					$return="P29";
				};
			}elsif($HOMO=~/hemi|半合子|5/i)
			{
				if ($AD=~/Y/)
				{
					$return="P23";
				}elsif($AD=~/XD|X-linked|XL/)
				{
					$return="P24";
				}elsif($AD=~/XR/)
				{
					$return="P25";
				};
			};
	}elsif($HOMO=~/homo|纯合|1/i)
	{
		if ($AD=~/AD/)
		{
			$return="P1";
		}elsif($AD=~/AR/)
		{
			$return="P2";
		}elsif($AD=~/XD|X-linked|XL/)
		{
			$return="P3";
		}elsif($AD=~/XR/)
		{
			$return="P4";
		};
	}elsif($HOMO=~/hete|杂合|2/i)
	{
		if ($AD=~/AD/)
		{
			$return="P8";
		}elsif($AD=~/AR/)
		{
			if ($uniq=~/YES/)
			{
				$return="P9";
			}elsif($fuhezahe=~/\d+/)
			{
				$return="P10";
			}else
			{
				$return="P11";
			};
		}elsif($AD=~/XD|X-linked|XL/)
		{
			$return="P12";
		}elsif($AD=~/XR/)
		{
			$return="P13";
		};
	}elsif($HOMO=~/hemi|半合子|5/i)
	{
		if ($AD=~/Y/)
		{
			$return="P5";
		}elsif($AD=~/XD|X-linked|XL/)
		{
			$return="P6";
		}elsif($AD=~/XR/)
		{
			$return="P7";
		};
	}elsif($HOMO=~/wild|野生型|4/i)
	{
		if ($AD=~/AD/)
		{
			$return="P14";
		}elsif($AD=~/AR/)
		{
			$return="P15";
		}elsif($AD=~/XD|X-linked|XL/)
		{
			$return="P16";
		}elsif($AD=~/XR/)
		{
			$return="P17";
		}elsif($AD=~/Y/)
		{
			$return="P18";
		};
	}elsif($HOMO=~/uncov|未覆盖|3/i)
	{
		$return="P34";
	};
	return $return;
};
