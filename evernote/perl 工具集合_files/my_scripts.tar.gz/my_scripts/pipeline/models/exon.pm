package exon;
{
	$Path::exon::VERSION = '0.1';
};
#!/usr/bin/perl -w
use strict;
use Cwd;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

my $abs_path=dirname(__FILE__);

my %parameters;
my $file="$abs_path/../../db/Z_lzw_database/CONFIG_ALL.txt";
initialize($file,\%parameters);


my $samtools="$parameters{T2}/samtools";	#######edit by wang 20180327
my $bedtools="$parameters{T2}/bedtools";	#######edit by wang 20180327

###############################################################################################
#
#以下是注释部分
#
###############################################################################################
sub revise_xgx
{
	my @RESULT=@_;
	for (my $i=0;$i<@RESULT; $i++)
	{
		$RESULT[$i]=~s/PA1\+|PA1\：|\：PA1|\:PA1|PA\:|PA//g;
		$RESULT[$i]=~s/PS5/PS/g;
		$RESULT[$i]=~s/PM7|PM8/PM/g;
		$RESULT[$i]=~s/BP8/BP/g;
		if ($RESULT[$i]=~/^$/)
		{
				$RESULT[$i]="NA";
		}elsif($RESULT[$i]=~/\:$|\：$/)
		{
				$RESULT[$i]=~s/\:$|\：$//g;
		};
	};
	return @RESULT;
};

#####################
sub get_handle
{
		my($handlefile,$pro,$raw_yuanxu,$sample_name,$out_file)=@_;

		my $jiaxihao="xxxxxxxxxxxx";
		open H,"$handlefile" or die "error:cannot open file $handlefile!!!\n";
		while(my $A=<H>)
		{
			chomp $A;
			next if($A=~/^$/ || $A=~/^\#/);
			my @arr=split/\t/,$A;
			if(!$arr[3] || $arr[3]=~/err/i || $arr[3]=~/NA/i)
			{
				
			}else
			{
				if($sample_name=~/^$arr[0]/ && ($pro eq $arr[5]))
				{
					if(length($arr[0])>=11 || $arr[0]=~/[A-Z]+/)
					{
						$jiaxihao=$arr[3];
					}else
					{
						chop $arr[3];
						$jiaxihao=$arr[3];

					};
				};
			};
		};
		close H;
		#####################
		open H1,"$handlefile" or die "error:cannot open file $handlefile !!!\n";
		open OH,">$out_file" or die "error:cannot write to file $out_file !!!\n";
		while(my $B=<H1>)
		{
			chomp $B;
			next if($B=~/^$/ || $B=~/^\#/);
			my @arrb=split/\t/,$B;
			my $jiaxi;
			if(!$arrb[3] || $arrb[3]=~/err/i || $arrb[3]=~/NA/i)
			{

			}else
			{
				if(length($arrb[0])>=11 || $arrb[0]=~/[A-Z]+/)
				{

					$jiaxi=$arrb[3];
				}else
				{
					$jiaxi=$arrb[3];
					chop $jiaxi;
				};
				if(($jiaxi eq $jiaxihao) && ($arrb[5] eq $pro))
				{
					if (!defined $raw_yuanxu || $raw_yuanxu=~/^$/)
					{
						#$raw_yuanxu="$arrb[0]";
						$raw_yuanxu="Not_in_allraw";
					};
					chomp $raw_yuanxu;
					$raw_yuanxu=~s/B$/A/;
					my $value=join"\t",@arrb[1..@arrb-1];
					print OH "$raw_yuanxu\t$value\n";
				};
			};
		};
		close H1;
		close OH;
	`mv $out_file $out_file\.bak && sort -u $out_file\.bak >$out_file`;
};
##########################################################################
sub path
{
	my ($dir)=@_;
	$dir=`readlink -f $dir`;
	chomp $dir;
	return $dir;
};
##########################################################################
sub NC2chr
{
	my $chr=(split /0{4,5}|\./,$_[0])[1];
	if ($chr eq '23')
	{
		$chr='X';
	}elsif($chr eq '24')
	{
		$chr='Y'
	};
	return "chr$chr";
};
##########################################################################
sub get_uniq
{
	my @TMP=@_;
	my (%uniq,@tmp);
	foreach my $A (@TMP)
	{
		next if(!defined $A || $A=~/^$/);
		if (not exists $uniq{$A})
		{
			push @tmp,$A;
			$uniq{$A}=1;
		};
	};
	return @tmp;
};
################################################################################
sub get_sum
{
	my $tot=0;
	foreach my $A (@_)
	{
		$tot+=$A if($A=~/\d+/);
	};
	return $tot;
};
##########################################################
sub initialize
{
	my ($file,$hash)=@_;
	open K,"$file" or die "\n\tcan not open file: $file !!!\n\n"; #######   0.读取所有配置文件与参数信息
	while (<K>)
	{
		chomp;
		next if (/^$/ || /^\#/);
		my @arr=split /\t+/,$_;
		if (!defined $arr[2])
		{
			$hash->{$arr[0]}=$arr[1];
		}else
		{
			$arr[2]=~s/\#//g;
			$hash->{$arr[0]}="$arr[1] $arr[2]";
		};
	};
	close K;
};
####################################################################
sub sh_recheck
{
	my($sh,$sh_name,$time)=@_;
	chomp $sh;
	if (!defined $time)
	{
		$time=2000;
	};
	my $return="\nlook_dog=0;\nwhile \(\(\$look_dog < $time\)\)\ndo\n";
	$return.="\t".$sh."\n";
	$return.="\tif [ \$\? == 0 ]\n\t\tthen echo \"\$\? : ".$sh_name." complete ! "."\"\n\t\tbreak\n\telse\n\t\techo \"\$\? : "."$sh_name"." work error ! "."\"\n\t\tsleep 10m \n\t\tlook_dog=\$((\$look_dog+600))\n\tfi\ndone\n\n";
	return $return;
};
####################################################################
sub file_recheck
{
	my($file_name)=@_;

	my $return="\nfile_stat=\$\(file $file_name\)\necho \"$file_name : \$file_stat\"\nif [[ \$file_stat =~ \"No such file or directory\" ]]\n\tthen echo \"error:no file $file_name\"\n\texit\nelif [[ \$file_stat =~ \"empty\" ]]\n\tthen echo \"error:$file_name is empty\"\n\texit\nelse\n\techo \"OK $file_name is not empty\"\nfi\n\n";
	return $return;
};
####################################################################
sub file_wait
{
	my($file_name,$time)=@_;
	if (!defined $time)
	{
		$time=2000;
	};
	my $return="\nlook_dog=0;\nwhile \(\(\$look_dog < $time\)\)\ndo\n\tif [ -f \"$file_name\" ]\n\t\tthen echo \"$file_name is ok, please go on !!!\"\n\t\tbreak\n\telse\n\t\techo \"sleeping:$file_name is not exists !!!\"\n\t\tsleep 120\n\t\tlook_dog=\$((\$look_dog+120))\n\tfi\ndone\n\n";
	return $return;
};
###############################################################
sub dir_bak
{
	my ($dir)=@_;
	my $return="\ntime=\$\(date\|sed \'s\/ \/\\_\/g\'\) \nif [ -d \"$dir\" ] \n\tthen mv $dir $dir\.bak.\$time\n\tmkdir -p $dir\nelse\n\tmkdir -p $dir\nfi \n\n";
	return $return;
};
###########################
sub field_match
{
	my($file,$tag,$match)=@_;
	my $return="\n\nif [[ \`less $file\|grep \^$tag\` =~ \"$match\" ]]\n\tthen echo \"error:$tag and $match in $file !!!\"\n\texit\nelse\n\techo \"$tag is ok in $file\"\nfi\n\n";
	return $return;
};
################################################################
sub dir_sge_check			#######edit by wang 20180327
{
	my @sample_dir=@_;
	my %sge;
	my %cluster;
	my $sge_only="yes";
	foreach my $tmp_dir (@sample_dir)
	{
		if($tmp_dir=~/share\/(.*?)\//)
		{
			my $data_root_dir=$1;
			if($data_root_dir=~/chigene/)
			{
				$cluster{chigene}=1
			}elsif($data_root_dir=~/ofs/)
			{
				$cluster{ofs}=1;
			}elsif($data_root_dir=~/chg2fs/)
			{
				$cluster{chg2fs}=1;
			};
		};
	};
	
	if((keys %cluster)>1)
	{
		return "no";
	}else
	{
		foreach my $tmp_dir (@sample_dir)
		{
			my $real_sge;
			if($tmp_dir=~/share\/(.*?)\//)
			{
				my $data_root_dir=$1;
				if (not exists $parameters{$data_root_dir})
				{
					print STDERR "error:can not find data in which sge !!!$tmp_dir\n\n";
					$sge_only="no";
					last;
				};
				$real_sge=$parameters{$data_root_dir};
			}else
			{
				$real_sge="error";
			};
			$sge{$real_sge}=1;
		};
		if((keys %sge)>1)
		{
			$sge_only="no";
		};
		return $sge_only;
	};
};
################################################################
sub get_dir_work_node
{
	my ($sample_dir)=@_;
	if($sample_dir=~/share\/(.*?)\//)
	{
		my $data_root_dir=$1;
		if ((not exists $parameters{$data_root_dir}) || (not exists $parameters{$parameters{$data_root_dir}}))
		{
			print STDERR "error:can not get dir work node!!!$sample_dir:$data_root_dir\n\n";
			#die;
			$sample_dir=$parameters{sge_all}; ##edit by wang 20180327
		}else
		{
			$sample_dir = $parameters{$parameters{$data_root_dir}};
		};
	}else
	{
		$sample_dir="error";
	};
	return $sample_dir;
};
#######################
sub get_protein_predict
{
	my ($score,$res)=@_;
	my $return;
	my @score=$score=~m/([\+\-\d+\.]+)/g;
		@score=grep /\d+/,@score;
	my @tag=$res=~m/([A-Z]+)/g;
	$return=$tag[0]."(".$score[0].")";
	return $return;
};
######################################################
sub xgx_trans		##########相关性说明
{
	my($origin_xgx,$acmg_path_yiju,$translation)=@_;

	my $xgx;
	if ($acmg_path_yiju=~/$translation->{acmg_PA}/)
	{
		$xgx.=$translation->{xgx_sm_1};
	}elsif($acmg_path_yiju=~/\_gain|\_loss|\_upd|\_UPD|\_SMN1|\_wild|\_CNV/)
	{
		$xgx=$origin_xgx;
	}elsif($acmg_path_yiju=~/PVS1/)
	{
		if ($acmg_path_yiju=~/PVS1a/)
		{
			$xgx.=";".$translation->{xgx_sm_2};
		}elsif($acmg_path_yiju=~/PVS1c/)
		{
			$xgx.=";".$translation->{xgx_sm_3};
		}elsif($acmg_path_yiju=~/PVS1d/)
		{
			$xgx.=";".$translation->{xgx_sm_4};
		}elsif($acmg_path_yiju=~/PVS1e/)
		{
			$xgx.=";".$translation->{xgx_sm_5};
		}elsif($acmg_path_yiju=~/PVS1f/)
		{
			$xgx.=";".$translation->{xgx_sm_6};
		}else
		{
			print STDERR "error:相关性错误,$acmg_path_yiju\n\n";
			die;
		};
	}elsif($acmg_path_yiju=~/PM8/)
	{
		$xgx.=";".$translation->{xgx_sm_7};
	};

	if ($acmg_path_yiju=~/PS2/)
	{
		$xgx.=";".$translation->{xgx_sm_11};
	};

	if ($acmg_path_yiju=~/PS1/)
	{
		$xgx.=";".$translation->{xgx_sm_9};
	}elsif($acmg_path_yiju=~/PP5/)
	{
		$xgx.=";".$translation->{xgx_sm_10};
	};
	if (!defined $xgx)
	{
		$xgx="NA";
	}else
	{
		$xgx=~s/;$|^;//g;
	};
	#######################
	$xgx=~s/PA1+|PA1：|PA:|PA//g;
	$xgx=~s/PS5/PS/g;
	$xgx=~s/PM7|PM8/PM/g;
	$xgx=~s/BP8/BP/g;
	if ($xgx=~/^$/)
	{
		$xgx="NA";
	};
	return $xgx;
};
#####################################
sub get_con_whx
{
	my ($predict,$amino,$conservation,$hot_region,$translation,$pre_MS,$con_MS)=@_;
	
	my ($sift,$polyphen_hdiv,$polyphen_hvar,$provean,$muttas,$mcap,$revel)=split /\;/,$predict;
	my $delete=0;
	my $nature=0;
	my @soft;
####($provean,$polyphen_hdiv,$polyphen_hvar,$sift,$muttas,$mcup,$revel)=split /[\|\_]/,$arr[32];
	if (defined $provean && $provean=~/D/)
	{
		$delete++;
		push @soft,"Provean";
	}elsif(defined $provean && $provean =~/\d+/)
	{
		$nature++;
	};
	if ((defined $polyphen_hdiv && $polyphen_hdiv=~/D/) || (defined $polyphen_hvar && $polyphen_hvar=~/D/))
	{
		$delete++;
		push @soft,"Polyphen2";
	}elsif((defined $polyphen_hdiv && $polyphen_hdiv=~/\d+/) || (defined $polyphen_hvar && $polyphen_hvar=~/\d+/))
	{
		$nature++;
	};
	if (defined $sift && $sift=~/D/)
	{
		$delete++;
		push @soft,"Sift";
	}elsif(defined $sift && $sift =~/\d+/)
	{
		$nature++;
	};
	if (defined $muttas && $muttas=~/^A|D/)
	{
		push @soft,"Mutationtaster";
		$delete++;
	}elsif(defined $muttas && $muttas =~/\d+/)
	{
		$nature++;
	};
	if (defined $mcap && $mcap=~/D/)
	{
		push @soft,"M-CAP";
		$delete++;
	}elsif(defined $mcap && $mcap =~/\d+/)
	{
		$nature++;
	};
	if (defined $revel && $revel=~/D/)
	{
		push @soft,"REVEL";
		$delete++;
	}elsif(defined $revel && $revel =~/\d+/)
	{
		$nature++;
	};
	###########################
	if ($delete>=2 || ($delete>=1 && $amino=~/^移码|^frameshift/))
	{
		$$pre_MS=$translation->{construnct_sm_1}."(".(join ",",@soft).")";	#######return "deleterious";
		$$con_MS="$amino".","."$$pre_MS";
	}elsif($nature>=2)
	{
		$$pre_MS=$translation->{construnct_sm_2};		##############return "neutral";
		$$con_MS="$amino".","."$$pre_MS";
	}else
	{
		$$con_MS="$amino";
	};
	if ($conservation=~/Y/ && $hot_region=~/Y/)
	{
		$$con_MS.=",".$translation->{construnct_sm_3};
	}elsif($conservation=~/Y/)
	{
		$$con_MS.=",".$translation->{construnct_sm_4};
	}elsif($hot_region=~/Y/)
	{
		$$con_MS.=",".$translation->{construnct_sm_5};
	};
};
#######################
sub get_parameters		##############&get_parameters($model,\%parameters);
{
	my ($file,$hash)=@_;
	open L,"$file" or die "\n\tcan not open file: $file !!!\n\n";
	while (<L>)
	{
		chomp;
		next if (/^$/ || /^#/);
		my ($key,$value)=split /\t+/,$_,2;
		$hash->{$key}=$value;
	};
	close L;
};
################################################################
sub read_sinfo		###############&standard_family::read_sinfo($Sinfo,\%relation);
{
	my ($info,$hash)=@_;
	open L,"$info" or die;
	while (<L>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t+/,$_;
		($arr[0])=split /xb|zj|sl|xj|\_|\s+/,$arr[0];
		$hash->{$arr[0]}{'off'}=$arr[2];		#######性别
		$hash->{$arr[0]}{'path'}=$arr[9];		#######是否患病
		$hash->{$arr[0]}{'rea'}=$arr[6];		#######样本名
		$hash->{$arr[0]}{'rel'}=$arr[10];		#######家系关系
	};
	close L;
};
#########################
sub add_blank
{
	my($old,$num)=@_;
	for(my $i=0;$i<$num;$i++)
	{
		push @{$old},"NA"
	};
};
#############################################################
sub write_out
{
	my ($out,$info)=@_;
	open OUT,">$out" or die "error:can not open file $out\n\n";
	if (!defined $info || $info=~/^$/)
	{
		print STDERR "error:$out is error !!!\n";
		die;
	};
	print OUT "$info";
	close OUT;
};

######################################################
sub read_hash
{
	my ($file,$hash,$key,$value,$type)=@_;
	if (!defined $type)
	{
		$type=1;
	};
	open L,"$file" or die "\n\tcan not open file: $file !!!\n\n";
	while (<L>)
	{
		chomp;
		next if (/^$/ || /^#/);
		my @arr=split /\t/,$_;
		#######################
		my ($VALUE,@VALUE);
		if ($value eq "0")
		{
			$VALUE=$_;
		}else
		{
			my @value_vols=split /\,/,$value;
			foreach my $vol (@value_vols)
			{
				if($vol >0)
				{
					push @VALUE,$arr[$vol-1];
				}else
				{
					push @VALUE,$arr[$vol];
				};
			};
			if(!defined $VALUE[0])
			{
				print "error:$file !\n";
				die;
			}
			$VALUE=join "\t",@VALUE;
		};
		if (!defined $VALUE)
		{
			print STDERR "\n\tfile error: $file \n\t$_\n\n";
			die;
		};
		##########################
		my @key_vols=split /\,/,$key;
		if ($type==1)
		{
			my ($KEY,@KEY);
			foreach my $vol (@key_vols)
			{
				if($vol >0)
				{
					if (!defined $arr[$vol-1])
					{
						print STDERR "\n\tfile error: $file\n\t$_\nnum:$key\n$value\n";
						die;
					};
					push @KEY,$arr[$vol-1];
				}else
				{
					if (!defined $arr[$vol])
					{
						print STDERR "\n\tfile error: $file\n\t$_\nnum:$key\n$value\n";
						die;
					};
					push @KEY,$arr[$vol];
				};
			};
			$KEY=join "\t",@KEY;
			if (!defined $KEY)
			{
				print Dumper \@KEY;
				print STDERR "\n\tfile error: $file\n\t$_\nnum:$key\n$value\n";
				die;
			};
			$hash->{$KEY}=$VALUE;
		}elsif($type==2 && @key_vols==2)
		{
			my $tmp_1;
			my $tmp_2;
			if($key_vols[0] >0)
			{
				$tmp_1=$key_vols[0]-1;
			}else
			{
				$tmp_1=$key_vols[0];
			};
			if($key_vols[1] >0)
			{
				$tmp_2=$key_vols[1]-1;
			}else
			{
				$tmp_2=$key_vols[1];
			};
			
			if (!defined $arr[$tmp_1] || !defined $arr[$tmp_2])
			{
				print STDERR "\n\tfile error: $file \n\t$_\n\n";
				die;
			};
			$hash->{$arr[$tmp_1]}{$arr[$tmp_2]}=$VALUE;
		}elsif($type==3 && @key_vols==3)
		{
			my $tmp_1;
			my $tmp_2;
			my $tmp_3;
			if($key_vols[0] >0)
			{
					$tmp_1=$key_vols[0]-1;
			}else
			{
					$tmp_1=$key_vols[0];
			};
			if($key_vols[1] >0)
			{
					$tmp_2=$key_vols[1]-1;
			}else
			{
					$tmp_2=$key_vols[1];
			};
			if($key_vols[2] >0)
			{
					$tmp_3=$key_vols[2]-1;
			}else
			{
					$tmp_3=$key_vols[2];
			};

			if (!defined $arr[$tmp_1] || !defined $arr[$tmp_2] || !defined $arr[$tmp_3])
			{
				print STDERR "\n\tfile error: $file \n\t$_\n\n";
				die;
			};
			$hash->{$arr[$tmp_1]}{$arr[$tmp_2]}{$arr[$tmp_3]}=$VALUE;
		}else
		{
			print STDERR "\n\tfile error: $file \n\t$_\n\n";
			die;
		};
	};
	close L;
};
###############################################
sub find_arr_dir
{
	my ($dir,$sample,$program)=@_;
	my @return;
	if (!defined $program)
	{
		$program="NT";
	};
	foreach my $AA (@{$sample})
	{
		if ($AA=~/err/)
		{
			push @return,"error_in_$AA";
			next;
		};
		my $BB=$AA;
		($BB)=split /xb|sl|zj|xj|\_|\s+/,$BB;
		my @tmp_dir=glob "$dir/@{[substr($AA,0,2)]}*/$BB*$program*/";
		if(@tmp_dir<1)
		{
			push @return,"error_in_$AA";
		}else
		{
			foreach my $tmp_dir (@tmp_dir)
			{
				$tmp_dir=`readlink -f $tmp_dir`;
				chomp $tmp_dir;
				push @return,$tmp_dir;
			};
		};
	};
	return @return;

};
####################
sub find_var_dir
{
	my ($dir,$sample,$program)=@_;
	if (!defined $sample)
	{
		print STDERR "error:$dir\t$sample \n";
		die;
	};
	if (!defined $program)
	{
		$program="NT01";
	};
	my ($outdir)=glob "$dir/@{[substr($sample,0,2)]}*/$sample*$program*/";
	if(!defined $outdir)
	{
		return "error";
	}else
	{
		$outdir=`readlink -f $outdir`;
		chomp $outdir;
		return $outdir;
	};
};
################################################
sub get_outname
{
	my ($od,$samples,$relation,$program,$DD_number,$all_raw)=@_;
	my $name="$od/$DD_number\_$program\_b";

	for (my $i=0;$i<@{$samples} ;$i++)
	{
		my $batch;
		if (`cut -f 1-4 $all_raw|grep $$samples[$i]|grep F|grep -E 'NT0'|tail -1|cut -f 1`)
		{
			$batch=`cut -f 1-4 $all_raw|grep $$samples[$i]|grep F|grep -E 'NT0'|tail -1|cut -f 1`;
			chomp $batch;
		}else
		{
			$batch=`cut -f 1-4 $all_raw|grep $$samples[$i]|grep -E 'NT0'|tail -1|cut -f 1`;
			chomp $batch;
		};
		if(!defined $batch)
		{
			print "error:$$samples[$i]\n$all_raw\n";
			die;
		};
		$name.="$batch"."A";
	};
#	print Dumper \@{$samples};
#	print Dumper \%{$relation};

	if (@{$samples}==3 && exists $relation->{son} && exists $relation->{father} && exists $relation->{mother})
	{
		$name.="_Trios_acmg2.0.xlsx";
	}elsif(@{$samples}==3 && exists $relation->{daughter} && exists $relation->{father} && exists $relation->{mother})
	{
		$name.="_Trios_acmg2.0.xlsx";
	}else
	{
		$name.="_unTrios_acmg2.0.xlsx";
	};
	my $txt_name=$name;
	$txt_name=~s/xlsx$/txt/;
	return ($txt_name,$name);
};
###########################################################
sub get_level
{
	my ($ms)=@_;
	my $return;
	if ($ms=~/Pathogenic/)
	{
		$return=1;
	}elsif ($ms=~/pathogenic/)
	{
		$return=2;
	}elsif($ms=~/Uncertain/)
	{
		$return=3;
	}elsif ($ms=~/benign/)
	{
		$return=4;
	}elsif ($ms=~/Benign/)
	{
		$return=5;
	}else
	{
		$return="error";
	};
	return $return;
};
#############################################################
sub read_annoation
{
	my ($file,$hash,$type)=@_;
	open L,"$file" or die "\n\tcan not open file: $file !!!\n\n";
	$/=">####";
	<L>;
	while (<L>)
	{
		chomp;
		next if (/^$/ || /^#/);
		my ($head,$anno)=split /\n/,$_,2;
		my @arr=split /\t/,$head;
		my $KEY;
		if ($type=~/MUTE/)
		{
			$KEY=$arr[5];
		}elsif($type=~/GENE/)
		{
			$KEY=$arr[0];
		}elsif($type=~/AMINO/)
		{
			next if($arr[1] eq "NA");
			$KEY="$arr[3]|$arr[0]|$arr[2]|$arr[1]";
		}else
		{
			print STDERR "type error:$_\n\n";
			die;
		};
		my $VALUE=$anno;
		if (!defined $KEY || !defined $VALUE)
		{
			print STDERR "infor_error:$file\n\t$_\n";
			die;
		};
		$hash->{$KEY}=$VALUE;
	};
	$/="\n";
	close L;
};
##########################################
sub get_mut_compile
{
	my ($mut)=@_;
	my ($chr,$start,$end,$ref,$alt)=split /\_/,$mut;
	my @tmp;
	push @tmp,$chr,$start,$end,$ref,$alt;
	if ($ref=~/-/)
	{
		push @tmp,"D";
	}elsif($alt=~/-/)
	{
		push @tmp,"D";
	}else
	{
		push @tmp,"S";
	};
	return @{[join "_",@tmp]};
};

#######################################
sub get_base_seq
{
	my ($pos,$genenome)=@_;
	my $seq=`$samtools faidx $genenome $pos|grep -v chr`;
	$seq=~s/\s+//g;
	return $seq;
};
###############################################################################################
sub get_effec_num
{
	my ($a,$res)=@_;
	$a=~s/^ | $//g;
	if ($a=~/^(\d+)\.0+$/)
	{
		$res=$1;
		return $res;
	}elsif ($a=~/^(\d+\.)(0*)(\d+)$/)
	{
		my $bef=$1;
		my $zero=$2;
		my $aft=$3;
		if ($aft==0)
		{
			$zero.=0;
			$aft="";
		};
		my ($tmptwo,$three);
		if (length($aft)>=3)
		{
			$tmptwo=substr($aft,0,2);
			$three=substr($aft,2,1);
			if ($three>=5) {++$tmptwo};
			if (length $tmptwo>2)
			{
				if (defined $zero && $zero=~/0$/)
				{
					$zero=~s/0$//;
					$res=$bef.$zero.$tmptwo;
				}else
				{
					$bef="1.";
					$tmptwo=~s/^\d//;
					$res=$bef.$zero.$tmptwo;
				};
			}else
			{
				$res=$bef.$zero.$tmptwo;
			};
		}elsif(length($aft)>0)
		{
			$tmptwo=$aft;
			while (length($tmptwo)<2)
			{
				$tmptwo.=0;
			};
			$res=$bef.$zero.$tmptwo;
		}else
		{
			$res=$bef;
			$res=~s/\.$//;
		};
		while ($res=~/0$|\.$/)
		{
			$res=~s/0$|\.$//g;
		};
		if ($res=~/^$/)
		{
			$res=0;
		};
		return $res;
	}else
	{
		$res=$a;
		return $res;
	};
};
######################################################
##########################################################################
sub read_all_raw
{
	my($all_raw,$hash)=@_;
	open L,"$all_raw" or die"error:can not open file $all_raw !!!\n";
	while (<L>)
	{
		chomp;
		next if(/^$/);
		next if($_!~/^\d+/);
		my ($batch,$sample,$prog,$chip,$sex,$fq,$lib,$info_add)=split /\t/,$_;
		##################
		$hash->{$sample}{batch}=$batch;
		$hash->{$sample}{prog}=$prog;
		$hash->{$sample}{chip}=$chip;
		$hash->{$sample}{sex}=$sex;
		$hash->{$sample}{fq}=$fq;
		$hash->{$sample}{lib}=$lib if(defined $lib);
		$hash->{$sample}{info_add}=$info_add if(defined $info_add);
	};
	close L;
};


sub get_fam_relative
{
	my ($conf_file,$number,$stdout)=@_;
	my %info;
	&read_all_raw($conf_file,\%info);
	###################
	my $ID=(split /xb|sl|zj|xj/,$number)[0];
	my $od=dirname($stdout);
	my $outfile="$od/$ID\_origin.txt";
	if (exists $info{$number})
	{
		if ((exists $info{$number}{chip}) && $info{$number}{chip}=~/NT/ && (exists $info{$number}{info_add}))
		{
			`wget -O $outfile -P ./ http://sample.zhiyindongfang.com/sample-app/desktop/sale/SpecialExam/findSpecialExamList.action?taskCode=$info{$number}{info_add}`;
		}elsif((exists $info{$number}{chip}) && $info{$number}{chip}=~/NT/ && (exists $info{$number}{prog}))
		{
			`wget -O $outfile -P ./ http://sample.zhiyindongfang.com/sample-app/desktop/sale/SpecialExam/findSpecialExamList.action?taskCode=$ID\_$info{$number}{prog}`;
		}else
		{
			print STDERR "$number program maybe error ?\n";
			return 0;
		};
	}else
	{
		print "$number not in ALL_RAW \n";
		return 0;
	};

	my $jsfile="$od/$ID\_json.txt";
	&read_js($outfile,$jsfile);

	my @springs=split /\n/,`grep -v callName $jsfile`;

	open OUT,">$stdout" or die;
	my $i=1;
	foreach (@springs)
	{
		chomp $_;
		my @result;
		my @arr=split /\t/,$_;
		my $id=$arr[-1];
		my $realnumber;
		if (`cut -f 1-4 $conf_file|grep $id|tail -1|cut -f 1`)
		{
			$realnumber=`cut -f 1-4 $conf_file|grep $id|tail -1|cut -f 2`;
			chomp $realnumber;
			if ($info{$number}{prog} ne $info{$realnumber}{prog})
			{
				print STDERR "$id not the same program ! \n";
				next;
			};
			push @result,$realnumber,$arr[1];
		}else
		{
			push @result,$id,$arr[1],"error:$id not in ALL_RAW";
			print STDERR "$id not in ALL_RAW !\n";
			next;
		};

		if ($arr[5]=~/女/)
		{
			push @result,'FM';
		}elsif($arr[5]=~/男/)
		{
			push @result,'M';
		}else
		{
			my $two=substr($id,0,2);
			my $sex_file=(glob "/share/ofs1a/prod/sample/$two*/$id*/4.1_QC/QC_report.txt")[0];
			if (!$sex_file || !-f $sex_file)
			{
				print STDERR "$id\tno_sex\n";
				push @result,'FM';
#				die;
			}else
			{
				if (`less $sex_file|grep sex` =~/XX/)
				{
					push @result,'FM';
				}elsif(`less $sex_file|grep sex` =~/XY/)
				{
					push @result,'M';
				}else
				{
					print STDERR "$id\tno_sex\n";
					die;
				};
			};
		};
		push @result,$arr[4],$arr[4],$arr[3];
		
		my $relate='NA';
		if (($arr[0] eq '先证者') || ($arr[0] eq 'NA'))
		{
			if ($result[2] eq 'M')
			{
				push @result,"先证者男";
				$relate='son';
			}else
			{
				push @result,"先证者女";
				$relate='daughter';
			};
		}elsif($arr[0] eq "父")
		{
			push @result,$arr[0].$arr[2];
			$relate='father';
		}elsif($arr[0] eq "母")
		{
			push @result,$arr[0].$arr[2];
			$relate='mother';
		}else
		{
			push @result,"成员$i\-$arr[0]".$arr[2];
			$i++;
			##################
			if ($arr[0]=~/兄|弟|姐|妹/)
			{
				if($arr[2]=~/患者|轻微表型/)
				{
					if ($result[2] eq 'FM')
					{
						$relate='daughter';
					}elsif($result[2] eq 'M')
					{
						$relate='son';
					};
				}else
				{
					$relate='other';
				};
			}else
			{
				$relate='other';
			};
		};
		push @result,$arr[1];

		if ($arr[2]=~/患者/)
		{
			push @result,"患者","4";
		}elsif($arr[2]=~/轻微表型/)
		{
			push @result,"轻微表型","2";
		}elsif($arr[2]=~/正常/)
		{
			push @result,"正常","0";
		}elsif($arr[2]=~/其它表型/)
		{
			push @result,"正常","0";
		};
		push @result,$relate;

		my $res=join "\t",@result;
		print OUT "$res\n";
	};
	close OUT;
};
#########################################
#########################################
sub read_js
{
	my($js_file,$outfile)=@_;
	#################
	my $js;
	open L,"$js_file" or die "\n\t:no_file:$js_file\n";
	while(<L>) 
	{
		$js .= "$_";
	};
	close L;
	#################
	open OUT,">$outfile" or die;
	my $obj = new JSON ->decode($js);
	my @head=("callName","checkerName","disease_condition","examCode","family_code","gender","member_sequence","report_code","resource_code");
	print OUT (join "\t",@head),"\n";
	foreach my $key1 (sort keys %{$obj})
	{
		next if (ref($obj->{$key1}) ne "ARRAY");
		for(my $num=0; $num<@{$obj->{$key1}}; $num++)###(0..@{$obj->{$key1}})
		{
			if ((ref($obj->{$key1}[$num]) eq 'HASH'))
			{
				foreach my $key2 (@head)
				{
					if(not exists $obj->{$key1}[$num]{$key2})
					{
						$obj->{$key1}[$num]{$key2}="NA";
					};
					print OUT "$obj->{$key1}[$num]{$key2}\t";
				};
			};
			print OUT "\n";
		};
	};
	close OUT;
};
##########################################################################

###############################################################################################
#
#以下是统计部分
#
###############################################################################################
sub get_gene_cov_dep
{
	my ($cov_dep_file,$hash,%result)=@_;
	open L,"$cov_dep_file" or die"$!";
	while(<L>)
	{
		chomp;
		next if /^$/;
		my @array=split;
		my $gene=$array[4];
		next if (!$gene);
		$result{$gene}{'cover_length'}+=(split /\//,$array[-2])[0];
		$result{$gene}{'length'}+=(split /\//,$array[-2])[1];
		$result{$gene}{'depth'}+=(split /\//,$array[-4])[0];
	};
	close L;
	foreach my $A(keys %result)
	{
		my $coverage=$result{$A}{'cover_length'}/$result{$A}{'length'};
		my $average=$result{$A}{'depth'}/$result{$A}{'length'};
		$hash->{$A}="$coverage\t$average";
	};
};
###############################################################################################
sub get_nX_ratio	#######&exon::get_gene_10X_cov($bed_depth,\%gene_bed,\%cov_dep,\%genecov_10X);
{
	my ($gene,$depth,$out,$hash)=@_;
	my($totlen,$totdepth,%totpoint);
	open L,"$depth" or die;
	open M,"> $out\.tmp1.bed" or die;
	while (my $DEPTH=<L>)
	{
		chomp $DEPTH;
		next if ($DEPTH=~/^$/);
		my @array=split /\t/,$DEPTH;
		my $start=$array[1]-1;
		print M "$array[0]\t$start\t$array[1]\t$array[2]\n";
	};
	close L;
	close M;
	############################################
	open N,"$gene" or die;
	open Z,"> $out\.tmp2.bed" or die;
	while (<N>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		$totlen+=$arr[2]-$arr[1];
		print Z "$arr[0]\t$arr[1]\t$arr[2]\n";
	};
	close N;
	close Z;
	`bedtools window -a $out\.tmp2.bed -b $out\.tmp1.bed -w 0 >$out\.tmp.result.bed`;
	###############################################
	open K,"$out\.tmp.result.bed" or die;
	while (<K>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		++$totpoint{$arr[6]};
		$totdepth+=$arr[6];
	};
	close K;
	foreach my $num (1,2,5,10,20,30)
	{
		my $point=0;
		foreach my $dep (sort {$b <=> $a} keys %totpoint)
		{
			last if ($dep<$num);
			$point+=$totpoint{$dep};
		};
		$hash->{$num}=$point/$totlen;
	};
	$hash->{ave}=$totdepth/$totlen;
	`rm $out\.tmp*`;
};
###################################################################################
###############################################################################################
sub get_UPD
{
	my ($infile,$outfile)=@_;
	my ($filter_dep,$filter_rat,$homo,%depth,%uniq,%chr_cnv)=(10,0.3,0.85);
	############################################
	my $chrcnv=$infile;
	$chrcnv=~s/3.3_variation_annotation\/tot_5_level.report.txt/5.2_EXON_deletion\/chr_cnv.txt/;
	open K,"$chrcnv" or die;
	<K>;
	while (<K>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		$chr_cnv{$arr[0]}=$arr[-1];
	};
	close K;
	#############################
	my $sexQC=$infile;
	$sexQC=~s/3.3_variation_annotation\/tot_5_level.report.txt/4.1_QC\/QC_report.txt/;
	$sexQC=`less $sexQC|grep ^sex_test`;chomp $sexQC;
	#############################
	open L,"$infile" or die;
	open M,">$outfile" or die;
	<L>;
	while (<L>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		if (exists $uniq{$arr[4]})
		{
			next;
		}else
		{
			$uniq{$arr[4]}=1;
		};
		my $chr=(split /\:/,$arr[4])[0];
		my @depth=split /[:=;\/]/,$arr[22];
		next if($depth[-2]<$filter_dep || $depth[-3]<$filter_rat);
		if ($depth[0]!~/Hemi/)
		{
			if ($depth[-3]>$homo)
			{
				$depth{$chr}{homo}+=1;
			}else
			{
				$depth{$chr}{hete}+=1;
			};
		}else
		{
			$depth{$chr}{hemi}+=1;
		};
	};
	close L;
	foreach my $key (sort keys %depth)
	{
		my $cnv='NA';
		if (exists $chr_cnv{$key}){$cnv=$chr_cnv{$key}};

		if (not exists $depth{$key}{hemi}) 
		{
			if (not exists $depth{$key}{homo}) {$depth{$key}{homo}=0};
			if (not exists $depth{$key}{hete}) {$depth{$key}{hete}=0};
			my $ratio=$depth{$key}{homo}/($depth{$key}{hete}+$depth{$key}{homo});
			$ratio=sprintf("%.4f",$ratio);
			print M "$key\t$depth{$key}{homo}\t$depth{$key}{hete}\t$ratio";
			if ($sexQC=~/YES/)
			{
				if ($cnv ne 'NA')
				{
					print M "\t$cnv\n";
				}elsif($ratio>0.8)
				{
					print M "\tUPD\n";
				}else
				{
					print M "\n";
				};
			}else
			{
				print M "\tsex_err\n";
			
			};
		}else
		{
			print M "$key\tHemi\t$depth{$key}{hemi}\t$cnv\n";
		}
	};
	close M;
};
