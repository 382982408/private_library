#!/usr/bin/perl -w
use strict;
use Cwd;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);
use lib "$Bin/models/";
use standard_family;
use exon;
###########################################################################Start_Time
my %parameters;
my $file="$Bin/../db/Z_lzw_database/CONFIG_ALL.txt";
&exon::initialize($file,\%parameters);

my $qsub="$Bin/../bin/qsub_for_master_2017-06-14.pl";
my %hash;
$hash{link}="no";
$hash{del}="no";
$hash{step}=1;
$hash{run}="no";
$hash{interval}="0h";
$hash{recov}="no";
$hash{h_cov}="yes";
$hash{sd}="no";

GetOptions
(
	"conf=s"=>\$hash{conf},
	"batch=s{,}"=>\@{$hash{batch}},
	"step=s"=>\$hash{step},
	"link=s"=> \$hash{link},
	"del=s" => \$hash{del},
	"run=s"=> \$hash{run},
	"interval=s"=> \$hash{interval},
	"sample=s"=> \$hash{sample},
	"recov=s"=> \$hash{recov},
	"sd=s"=> \$hash{sd},
	"h_cov=s"=>\$hash{h_cov},
);

###############
if(!$hash{conf} || !$hash{batch} || (@{$hash{batch}}<1 && !$hash{sample}))
{
	print STDERR 
"
	perl $0
	-conf		<essential>: conf.txt
	-batch		<essential>: 901 902 903
	-sample		<unessential>: sample_list.txt
	-sd		<unessential>: is the stat directory ispecified ?
	-link		<unessential>: to link the out_directory to \"/share/ofs1a/prod/sample/\" ? (default:no)
	-del		<unessential>: weather to delete the clean data ? (default:no|yes|predell)
	-run		<unessential>: to start this work ? (default:no)
	-interval	<unessential>: interval between the two tasks (default:0h)
	-recov		<unessential>: whether to delete the previous delivery record or not ! (default:no)
	-h_cov		<unessential>: wheather to cover the handle info ?
	-step		<unessential>: to specify the begening of the pipline (default:1)
			1:	start_from_raw_data
			2:	start_from_clean_data
			3:	start_from_stat
			4:	start_from_bam
			5:	start_from_vcf
			6:	start_from_qc
";
	exit;
};

#########################################
#################
my $tumour_NT01T_file=$parameters{D90};
my %tumour;
&exon::read_hash($tumour_NT01T_file,\%tumour,2,2);
print Dumper \%tumour;


############
my %sample;

if (exists $hash{batch} && @{$hash{batch}}>0 && defined $hash{sample})
{
	print STDERR "\n\tThe two parameters cannot be used at the same time: batch and sample !!!\n\n";
	exit;
}elsif (exists $hash{batch} && @{$hash{batch}}>0)
{
	my %BATCH;
	foreach(@{$hash{batch}})
	{
		$BATCH{$_}=1
	};
	#########
	open L,"$hash{conf}" or die "\n\t$hash{conf} ???\n";
	while (<L>)
	{
		chomp;
		next if(/^$|^\#|^batch/);
		my @arr=split /\t/,$_;
		next if (!defined $arr[0]);
		next if($arr[3]!~/NT01|NT09|NT02|NXBJS/);
		next if(exists $tumour{$arr[2]});		#######add_by_lzw_20180426

		next if(not exists $BATCH{$arr[0]});
		if (exists $sample{$arr[1]}{$arr[3]})
		{
			delete $sample{$arr[1]}{$arr[3]};
		};
		$sample{$arr[1]}{$arr[3]}{$arr[0]}=1;
	};
	close L;
}elsif(defined $hash{sample})
{
	my %SAMPLE;
	open L,"$hash{sample}" or die "no file $hash{sample} !!!\n\n\n";
	while (<L>)
	{
		chomp;
		next if(/^$/);
		my @arr=split /\t/,$_;
		$SAMPLE{$arr[0]}=1;
	};
	close L;
	#########
	open L,"$hash{conf}" or die "\n\t$hash{conf} ???\n";
	while (<L>)
	{
		chomp;
		next if(/^$|^\#|^batch/);
		my @arr=split /\t/,$_;
		next if (!defined $arr[0]);
		next if($arr[3]!~/NT01|NT09|NT02|NXBJS/);
		next if(exists $tumour{$arr[2]});		#######add_by_lzw_20180426

		next if(not exists $SAMPLE{$arr[1]});
		if (exists $sample{$arr[1]}{$arr[3]})
		{
			delete $sample{$arr[1]}{$arr[3]};
		};
		$sample{$arr[1]}{$arr[3]}{$arr[0]}=1;
	};
	close L;
}else
{
	print STDERR "\n\tparameters error !!! \n";
	die;
};

if (defined $hash{od})
{
	if (-d $hash{od})
	{
		$hash{od}=`readlink -f $hash{od}`;
		chomp $hash{od};
	};
};

#print Dumper \%sample;
#die;

#############################  edit by wang
my $hostname=`hostname`; chomp $hostname;
my $sge_master=$parameters{sge_master};
if ($hostname ne $sge_master)
{
	print STDERR "\n\tPlease turn to the master node !!!\n\n";
	die;
};
#########################
my $orgin_bed="$Bin/../db/K_cap_bed";
my $writesh="$Bin/0.write_WES_pipline_shell.v1.pl";
#########################

my %data;
my %fq;

open L,"$hash{conf}" or die "\n\t$hash{conf} ???\n";
while (<L>)
{
	chomp;
	next if(/^$|^\#|^batch/);
	my @arr=split /\t/,$_;
	next if (!defined $arr[0]);
	next if($arr[3]!~/NT01|NT09|NT02|NXBJS/);
	next if(exists $tumour{$arr[2]});		#######add_by_lzw_20180426

	next if(not exists $sample{$arr[1]}{$arr[3]});

	next if($arr[5] eq 'NA');
	my @fqs=glob "$arr[5]/*gz";
	if(@fqs==0)
	{
		print STDERR "\n\t no fastq: $_\n";
		die;
	}elsif(@fqs%2!=0)
	{
		print STDERR "\n\tfq not in pair:\t$_\n";
		die;
	};
	my($fq1,$fq2);
	my $fq_err;

	for(my $i=0;$i<@fqs-1;$i+=2)
	{
		$fq1.="$fqs[$i] ";
		$fq2.="$fqs[$i+1] ";
		$fqs[$i]=`readlink -f $fqs[$i]`;chomp $fqs[$i];
		$fqs[$i+1]=`readlink -f $fqs[$i+1]`;chomp $fqs[$i+1];
		my $fq1_data=`du -sh $fqs[$i]|cut -f 1`;chomp $fq1_data;
		my $fq2_data=`du -sh $fqs[$i+1]|cut -f 1`;chomp $fq2_data;
		foreach my $A ($fq1_data,$fq2_data)
		{
			if($A=~/G/)
			{
			}elsif($A=~/M/)
			{
				$fq_err.="\tfq_error???\t$A:$fqs[$i]\n";
			}else
			{
				$fq_err.="\tfq_error???\t$A:$fqs[$i]: work_die \n";
			};
		};
		push @{$fq{$arr[1]}{$arr[2]}{fq1}},$fqs[$i];
		push @{$fq{$arr[1]}{$arr[2]}{fq2}},$fqs[$i+1];
	};
	if(defined $fq_err)
	{
		print STDERR "$_\n$fq_err\n";
		if ($fq_err=~/work_die/)
		{
			next;
		};
	};

	next if( not exists $sample{$arr[1]}{$arr[3]}{$arr[0]});


	$arr[2]=~s/\s+//g;
	$arr[3]=~s/\s+//g;
	$arr[4]=~s/\s+//g;
	$data{$arr[0]}{$arr[1]}{$arr[3]}{prog}=$arr[2];
	$data{$arr[0]}{$arr[1]}{$arr[3]}{bed}=$arr[3];
	$data{$arr[0]}{$arr[1]}{$arr[3]}{sex}=$arr[4];
	$data{$arr[0]}{$arr[1]}{$arr[3]}{fq_dir}=$arr[5];
	if (!defined $arr[6])
	{
		$arr[6]=$arr[1];
	};
	$data{$arr[0]}{$arr[1]}{$arr[3]}{DD}=$arr[6];

	my $fq_dir;
	if($arr[5]=~/share\/(.*?)\//)
	{
		my $data_root_dir=$1;
		if (not exists $parameters{$data_root_dir})
		{
			print STDERR "error:can not find data in which sge !!!$arr[5]\n\n";
			die;
		};
		my $real_sge=$parameters{$data_root_dir};
		if(exists $data{$arr[0]}{sge} && ($data{$arr[0]}{sge} ne $real_sge))
		{
				print STDERR "$arr[0]\tdata_in_diff_queue !!!";
				die;
		};
		$data{$arr[0]}{sge}=$real_sge;
		$data{$arr[0]}{od}="/share/$data_root_dir/prod/run/";
	}else
	{
		print STDERR "error:can not find data in which sge !!!$arr[5]\n\n";
		die;
	};

};
close L;

#print Dumper \%fq;
#die;
#######################################

my $time=&datetime;
$time=~s/ /\_/g;
#my $tmpsh="/share/ofs1a/prod/Production_log/date_$time\_work.sh";
my $tmpsh="/share/chg2master/prod/Production_log/date_$time\_work.sh";

open OUT,">$tmpsh" or die;
foreach my $batch (sort keys %data)
{
	my $batchID="$data{$batch}{od}/b$batch";
	my $tot_sh="$batchID/b$batch\_work.sh";

	if($hash{recov} ne "no")
	{
		`rm -rf $batchID/b$batch\_*qsub `;
	};

	my $tot_exonsh="$batchID/b$batch\_exon_work.sh";
	my $tot_exon_fam_sh="$batchID/b$batch\_exon_fam_work.sh";
	my $fresh_report_sh="$batchID/b$batch\_report_fresh.sh";
	`mkdir -p $batchID`;
	open Z,">$tot_sh" or die "\n\tHave permission? \n\n";
	open E,">$tot_exonsh" or die;
	open R,">$fresh_report_sh" or die;
	foreach my $sam(sort keys %{$data{$batch}})
	{
		next if($sam=~/od|sge/);
		foreach my $bed (sort keys %{$data{$batch}{$sam}})
		{
				my $ID="$batchID/$data{$batch}{$sam}{$bed}{bed}/$sam\_$data{$batch}{$sam}{$bed}{prog}\_$data{$batch}{$sam}{$bed}{bed}";
				`mkdir -p $ID`;

				open(W,">$ID/conf.txt") or die "\n\t$ID\t$sam ???\n\n";
				foreach my $para (keys %parameters)
				{
					print W "$para\t\t$parameters{$para}\n" if($para=~/filter/);
				};
				print W "\nSNP_call_T\t\tHaplotypeCaller\n";
			
				my $BED=$bed;
				my $PROG=$data{$batch}{$sam}{$bed}{prog};

					if($bed=~/NT01M/)
					{
							$bed="NT01M";
					}elsif($bed=~/NT01T/)
					{
							$bed="NT01T";
					}elsif($bed=~/NT01/)
					{
							$bed="NT01";
					}elsif($bed=~/NT02A-Nc/)
					{
							$bed="NT02A-Nc";
					}elsif($bed=~/NT02/)
					{
							$bed="NT02A";
					}elsif($bed=~/NT09P/)
					{
							$bed="NT09P";
					}elsif($bed=~/NT09/)
					{
							$bed="NT09";
					}elsif($bed=~/NXBJS/)
					{
							$bed="NXBJS";
					};

				my $capbed="$bed\_cap.bed";
				my $tarbed="$bed\_target.bed";
				my $depbed="$bed\_dep.bed";
				my $varbed="$bed\_var.bed";
				foreach my $tmp_bed ($capbed,$tarbed,$depbed,$varbed)
				{
					if (!-f "$orgin_bed/$tmp_bed")
					{
						print STDERR "\n\t$sam\t$data{$batch}{$sam}{$BED}{bed}\t$tmp_bed ???";
						die;
					}else
					{
						$tmp_bed="$parameters{T3}/K_cap_bed/$tmp_bed";
					};
				};

				print W "\ncap_bed\t\t$capbed\n";
				print W "target_bed\t\t$tarbed\n";
				print W "dep_bed\t\t$depbed\n";
				print W "var_bed\t\t$varbed\n";

				print W "sample_id\t\t$sam\_$data{$batch}{$sam}{$BED}{prog}\_$data{$batch}{$sam}{$BED}{bed}\n";
				print W "DD_number\t\t$data{$batch}{$sam}{$BED}{DD}\n";
				print W "batch\t\t$batch\n";
				print W "sex\t\t$data{$batch}{$sam}{$BED}{sex}\n";
				
				my $fq1_dz;
				my $fq2_dz;
				my %fq_uniq;
				my $fq_dir=$data{$batch}{$sam}{$BED}{fq_dir};

				foreach my $tmp_fq (&get_uniq(@{$fq{$sam}{$PROG}{fq1}}))
				{
					my $fastq_name=basename $tmp_fq;
					if (!-f "$fq_dir/$fastq_name")
					{
						print STDOUT "copy fastq:\tcp $tmp_fq $fq_dir & \n";
						if (!-d $fq_dir)
						{
							`mkdir -p $fq_dir`;
						};
						`cp $tmp_fq $fq_dir &`;
					};
					next if(exists $fq_uniq{"$fq_dir/$fastq_name"});
					$fq1_dz.="$fq_dir/$fastq_name ";
					$fq_uniq{"$fq_dir/$fastq_name"}=1;
				};
				foreach my $tmp_fq (&get_uniq(@{$fq{$sam}{$PROG}{fq2}}))
				{
					my $fastq_name=basename $tmp_fq;
					if (!-f "$fq_dir/$fastq_name")
					{
						print STDOUT "copy fastq:\t cp $tmp_fq $fq_dir & \n";
						`cp $tmp_fq $fq_dir &`;
					};
					next if(exists $fq_uniq{"$fq_dir/$fastq_name"});
					$fq2_dz.="$fq_dir/$fastq_name ";
					$fq_uniq{"$fq_dir/$fastq_name"}=1;
				};

				print W "fq1\t\t$fq1_dz\n";
				print W "fq2\t\t$fq2_dz\n";
				close W;

				print STDOUT "\t\t$ID\n";

				`perl $writesh -conf  $ID/conf.txt  -od $ID -step $hash{step} -link $hash{link} -del $hash{del} -sd $hash{sd} -cov $hash{h_cov}`;

				print Z "sh $ID/$parameters{DIR1}/run.sh 1\>$ID/$parameters{DIR2}/run.sh.out 2\>$ID/$parameters{DIR3}/run.sh.err \n";
				print E "sh $ID/$parameters{DIR1}/run_exon.sh 1\>$ID/$parameters{DIR2}/run_exon.sh.out 2\>$ID/$parameters{DIR3}/run_exon.sh.err \n";
				print R "sh $ID/$parameters{DIR1}/report_work.sh 1\>$ID/$parameters{DIR2}/report_work.sh.out 2\>$ID/$parameters{DIR3}/report_work.sh.err \n";
		};
	};
	close Z;
	close E;
	close R;
	`mv $tot_sh $tot_sh.bak && sort -u $tot_sh.bak >$tot_sh && rm $tot_sh.bak`;
	`mv $tot_exonsh $tot_exonsh.bak && sort -u $tot_exonsh.bak >$tot_exonsh && rm $tot_exonsh.bak`;
	`mv $fresh_report_sh $fresh_report_sh.bak && sort -u $fresh_report_sh.bak >$fresh_report_sh && rm $fresh_report_sh.bak`;

	my $num=`cat $tot_sh|wc -l`;
	chomp $num;
	next if($num<1);
	###################
	my $report_time_date=`date`;
	my @report_time_data=$report_time_date=~m/(\d+)/g;
	my $report_time=join "",@report_time_data[0..2];
	
	
		open K,">$batchID/b$batch\_qsub.sh" or die;
		if (not exists $data{$batch}{sge})
		{
				print STDERR "$batch\tsge\t\n";
				die;
		};

		if (not exists $hash{"$data{$batch}{sge}\_interval"})
		{
			if($hash{step}>6)
			{
				print K "sleep 5s \n";
				print K "ssh $parameters{sge_all} \'sh $tot_exonsh \' &\n";   ####exit by wang 20180327
				print K "wait\n";
				print K "perl $qsub --queue $data{$batch}{sge} --wait 180 --interval 180 --maxproc 20 --Check no --independent yes $fresh_report_sh 1>$fresh_report_sh.out 2>$fresh_report_sh.err &\n";
				print K "wait\n";
				print K "ssh $parameters{sge_all} \'perl $Bin/Bin/genetic_audit_reports_for_master.pl -batch $batch \' &\n"; ####exit by wang 20180327
				print K "wait\n";
			}else
			{
				print K "sleep 5s \n";
				print K "perl $qsub --queue $data{$batch}{sge} --wait 180 --interval 180 --maxproc 20 --Check no --independent yes $tot_sh 1>$tot_sh.out 2>$tot_sh.err &\n";
				print K "wait \n";
				print K "ssh $parameters{sge_all} \'sh $tot_exonsh \' &\n";
				print K "wait \n";
				print K "perl $qsub --queue $data{$batch}{sge} --wait 60 --interval 60 --maxproc 20 --Check no --independent yes $fresh_report_sh 1>$fresh_report_sh.out 2>$fresh_report_sh.err &\n";
				print K "wait\n";
				print K "ssh $parameters{sge_all} \'perl $Bin/Bin/genetic_audit_reports_for_master.pl -batch $batch \' &\n";
				print K "wait\n";
			};
					$hash{"$data{$batch}{sge}\_interval"}=$hash{interval};
		}else
		{
			if($hash{step}>6)
			{
				print K "sleep ".$hash{"$data{$batch}{sge}\_interval"}."\n";
				print K "ssh $parameters{sge_all} \'sh $tot_exonsh \' &\n";     ####edit by wang 20180327
				print K "wait\n";
				print K "perl $qsub --queue $data{$batch}{sge} --wait 180 --interval 180 --maxproc 20 --Check no --independent yes $fresh_report_sh 1>$fresh_report_sh.out 2>$fresh_report_sh.err &\n";
				print K "wait\n";
				print K "ssh $parameters{sge_all} \'perl $Bin/Bin/genetic_audit_reports_for_master.pl -batch $batch \' &\n";
				print K "wait\n";
			}else
			{
				print K "sleep ".$hash{"$data{$batch}{sge}\_interval"}."\n";
				print K "perl $qsub --queue $data{$batch}{sge} --wait 180 --interval 180 --maxproc 20 --Check no --independent yes $tot_sh 1>$tot_sh.out 2>$tot_sh.err &\n";
				print K "wait \n";
				print K "ssh $parameters{sge_all} \'sh $tot_exonsh \' &\n";
				print K "wait\n";
				print K "perl $qsub --queue $data{$batch}{sge} --wait 60 --interval 60 --maxproc 20 --Check no --independent yes $fresh_report_sh 1>$fresh_report_sh.out 2>$fresh_report_sh.err &\n";
				print K "wait\n";
				print K "ssh $parameters{sge_all} \'perl $Bin/Bin/genetic_audit_reports_for_master.pl -batch $batch \' &\n";
				print K "wait\n";
			};

				my $dt=$hash{"$data{$batch}{sge}\_interval"};
					$dt=~s/\D+$//g;
				my $dw=$hash{"$data{$batch}{sge}\_interval"};
					$dw=~s/[\d\.]+//g;
				my $ad=$hash{interval};$ad=~s/\D+$//g;
						$dt+=$ad;
				$hash{"$data{$batch}{sge}\_interval"}="$dt"."$dw";
		};
		close K;

	print OUT "sh $batchID/b$batch\_qsub.sh & \n";
};

close OUT;

if($hash{run} ne "no")
{
	print STDOUT "sh $tmpsh \n";
	`sh $tmpsh `;
}else
{
	print STDOUT "no sh $tmpsh \n";
};

#############################
sub initialize
{
        my ($file,$hash)=@_;
        open K,"$file" or die; #######   0.��ȡ���������ļ��������Ϣ
        while (<K>)
        {
                chomp;
                next if (/^$/ || /^\#/);
                my @arr=split /\t/,$_;
                if (!defined $arr[2])
                {
                        $hash->{$arr[0]}=$arr[1];
                }else
                {
                        $hash->{$arr[0]}="$arr[1] $arr[2]";
                };
        };
        close K;
};


sub datetime{#Time calculation subroutine
                my @arr=localtime ();
        my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @arr;
        $wday = $yday = $isdst = 0;
        sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
};

sub get_uniq
{
        my @TMP=@_;
        my (%uniq,@tmp);
        foreach my $A (@TMP)
        {
                if (not exists $uniq{$A})
                {
                        push @tmp,$A;
                        $uniq{$A}=1;
                };
        };
        return @tmp;
};
