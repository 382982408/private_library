#!/usr/bin/perl -w
use strict;
use Cwd;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);
use lib "$Bin/9.0_models/";
use standard_family;
###########################################################################Start_Time
my $pl=basename($0);
my (@infile,@indir,$level,$Sinfo,$out,$call,$panel_list);
GetOptions
(
	"i=s{,}"		=>\@infile,
	"id=s{,}"		=>\@indir,
	"level=s"		=>\$level,
	"panel=s"		=>\$panel_list,
	"o=s"			=>\$out,
);
&help if(!@indir || !$out);
sub help{
	print <<"Usage_end";
	Usage:
		perl $pl
		-i		input_files
		-id		input_dirs
		-level		3|5
		-panel          panel_gene_list
		-o		output_file
eg:
perl $pl -id <samp_dir> -o <28506_NT01_b999A_Poly_v2.xlsx>
perl $pl -i <samp_result>-id <samp_dir> -o <28506_NT01_b999A_Poly_v2.xlsx>

Usage_end
exit;
};
#########################my ($level,$input,$file,$bam,$rbam,$genecov,$rmgene_cov,$conf,$stat,$rmstat,$rmdupratio,$depthfile,$rmdepthfile)=@_;
###if (!defined $call){$call=1};
my $od=dirname($out);
if (!-d $od)
{
	`mkdir -p $od`;
};
if (!defined $level){$level=3};
######################################
my $conf_file="/share/ofs1a/EXdev/WES_pipe_v1/db/Z_lzw_database/CONFIG_ALL.txt";
my %parameters;
&initialize($conf_file,\%parameters);
########################################

my(@bam,@rbam,@genecov,@rmgenecov,@conf,@stat,@rmstat,@rmdupratio,@depthfile,@rmdepthfile,@sampname,@bestNM,%getdata);
print "get files and dirs...\n";
if (@infile)
{
	&standard_family::input($level,\@indir,\@infile,\@bam,\@rbam,\@genecov,\@rmgenecov,\@conf,\@stat,\@rmstat,\@rmdupratio,\@depthfile,\@rmdepthfile,\@sampname,\@bestNM,\%getdata);
}elsif(@indir)
{
	&standard_family::input($level,\@indir,\@infile,\@bam,\@rbam,\@genecov,\@rmgenecov,\@conf,\@stat,\@rmstat,\@rmdupratio,\@depthfile,\@rmdepthfile,\@sampname,\@bestNM,\%getdata);
}else
{
	print STDERR "\n\tplease check your inputs !\n";
	exit;
};
##########################################################
########################my ($geneanno,$genepos,$genestrand,$genecov,$omim,$phenotype,$for_report,$translation,$first,$second,$num2type)=@_;
my $genepos="$parameters{T3}/C_mut_anno_database/gene_id_chrpos.txt";
my $genestrand="$parameters{T3}/C_mut_anno_database/gene_strand.txt";
my $for_report="$parameters{T3}/Z_lzw_database/for_report_convert.txt";

my $omomphen="$indir[0]/3.3_variation_annotation/OMIM_database/omim.txt";

my (%geneinf,%omiminf,%translation);
print "input the report configs...\n";
my $MS="$Bin/9.0_models/proband_MS";
&standard_family::config(\@sampname,\@genecov,$genepos,$genestrand,\%geneinf,$omomphen,\%omiminf,$for_report,$MS,\%translation);

###print Dumper \%geneinf;die;
###print "$omomphen\n";
##print Dumper \%omiminf;die;

my ($len,%depth,%rmdepth,%com,%single,%singleresult,%genemut)=(50);
my $open=1;
`touch $out` if (!-f $out);
$out=&standard_family::path($out);
print "get anno information of all variants...\n";

my $return;
$return.=&standard_family::get_cominfo(\@sampname,\@infile,\%geneinf,\%omiminf,\%translation,\%com,\%singleresult,$open,\%genemut);

if ($return=~/error/)
{
	die "$return\n\n";
};
###################

print "get SMN1 mut info...\n";
my (%SMN1_com,%relation);
&standard_family::get_SMN1(\@sampname,\@bam,\@rbam,\%omiminf,\%geneinf,\%relation,\%SMN1_com,$open);
############################################
##################i
my $all_file="/share/ofs1a/prod/warriors_assemble.txt";
my ($number)=split /\D+/,$sampname[0];
my $prog=`grep $number $all_file|tail -1|cut -f 3`;chomp $prog;
my %panel_gene;


if((defined $panel_list) && ($panel_list eq "NT01"))
{

}elsif(defined $panel_list)
{
        $prog=$panel_list;
        my $gene_file="$out\.gene.list";
        `wget http://192.168.1.169:8090/omim/panel/find2.do?panelName=$prog -O $gene_file`;
        if ($gene_file && -f $gene_file)
        {
                $panel_gene{OK}=1;
                open L,"$gene_file" or die;
                while (<L>)
                {
                        chomp;
                        next if (/^$/);
                        my @arr=split /\<br\>/,$_;
                        foreach my $gene (@arr)
                        {
                                $panel_gene{$gene}=1;
                        };
                };
                close L;
        }else
        {
                print STDERR "\nError:\tno_gene_list !!!\t";
        };
}elsif ($prog=~/e$|eF$/)
{
	$prog=~s/F//g;
	my $gene_file="$out\.gene.list";
	`wget http://192.168.1.169:8090/omim/panel/find2.do?panelName=$prog -O $gene_file`;
	if ($gene_file && -f $gene_file)
	{
		$panel_gene{OK}=1;
		open L,"$gene_file" or die;
		while (<L>)
		{
			chomp;
			next if (/^$/);
			my @arr=split /\<br\>/,$_;
			foreach my $gene (@arr)
			{
				$panel_gene{$gene}=1;
			};
		};
		close L;
	}else
	{
		print STDERR "\nError:\tno_gene_list !!!\t";
	};
}else
{
	##########不做筛选；
};
#print Dumper \%panel_gene;die;
#########################
print "write to txt...\n";

open OUT2,">$od/filter_result.txt" or die;
open ALL,">$od/filter_result.txt_allgene" or die;

my (@head,$famname,$sexQC,$sex);
if (-f "$indir[0]/4.1_QC/QC_report.txt")
{
	$sexQC=`grep ^sex $indir[0]/4.1_QC/QC_report.txt|cut -f 2`;
	$sex=`grep ^sex $indir[0]/4.1_QC/QC_report.txt|cut -f 1`;
}elsif(-f "$indir[0]/conf.txt")
{
	$sexQC="YES";
	$sex=`grep sex $indir[0]/conf.txt|cut -f 3`;chomp $sex;
}else
{
	print STDERR "\terror:\tplease check the sex information in the config file !\n";
	die;
};

if ($sexQC=~/YES/ && $sex=~/XX/)
{
	$famname="(先证者女,$sampname[0])";
}elsif ($sexQC=~/YES/ && $sex=~/XY/)
{
	$famname="(先证者男,$sampname[0])";
}else
{
	print STDERR "\terror:\tplease check the sex information in the QC file !\n";
	die;
};
$famname=~s/正常/\(表型正常\)/;
push @head,"突变编号","总深度$famname","突变深度$famname","突变率$famname","杂合/纯合$famname","突变可靠性$famname","突变级别","遗传学评分","结论","依据","生物学+遗传学总分","样品编号","基因","基因方向";
push @head,"染色体名称","起始位置","终止位置","核酸改变","氨基酸改变","突变类型";
push @head,"rs编号","次要基因型频率",'千人基因组(中国)','千人基因组(中国南方)','千人基因组(中国北方)',"德易东方MAF频率";
push @head,"EXAC东亚频率","EXAC南亚频率","EXAC最大频率","ESP数据库频率","PubMed文献号","HGMD数据库注释";
push @head,"Clinvar数据库注释","OMIM数据库注释","SWISS数据库注释","Provean危害性预测","SIFT危害性预测","Polyphen2_HDIV危害性预测","Polyphen2_HVAR危害性预测","mutationtaster危害性预测","与疾病相关性","相关性说明","疾病表型名称";
push @head,"基因所关联疾病表型","遗传方式","基因ID","基因Location","基因覆盖度";		###################decode($code,"基因/CNV基因集"),
push @head,"基因覆盖深度","原始总深度","原始突变深度","原始突变率","该基因致病突变数","基因关联疾病数";
push @head,"mRNA变体名称(NM)","是否重复区域","生物学意义编号","疑似阳性/非阳性","ACMG危害等级","ACMG危害判定依据";
push @head,"基因在tiger数据库中高表达组织","基因在tiger数据库中有表达组织","基因在GTEx数据库中高表达组织","基因在GTEx数据库中有表达组织","是否位于保守性区域","是否位于致病热点区域";
push @head,"德易东方患者MAF频率","M-CAP危害性预测","REVEL危害性预测","预测危害性","结构危害性","剪切位点危害性预测","是否共分离","是否denovo","是否复合杂合","打分所用遗传方式","染色体碱基变化";

my @quahead;
push @quahead,"基因","覆盖度$famname","平均深度$famname","基因大于等于10x覆盖度$famname","基因突变数$famname","是否目标基因";

print OUT2 (join "\t",@head)."\n";
print ALL (join "\t",@head)."\n";

############################################################################
my %mut_genetic;
my %resultdata;

foreach my $key (sort keys %singleresult)
{
	foreach my $omimid (sort keys %{$singleresult{$key}})
	{
				my @arr=@{$singleresult{$key}{$omimid}};

##next if($key!~/10437452/);
				$geneinf{$arr[8]}{$sampname[0]}{'mute'}=$arr[46];############质控中基因上突变数，如果有Resultsheet，用1-3级，
				$geneinf{$arr[8]}{$sampname[0]}{'omim'}=$arr[47];
				my (@results,$flag,$rely);
				push @results,@arr[0..3];
			###############################################################
			my $mutqc=10;
			my $rubish;
			&get_correct_homo($arr[4],\$flag,\$rubish);
			if ($flag=~/野生型/ && $level==3)
			{
				print STDERR "Wild mut in result ! $key\n\n";
				die;
			}elsif($flag=~/野生型/ && $level==5)
			{
				#####goon;
			};

				if ($arr[3]>=0.3 && $arr[2]>=5)
				{
					$mutqc=100;
				}else
				{
					$mutqc-=1;
				};
#				if (exists $MQ{$key}{$omimid}{$sampname[0]})
#				{
#					if($MQ{$key}{$omimid}{$sampname[0]}{'mq'}<40){$mutqc-=1};
#					if($MQ{$key}{$omimid}{$sampname[0]}{'repeat'}=~/YES/i){$mutqc-=1};
#					if($MQ{$key}{$omimid}{$sampname[0]}{'rs'}=~/NO/i){$mutqc-=1};
#				};

				#############################		by luozw 20161103
				if ($arr[3]>=0.1 && $arr[2]>=6)
				{
					$mutqc=100;
				}else
				{
					$mutqc=0;
				};
				#####################################
				if($mutqc<=0)
				{
					$rely="不可靠";
				}elsif ($mutqc<=8)
				{
					$rely="不可靠";
				}else
				{
					$rely="相对可靠";
				};
			push @results,$flag,$rely,$arr[5];
			######################################################################
			&standard_family::get_revise_genetic($arr[10],\$arr[38]);
			$arr[38]=~s/X-linked/XL/g;
			my $true_genetic=$arr[38];
			$true_genetic=~s/\(HPO\)//g;
			my @ADS=split /\,/,$true_genetic;
			my %for_gen_score;
			my $biolevel=$arr[5];


			foreach my $ad (sort @ADS)
			{
				if($arr[37] eq 'NA')
				{
					$arr[38]='NA';
					last;
				};				#########################无OMIM疾病的没有遗传打分
				next if($ad=~/^$/);
				&get_correct_genetic($arr[10],\$ad,\$rubish);

				my $uniq="NA";
				my $denovo="NA";
				my $fuhezahe="NA";
				my $gene=$arr[8];
				if ($ad=~/AR/ && ($arr[4]=~/Hete/i) && $biolevel<=3 && (keys %{$genemut{$gene}}>1))
				{
						my %tmp_number;
						foreach my $tmp_key (keys %{$genemut{$gene}})
						{
							next if($key eq $tmp_key);
							foreach my $tmp_level (sort {$a <=> $b} keys %{$genemut{$gene}{$tmp_key}})
							{
								$tmp_number{$tmp_level}=1;
								last;
							};
						};
						##############
						foreach my $min_level (sort {$a <=> $b} keys %tmp_number)
						{
							my @tmp_fuhezahe=($biolevel,$min_level);
							@tmp_fuhezahe=sort {$a <=> $b} @tmp_fuhezahe;
							$fuhezahe="$tmp_fuhezahe[0]\+$tmp_fuhezahe[1]";
							last;
						};
				}elsif($ad=~/AR/ && $arr[4]=~/Hete/i)
				{
					$uniq="YES";
				};

				#######################################################
				my $genetictag22=&standard_family::get_genetic_conclusion($arr[4],$ad,$uniq,$denovo,$fuhezahe);	###########my($HOMO,$AD,$uniq,$denovo,$fuhezahe)=@_;
				$genetictag22.=":F3:O3";

				my ($value,$jielun,$yiju,$totscore);
				if (exists $translation{$genetictag22})
				{
					($value,$jielun,$yiju)=split /\|/,$translation{$genetictag22};
				}else
				{
					$value=100;
					$jielun="err";
					$yiju="err";
#					print STDERR "\n\tmuttype have no conclusion\n$genetictag22\n$key\n$arr[4]\n$ad\n$uniq\n$denovo\n$fuhezahe\n";
#					die;
				};

					if ($fuhezahe=~/\d+/)
					{
						if ($fuhezahe eq '1+1')
						{
							$totscore=1;
						}elsif($fuhezahe eq '1+2')
						{
							$totscore=2;
						}elsif($fuhezahe eq '1+3')
						{
							$totscore=4;
						}elsif($fuhezahe eq '2+2')
						{
							$totscore=4;
						}elsif($fuhezahe eq '2+3')
						{
							$totscore=6;
						}elsif($fuhezahe eq '3+3')
						{
							$totscore=18;
						}else
						{
							print STDERR "please check the score of comphete !\n";
							die;
						};
##						$yiju.="($fuhezahe)";
					}else
					{
						if ($biolevel eq '1')
						{
							$totscore=$value*1;
						}elsif($biolevel eq '2')
						{
							$totscore=$value*3;
						}elsif($biolevel eq '3')
						{
							$totscore=$value*6;
						}elsif($biolevel eq '4')
						{
							$totscore=$value*10;
						}elsif($biolevel eq '5')
						{
							$totscore=$value*20;
						}else
						{
							print STDERR "please check the bio-level of this mutation ! \t $key \n";
							die;
						};
					};
				push @{$for_gen_score{$totscore}},"$value|$jielun|$yiju|$totscore|$ad";
			};

			my ($value,$jielun,$yiju,$totscore)=("NA","NA","NA","NA");
				foreach my $AAA (sort {$a <=> $b} keys %for_gen_score)
				{
					($value,$jielun,$yiju,$totscore,$true_genetic)=split /\|/,@{$for_gen_score{$AAA}}[0];###############遗传方式只输出一个，
					last;
				};

			$mut_genetic{$key}{$omimid}=$value;

			if ($arr[38]=~/NA/)
			{
				$yiju=~s/，符合/，本疾病遗传方式尚未报道，不排除其符合/;
				$yiju=~s/，不符合/，本疾病遗传方式尚未报道，不排除其不符合/;
			}elsif($arr[38]=~/XL/ && $true_genetic=~/XD/)
			{
				$true_genetic="XL";
				$yiju=~s/X-linked|XD/XL/g;
			};

			push @results,$value,$jielun,$yiju,$totscore;

			if ($totscore=~/\d+/ && $totscore<=8)
			{
			        $arr[51]="疑似阳性";
			}else
			{
			        $arr[51]="非阳性";
			};

		my @chrpos=split /[:-]/,$arr[10];
		if (!$chrpos[2]) {$chrpos[2]=$chrpos[1]};
		push @results,@arr[7..9],@chrpos,@arr[11..51],"NA","NA","NA","NA","NA","NA","NA","NA";

		##########################
		my $AR_hete="NA";
		if ($true_genetic=~/AR/ && ($arr[4]=~/Hete/i) && ($value==4))
		{
			$AR_hete=1;
		}elsif($true_genetic=~/AR/ && ($arr[4]=~/Hete/i) && ($value==15))
		{
			$AR_hete="0";
		}else
		{
			$AR_hete="0";
		};

		push @results,@arr[52..57],"-1","-1",$AR_hete,$true_genetic,$arr[58];
		############################
		next if ($arr[8] =~ /^HLA/);                    ############################出报告那一步，把HLA基因的突变过滤掉！20160901
		foreach (0..@results-1){$_=~s/^\s+|\s+$//g};
##		foreach (0..@results-1){Encode::_utf8_on($results[$_])};					#########################Encode::_utf8_off($b);
##		map {delete $results[$_] if($results[$_] && $results[$_] =~ /^NA$|^NULL$|^ NA$|^NA $/i);} 0..@results-1;
#		$results[0]=`echo \'$results[0]\'|md5sum |cut -d \' \' -f 1`;chomp $results[0];
		foreach my $bef_eff (@results)
		{
			$bef_eff=&standard_family::get_effec_num($bef_eff);
		};

		$resultdata{$key}{$omimid}=\@results;
	};
};
##########################################################

print "get ACMG value...\n";
my $cds="$parameters{T3}/G_RNA_expre_database/last_cds_and_50bp_nm.txt";
my $pm1="$parameters{T3}/G_RNA_expre_database/PM1.site";
my (%acmg11,%disease_hot,%MQ);
&standard_family::get_ACMG(\@bestNM,$cds,$pm1,\%mut_genetic,\%acmg11,\%disease_hot,\%MQ,\@sampname);

foreach my $key (sort keys %resultdata)
{
	foreach my $omimid (sort keys %{$resultdata{$key}})
	{
		 my @results=@{$resultdata{$key}{$omimid}};

		 my @tidai;
		 my @relys;
		 if (exists $acmg11{$key}{$omimid})
		 {
			push @relys,@{$acmg11{$key}{$omimid}};
		 };
		 @relys=&standard_family::get_uniq(@relys);
		 my ($comYES,$comNO,$match,$reaYES,$reaNO)=("NA","NA","NA","NA","NA");
		 &standard_family::get_acmg_result(\@relys,\$comYES,\$comNO,\$match,\$reaYES,\$reaNO);

		 push @tidai,$reaNO,$comNO;

                        if (exists $disease_hot{$key})
                        {
                                push @tidai,@{$disease_hot{$key}};
                        }else
                        {
                                print STDERR "no_disease_hot:\t$key\n";
                                die;
                        };

                        if (exists $translation{$results[0]})
                        {
                                $results[0]=$translation{$results[0]};
                        }else
                        {
                                print STDERR "no_mutation_tag:$key\n";
                                die;
                        };

		splice(@results,58,8,@tidai);

		&standard_family::revese_cons_whx($results[64],$results[65],\$results[70]);


		my $last_out=join "\t",@results;
                print ALL "$last_out\n";
                if (exists $panel_gene{OK})
                {
                        next if (not exists $panel_gene{$results[12]});
                };
                print OUT2 "$last_out\n";
	};
};






if(exists $SMN1_com{$sampname[0]})
{
		foreach my $A (sort @{$SMN1_com{$sampname[0]}})
		{
			my @results=@{$A};
			foreach (0..@results-1){$_=~s/^\s+|\s+$//g};
	##		foreach (0..@results-1){Encode::_utf8_on($results[$_])};					#########################Encode::_utf8_off($b);
	##		map {delete $results[$_] if($results[$_] && $results[$_] =~ /^NA$|^NULL$|^ NA$|^NA $/i);} 0..@results-1;
#			$results[0]=`echo \'$results[0]\'|md5sum |cut -d \' \' -f 1`;chomp $results[0];
			if (exists $translation{$results[0]})
			{
				$results[0]=$translation{$results[0]};
			}else
			{
				print STDERR "no_mutation_tag:$results[0]\n";
				die;
			};
			my $last_out=join "\t",@results;
			print ALL "$last_out\n";

			if (exists $panel_gene{OK})
			{
				next if (not exists $panel_gene{SMN1});		###############gene 过滤
			};
			print OUT2 "$last_out\n";
		};
};

######################
my @chr_cnv;

my $cnv_cnv_file="$indir[0]/5.2_EXON_deletion/chr_UPD.txt.anno";
my $exon_cnv_file="$indir[0]/5.3_Batch_EXON_deletion/positive_cnv_region_exon_reliable_anno";
if (-f $cnv_cnv_file && -f $exon_cnv_file)
{
	&get_chr_cnv($cnv_cnv_file,$exon_cnv_file,\@chr_cnv);
}else
{
#	print STDERR "\t\t\tno_file:\t$cnv_cnv_file || $exon_cnv_file \n";
};
###########暂时关闭 20161024

if (@chr_cnv > 1)
{
	open CNV,">$od/cnv.txt" or die;
	foreach my $res (@chr_cnv)
	{
		my @results=split /\t/,$res;

			foreach (0..@results-1){$_=~s/^\s+|\s+$//g};
	##		foreach (0..@results-1){Encode::_utf8_on($results[$_])};					#########################Encode::_utf8_off($b);
	##		map {delete $results[$_] if($results[$_] && $results[$_] =~ /^NA$|^NULL$|^ NA$|^NA $/i);} 0..@results-1;
			my $last_out=join "\t",@results;
			print CNV "$last_out\n";
	};
	close CNV;
};
########################################################

if ((keys %{$geneinf{DMD}}) >3)			############fx	pos	id	####dep	cov
{
	open QC,">$od/QC.txt" or die;
	print QC (join "\t",@quahead)."\n";

	foreach my $gene (sort keys %geneinf)			#########$geneinf->{$arr[0]}{$$sampname[$i]}{'cov'}=$arr[1];
	{
		next if (not exists $geneinf{$gene}{$sampname[0]}{'dep'});
		my @last2;
		if (exists $panel_gene{OK})
		{
			next if (not exists $panel_gene{$gene});		###############gene 过滤
		};

		push @last2,$gene;
		for (my $i=0;$i<@sampname ;$i++)
		{
			my $gene_mut=0;
			if (exists $geneinf{$gene}{$sampname[$i]}{'mute'})
			{
				$gene_mut=$geneinf{$gene}{$sampname[$i]}{'mute'};
			};
			foreach my $value (($geneinf{$gene}{$sampname[$i]}{'cov'},$geneinf{$gene}{$sampname[$i]}{'dep'},$geneinf{$gene}{$sampname[$i]}{'cov10X'}))
			{
				if (defined $value && $value=~/\./)
				{
					$value=sprintf("%.2f",$value);
					push @last2,$value;
				}elsif(!defined $value)
				{
					push @last2,0;
					next;
					print "$gene\n";
					print Dumper \%{$geneinf{$gene}};
					die;
				}else
				{
					push @last2,$value;
				};
			};
			push @last2,$gene_mut;
		};
		push @last2,"是";

		foreach (0..@last2-1){$_=~s/^\s+|\s+$//g};
	##	foreach (0..@results-1){Encode::_utf8_on($results[$_])};					#########################Encode::_utf8_off($b);
	##	map {delete $results[$_] if($results[$_] && $results[$_] =~ /^NA$|^NULL$|^ NA$|^NA $/i);} 0..@results-1;
		my $last_out=join "\t",@last2;
		print QC "$last_out\n";
	};
	close QC;
}else
{
	print STDERR "\n\t\t\tError:no_gene_coverage_depth_information !\n";
};
close OUT2;
close ALL;
##############################################################################################
=cut
open OUT1,">$od/all_result.txt" or die;
open OUT2,">$od/filter_result.txt" or die;
open CNV,">$od/cnv.txt" or die;
open QC,">$od/QC.txt" or die;
=cut
my $convert=$parameters{S7};
if (-f "$od/filter_result.txt" && -f "$od/cnv.txt" && -f "$od/QC.txt")
{
##	`$convert -i "$od/filter_result.txt" "$od/cnv.txt" "$od/QC.txt" -code utf-8 -n Mutation CNV Quality -null -o $out`;
	`$convert -i "$od/filter_result.txt" "$od/QC.txt" -code utf-8 -n Mutation Quality -null -o $out`;
}elsif(-f "$od/filter_result.txt"  && -f "$od/QC.txt")
{
	`$convert -i "$od/filter_result.txt" "$od/QC.txt" -code utf-8 -n Mutation Quality -null -o $out`;
}elsif(-f "$od/filter_result.txt")
{
	`$convert -i "$od/filter_result.txt" -code utf-8 -n Mutation -null -o $out`;
	print STDERR "\t\tError:no_QC_file\n";
}else
{
	print STDERR "Error:\tplease_check_the_outdir !\n";
	die;
};

print "done...\n\n";
#############################################################################
###############################################################

sub get_chr_cnv
{
	my ($chrcnv,$exoncnv,$arr,%hash)=@_;
	open L,"$chrcnv" or die "no $chrcnv\n";
	my $head=<L>;
	push @{$arr},$head;
	while (<L>)
	{
		chomp;
		next if (/^$/);
		push @{$arr},$_;
		my @tmp=split /\t/,$_;
		$hash{$tmp[2]}=1;
	};
	close L;
	#########################
	open L,"$exoncnv" or die;
	<L>;
	while (<L>)
	{
		chomp;
		next if (/^$/);
		my @tmp=split /\t/,$_;
		next if(exists $hash{$tmp[2]});
##		push @{$arr},$_;	###########暂时关闭 20161024
	};
	close L;
};

sub get_correct_genetic
{
	my ($chr,$genetic,$tag)=@_;
	if ($$genetic=~/XD|X-linked/)
	{
		$$tag.="3";
	}elsif($$genetic=~/XR/)
	{
		$$tag.="4";
	}elsif($$genetic=~/AD/)
	{
		$$tag.="1";
	}elsif($$genetic=~/AR/)
	{
		$$tag.="2";
	}elsif($$genetic=~/Y/)
	{
		$$tag.="5";
	}else
	{
		if ($chr=~/chrX|NC_000023/)
		{
			$$tag.="3";
			$$genetic='XD';
		}elsif ($chr=~/chrY|NC_000024/)
		{
			$$tag.="5";
			$$genetic='Y';
		}else
		{
			$$tag.="1";
			$$genetic='AD';
		};
	};
};

sub get_correct_homo
{
	my($homo_type,$homo_tag,$genetic)=@_;
	if ($homo_type=~/Homo/i)
	{
		$$genetic.="1";
		$$homo_tag="纯合";
	}elsif($homo_type=~/Hemi/i)
	{
		$$genetic.="5";
		$$homo_tag="半合子";
	}elsif($homo_type=~/Hete/i)
	{
		$$genetic.="2";
		$$homo_tag="杂合";
	}else
	{
		$$genetic.="4";
		$$homo_tag="野生型";
	};
};

sub initialize
{
        my ($file,$hash)=@_;
	open K,"$file" or die;
        while (<K>)
        {
                chomp;
                next if (/^$/ || /^\#/);
                my @arr=split /\t/,$_;
                if (!defined $arr[2])
                {
                        $hash->{$arr[0]}=$arr[1];
                }else
                {
                        $arr[2]=~s/\#//g;
                        $hash->{$arr[0]}="$arr[1] $arr[2]";
                };
        };
        close K;
};


#########&revese_cons_whx($results[-2],$results[-1],\$arr[56]);
