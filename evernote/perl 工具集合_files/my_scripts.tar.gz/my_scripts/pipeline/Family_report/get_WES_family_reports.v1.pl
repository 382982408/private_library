#!/usr/bin/perl -w
use strict;
use Cwd;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);
use lib "$Bin/9.0_models/";
use standard_family;
###########################################################################Start_Time
my %parameters;
my $file="/share/ofs1a/EXdev/WES_pipe_v1/db/Z_lzw_database/CONFIG_ALL.txt";
&initialize($file,\%parameters);

sub initialize
{
        my ($file,$hash)=@_;
	open K,"$file" or die;
	        while (<K>)
        {
                chomp;
                next if (/^$/ || /^\#/);
                my @arr=split /\t/,$_;
                if (!defined $arr[2])
                {
                        $hash->{$arr[0]}=$arr[1];
                }else
                {
                        $arr[2]=~s/\#//g;
                        $hash->{$arr[0]}="$arr[1] $arr[2]";
                };
        };
        close K;
};
my $all_raw=$parameters{D28};
my $sam_dir=$parameters{D30};
###########################################################################

my $pl="$Bin/get_compound_family_report.v1.pl";
my $id=shift;
my $level=shift;
my $od=shift;
my $run=shift;
my $cov=shift;
if(!$id || !$level || !$od || !$run)
{
	print "\n\tperl $0 <sam_dir> <level> <out_dir> <run_or_not?> <cov_or_not>\n\n";
	exit;
};
$id=`readlink -f $id`;

`mkdir -p $od` if(!-d $od);
$od=`readlink -f $od`;chomp $od;
my $number=(split /\D+/,(basename $id))[0];

if(!defined $cov)
{
	$cov="yes";
};
########################
open Z,">$od/fam_$number\.sh" or die "$od/fam_$number\.sh \n";
open ERR,">$od/fam_$number\.sh.err" or die;
if (`grep $number $all_raw|grep F|head -1|cut -f 3`)
{
	if($cov=~/yes/ || !-f "$od/$number\_handle.txt")
	{
		&standard_family::get_fam_relative($all_raw,$number,"$od/$number\_handle.txt");
	};
	my $xzz_num=`grep 先证者 $od/$number\_handle.txt|head -1|cut -f 1`;
	$xzz_num=(split /\D/,$xzz_num)[0];
	if ($number==$xzz_num)
	{
		my @samples;
		my @samdirs;
		my $xianzhenzhe;
		my $xzzdir;
		my %relative;
		my $tag=1;
        	open L,"$od/$number\_handle.txt" or die;
	        while (<L>)
        	{
	                chomp;
        	        next if(/^$/);
	                my @arr=split /\t/,$_;
	       	        my ($tmpnumber)=split /\D+/,$_;

			my $pre_batch=`cut -f 1-4 $all_raw|grep $tmpnumber|grep F|head -1|cut -f 1`;chomp $pre_batch;

			my $batch=`cut -f 1-4 $all_raw|grep $tmpnumber|grep F|tail -1|cut -f 1`;chomp $batch;
			my $sampdir=(glob "$sam_dir/b$pre_batch/$tmpnumber*")[0];

	                if (!$sampdir)
        	        {
                	        print ERR "no_familiy_dir:\t$number\t$tmpnumber\n\n";
				$tag=0;
                        	next;
	                };
			$sampdir=`readlink -f $sampdir`;chomp $sampdir;
			push @samples,$tmpnumber;
                        push @samdirs,$sampdir;
			if ($arr[6] && $arr[6] =~/先证者/)
			{
				$xianzhenzhe=$tmpnumber;
                        	$xzzdir=$sampdir;
			};
			++$relative{$arr[10]};
                };
		close L;

	        if ($xianzhenzhe && $xzzdir)
		{
                	unshift @samples,$xianzhenzhe;
	                @samples=&standard_family::get_uniq(@samples);
			$xzzdir=`readlink -f $xzzdir`; chomp $xzzdir;

	                unshift @samdirs,$xzzdir;
        	        @samdirs=&standard_family::get_uniq(@samdirs);
		};
	        my $inputdir=join " ",@samdirs;

		if($tag==0)
		{
			print Z "some sample error !!!\n";		
		}elsif(@samples<1)
		{
			print Z "is this really a family !!!\n";
		}else
		{
			my $outname=&get_outname($od,\@samples,\%relative,$all_raw);
			my $level5=$outname;
			$level5=~s/xlsx$/level1_5.xlsx/;
			my $level3=$outname;
			$level3=~s/xlsx$/level1_3.xlsx/;
			print Z "nohup perl $pl -id $inputdir -level 5 -o $outname 1>$outname.out  2> $outname.err \& \n";
			print Z "wait\ncp $outname $level5 \n";
			print Z "nohup perl $pl -id $inputdir -level 3 -o $outname 1>>$outname.out  2>> $outname.err \& \n";
			print Z "wait\ncp $outname $level3 \n";
		};
        }else
	{
		print ERR "not_the_proband !!!\n";		
	};
}else
{
	print ERR "not fam sample !!!\n";
};
close Z;
close ERR;

if($run=~/yes/i && (stat "$od/fam_$number\.sh")[7]!=0)
{
	`ssh node-0-11 \'nohup sh $od/fam_$number\.sh &\' &`;
	print STDOUT "ssh node-0-11 \'sh $od/fam_$number\.sh &\'\n\n";
};
##############################################################
sub get_outname
{
	my ($od,$samples,$relation,$all_raw)=@_;
	my $name;
	$name="$od/$$samples[0]_";
	if (`grep $$samples[0] $all_raw|grep F|tail -1|cut -f 3`)
	{
		$name.=`grep $$samples[0] $all_raw|grep F|grep -v Nmt|tail -1|cut -f 3`;chomp $name;
	}else
	{
		$name.=`grep $$samples[0] $all_raw|grep F|grep -v Nmt|tail -1|cut -f 3`;chomp $name;
	};
	$name.="_b";
	for (my $i=0;$i<@{$samples} ;$i++)
	{
		my $batch;
		if (`grep $$samples[$i] $all_raw|grep F|grep -v Nmt|tail -1|cut -f 1`)
		{
			$batch=`grep $$samples[$i] $all_raw|grep F|grep -v Nmt|tail -1|cut -f 1`;chomp $batch;
		}else
		{
			$batch=`grep $$samples[$i] $all_raw|grep F|grep -v Nmt|tail -1|cut -f 1`;chomp $batch;
		};
		$name.="$batch"."A";
	};
	if (@{$samples}==3 && exists $relation->{son} && exists $relation->{father} && exists $relation->{mother} && $relation->{son}==1 && $relation->{father}==1 && $relation->{mother}==1)
	{
		$name.="_Trios_v2.xlsx";
	}elsif(@{$samples}==3 && exists $relation->{daughter} && exists $relation->{father} && exists $relation->{mother} && $relation->{daughter}==1 && $relation->{father}==1 && $relation->{mother}==1)
	{
		$name.="_Trios_v2.xlsx";
	}else
	{
		$name.="_unTrios_v2.xlsx";
	};
	return $name;
};


sub path{ #$pavfile=&ABSOLUTE_DIR($pavfile);获取绝对路径
	my $cur_dir=`pwd`;chomp($cur_dir);
	my ($in)=@_;
	my $return="";

	if(-f $in){
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;chomp $dir;
		$return="$dir/$file";
	}elsif(-d $in){
		chdir $in;$return=`pwd`;chomp $return;
	}else{
		warn "Warning just for file and dir\n";
		exit;
	}
	chdir $cur_dir;
	return $return;
};

sub datetime{
        my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
        $wday = $yday = $isdst = 0;
                $year+=1900;$mon+=1;
                if ((length $mon)==1){$mon="0$mon"};
                return "$year$mon$day";
##        sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
};
