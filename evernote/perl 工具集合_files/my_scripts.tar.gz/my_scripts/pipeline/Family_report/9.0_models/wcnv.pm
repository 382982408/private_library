package wcnv;
{
	$Path::wcnv::VERSION = '0.1';
};
#!/usr/bin/perl -w
use strict;
use Cwd;
use Getopt::Long;
use Data::Dumper;
use Spreadsheet::WriteExcel;
use Excel::Writer::XLSX;
use Spreadsheet::ParseExcel;
use Encode;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

sub path{
	my $cur_dir=`pwd`;
	chomp($cur_dir);
	my ($in)=@_;
	my $return="";
	if(-f $in){
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;chomp $dir;
		$return="$dir/$file";
	}elsif(-d $in){
		chdir $in;$return=`pwd`;chomp $return;
	}else{
		warn "Warning just for file and dir:$in\n";
		exit;
	}
	chdir $cur_dir;
	return $return;
};
###############################################
sub sub_format_datetime{#Time calculation subroutine
	my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
	$wday = $yday = $isdst = 0;
	sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}
##########################################################################
sub chr_convert{
	my $chr=(split /0{4,5}|\./,$_[0])[1];
	if ($chr eq '23') {$chr='X'}
	elsif($chr eq '24'){$chr='Y'};
	return "chr$chr";
};
##########################################################################
sub get_sex_model
{
	my($file,$hash)=@_;
	open M,"$file" or die;
	<M>;
	while (<M>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\s+/,$_;
		$hash->{"$arr[0]-$arr[1]-$arr[2]"}=$_;
	};
	close M;
};
#######################################################################
sub get_sex_QC
{
	my($file,$hash,$col)=@_;
	open M,"$file" or die;
	while (<M>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\s+/,$_;
		$hash->{$arr[0]}="$arr[1]-$arr[3]-$arr[4]";
		push @{$col},$arr[0];
	};
	close M;
};
#########################################################################
sub get_sex_cnv		#########&wcnv::get_sex_cnv($bed_dep,$totreads,\%value_man,$manresult);
{
	my ($in,$pairreads,$hash,$out)=@_;
	open L,"$in" or die;
	open OUT, ">$out" or die;
	print OUT "chr\tstart\tend\taverage\tsd\tcv\tZ_value\tdiff\tstd_value\tresult\n";
	my $del1_value_a=0.4;			####CNV参数
	my $del1_value_b=0.6;
	my $del2_value=0.1;
	my $dup1_value_a=1.45;
	my $dup1_value_b=1.65;
	my $dup2_value=1.85;
	my $significance=2.58;
	while (<L>)
	{
		chomp;
		next if (/^$/);
		my ($chr,$s,$e,$rds)=split;
		my $value=$rds/$pairreads;
		if (exists $hash->{"$chr-$s-$e"})
		{
			my @data=split /\s+/,$hash->{"$chr-$s-$e"};
			my $z_value=abs(($value-$data[3])/$data[4]);
			my $diff=$value/$data[3];
			my $copy;
			if ($diff>=$dup2_value && $z_value>=$significance) 
			{
				$copy='dup';				###############此处先不做dup1 dup2 区分，方便后面的合并
			}elsif($diff>=$dup1_value_a && $z_value>=$significance)
			{	
				$copy='dup';
			}elsif($diff<=$del2_value && $z_value>=$significance)
			{
				$copy='del';
			}elsif($diff<=$del1_value_b && $z_value>=$significance)
			{
				$copy='del';
			}else
			{
				$copy='NA';	
			};
			print OUT $hash->{"$chr-$s-$e"},"\t$z_value\t$diff\t$value\t$copy\n";
		};
	};
	close L;
	close OUT;
};
############################################################################
sub get_cnv_region_merge		########&wcnv::get_cnv_region_merge(\@tmp,\%NC_all_data,$type,\%result);
{
	my($origin,$type,$last)=@_;
	my ($chr,$start,$end)=split /\t/,$$origin[0];
	for (my $i=1;$i<=@{$origin};$i++)
	{
		if ($i==@{$origin}) 
		{
			$last->{$chr}{$type}{$start}{$end}=1;
		}else
		{
			my ($tmpchr,$tmpstart,$tmpend)=split /\t/,$$origin[$i];
			if ($start<=$tmpend && $end>=$tmpstart)
			{
				my @tmp=sort {$a <=> $b} ($start,$end,$tmpstart,$tmpend);
				($chr,$start,$end)=($tmpchr,$tmp[0],$tmp[-1]);
			}else
			{
				$last->{$chr}{$type}{$start}{$end}=1;
				($chr,$start,$end)=($tmpchr,$tmpstart,$tmpend);
			};
		};
	};
};
#######################################################################
sub get_NA_region_merge		#############&wcnv::get_NA_region_merge(\@tmp,\%NC_all_data,$type,\%last);
{
	my($origin,$hash,$type,$last)=@_;
	my ($chr,$start,$end)=split /\t/,$$origin[0];
	my $duplimit=1.2;my $dupalllimit=1.3;
	my $dellimit=0.8;my $delalllimit=0.7;
	for (my $i=1;$i<=@{$origin};$i++)
	{
		if ($i==@{$origin}) 
		{
			$last->{$chr}{$start}="$chr\t$start\t$end";
		}else
		{
			my ($tmpchr,$tmpstart,$tmpend)=split /\t/,$$origin[$i];
			my ($tot,$num,$tag)=(0,0,1);
		OUT:foreach my $aaastart (sort {$a <=> $b} keys %{$hash->{$chr}})
			{
				next if($aaastart<$start);
				foreach my $aaaend (sort {$a <=> $b} keys %{$hash->{$chr}{$aaastart}})
				{
					last OUT if($aaaend>$tmpend);
					++$num;
					$tot+=$hash->{$chr}{$aaastart}{$aaaend};
					$tag=0 if($hash->{$chr}{$aaastart}{$aaaend}>$dellimit && $hash->{$chr}{$aaastart}{$aaaend}<$duplimit);
				};
			};
			my $ave=$tot/$num;
			$tag=0 if($ave>$delalllimit && $ave<$dupalllimit);
			if ($tag==1)
			{
				my @tmp=sort {$a <=> $b} ($start,$end,$tmpstart,$tmpend);
				($chr,$start,$end)=($tmpchr,$tmp[0],$tmp[-1]);
			}elsif($tag==0)
			{
				$last->{$chr}{$start}="$chr\t$start\t$end";
=ut
				my ($num,$tag,$yxtag)=&get_NA_region_merge_tag($chr,$start,$end,$hash);
				$start+=$cut;
				$end-=$cut;
				my $len=$end-$start;
				next if($len<$cutoff || $tag eq 'err');
				$last->{"$chr\t$start\t$end\t$num\t$tag\t$yxtag"}=1;
=cut
				($chr,$start,$end)=($tmpchr,$tmpstart,$tmpend);
			};
		};
	};
};
sub get_NA_region_merge_tag
{
	my ($chr,$start,$end,$hash,@tag)=@_;
	my ($tot,$num,$yxnum)=(0,0,0);
	OUT:foreach my $aaastart (sort {$a <=> $b} keys %{$hash->{$chr}})
		{
			next if($aaastart<$start);
			foreach my $aaaend (sort {$a <=> $b} keys %{$hash->{$chr}{$aaastart}})
			{
				last OUT if($aaaend>$end);
				++$num;
				$tot+=$hash->{$chr}{$aaastart}{$aaaend};
				next if($hash->{$chr}{$aaastart}{$aaaend}>0.6 && $hash->{$chr}{$aaastart}{$aaaend}<1.45);
				++$yxnum;
			};
		};
	if ($num<=1)
	{
		@tag=("err","err","1/1=1");		##########说明是单包
	}else
	{
		my $yxratio=$yxnum/$num;$yxratio=sprintf("%.4f",$yxratio);
		my $ave=$tot/$num;
		if ($ave>=1.8)
		{
			@tag=(2,"gain","$yxnum\/$num\=$yxratio");
		}elsif($ave>=1.3)
		{
			@tag=(1,"gain","$yxnum\/$num\=$yxratio");
		}elsif($ave<=0.1)
		{
			@tag=("-2","loss","$yxnum\/$num\=$yxratio");
		}elsif($ave<=0.7)
		{
			@tag=("-1","loss","$yxnum\/$num\=$yxratio");
		}else
		{
			@tag=("err","err","$yxnum\/$num\=$yxratio");
		};
	};
	return @tag;
};
###############################################################
sub get_GC_copy_number
{
	my($result,$anno,$hash,$od)=@_;
	my $tmpfile="$od/bed_tmp1.txt";
	`bedtools map -a $result -b $anno -c 4 -o mean -null 0 >$tmpfile `;
	open L,"$tmpfile" or die "fail to get GC or copy number\n";
	while (<L>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		$arr[3]=sprintf("%.2f",$arr[3]);
		$hash->{$arr[0]}{$arr[1]}{$arr[2]}=$arr[3];
	};
	close L;
	`rm $tmpfile`;
};

###############################################################################################以上程序均与WCNV分析相关
###############################################################################################
###############################################################################################以下程序均与出报告相关
sub get_region_exon
{
	my ($file,$genefile,$exonfile,$cnv,$exon,$gene,$NM,$exonnum,%tmp)=@_;
	open M,"$file" or die;
	while (<M>)
	{
		chomp;
		next if(/^$/);
		my @arr=split /\t/,$_;
		$tmp{$arr[0]}{$arr[1]}{$arr[2]}=1;
		$arr[3]=~s/-//;
		$cnv->{$arr[0]}{$arr[1]}{$arr[2]}="$arr[4]$arr[3]";
	};
	close M;
	################
	open L,"$exonfile" or die;
	while (<L>)
	{
		chomp;
		next if(/^$/);
		my @arr=split /\s+/,$_;
		next if (not exists $tmp{$arr[0]});
		$exonnum->{$arr[3]}+=1;
		foreach my $start (keys %{$tmp{$arr[0]}})
		{
			next if ($start>$arr[2]);
			foreach my $end (keys %{$tmp{$arr[0]}{$start}})
			{
				if ($start<=$arr[2] && $end>=$arr[1])
				{
					push @{$gene->{"$arr[0]:$start-$end"}},$arr[3];
					$NM->{"$arr[0]:$start-$end"}{$arr[3]}=$arr[5];
					my @tmp=(split /\:/,$arr[-1]);
					if (@tmp)
					{
						push @{$exon->{"$arr[0]:$start-$end"}{$arr[3]}},$tmp[1];
					}else
					{
						print Dumper \@arr;die;
					};
				};
			};
		};
	};
	close L;
	###########################
	open L,"$genefile" or die;
	while (<L>)
	{
		chomp;
		next if(/^$/);
		my @arr=split /\s+/,$_;
		next if (not exists $tmp{$arr[0]});
		foreach my $start (keys %{$tmp{$arr[0]}})
		{
			next if ($start>$arr[2]);
			foreach my $end (keys %{$tmp{$arr[0]}{$start}})
			{
				if ($start<=$arr[2] && $end>=$arr[1])
				{
					push @{$gene->{"$arr[0]:$start-$end"}},(split/\|/,$arr[3])[0];
				};
			};
		};
	};
	close L;
};
#########################################################################################
sub get_allfam_genedell		##############(\@gene_cnv,\%fam_del);
{
	my ($samname,$file,$samp_region,$hash,$gene_bed,%tmp_gene)=@_;
	open L,"$gene_bed" or die;
	while (<L>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		my $gene_name=(split /\|/,$arr[3])[0];
		$tmp_gene{$arr[0]}{$arr[1]}{$arr[2]}=$gene_name;
	};
	close L;
	for (my $i=0;$i<@{$file} ;$i++)
	{
		open M,"$$file[$i]" or die;
		while (<M>)
		{
			chomp;
			next if (/^$/);
			my @arr=split /\t/,$_;
			$arr[3]=~s/-//;
			$samp_region->{$$samname[$i]}{$arr[0]}{$arr[1]}{$arr[2]}="$arr[4]$arr[3]";
			foreach my $start (sort keys %{$tmp_gene{$arr[0]}})
			{
				last if($start>$arr[2]);
				foreach my $end (sort keys %{$tmp_gene{$arr[0]}{$start}})
				{
					next if ($end<$arr[1]);
					$hash->{$$samname[$i]}{$tmp_gene{$arr[0]}{$start}{$end}}.="$arr[4]$arr[3]|";
				};
			};
		};
		close M;
	};
};
##############################################################
sub get_del_tag
{
	my ($del,$tag)=@_;
	if ($del=~/gain2/)
	{
		$tag="双倍重复"
	}elsif($del=~/gain1/)
	{
		$tag="单倍重复"
	}elsif($del=~/loss2/)
	{
		$tag="纯合缺失"
	}elsif($del=~/loss1/)
	{
		$tag="杂合缺失"
	}else
	{
		$tag="未知"
	};
	return $tag;
};
###############################################################################################
sub config{				#################&standard_family::config($genepos,$genestrand,\%geneinf,$gene2omim,\%gene2num,$omomphen,\%phenotype,$first,$second,\%num2type);
	my ($genepos,$genestrand,$geneinf,$omim,$omiminf)=@_;
		##########################################
		open L,"$genepos" or die;		<L>;
		while (<L>)
		{
			chomp;	next if (/^$/ || /^\#/);
			my @arr=split /\t/,$_;
			if ($arr[1] eq '-') {$arr[2]='NA'};
			$geneinf->{$arr[1]}{'id'}=$arr[0];
			$geneinf->{$arr[1]}{'pos'}=$arr[2];
		};
		close L;
		################################################
		open L,"$genestrand" or die;
		while (<L>)
		{
			chomp;	next if (/^$/);
			my @arr=split /\t/,$_;
			$geneinf->{$arr[0]}{'fx'}=$arr[1];
		};
		close L;
		################################################
		open L,"$omim" or die;
		<L>;
		while (<L>)
		{
			chomp;
			next if (/^$/);
			my ($gene,$gene_arr,$gene_OMIM,$dis_OMIM,$inherit,$old,$old2,$chr,$revise,$disease)=split /\t/,$_;
			if (!$inherit || $inherit!~/[A-Z]+/)
			{
				$inherit="NA";
			};
			if (!$dis_OMIM || $dis_OMIM!~/\d+/)
			{
				$dis_OMIM="NA";
			};
			if (!$disease || $disease=~/^$/)
			{
				$disease="NA";
			};
			push @{$omiminf->{omim}{$dis_OMIM}},"$gene|$gene_OMIM|$dis_OMIM|$inherit|$disease";
			push @{$omiminf->{gene}{$gene}},"$gene|$gene_OMIM|$dis_OMIM|$inherit|$disease";
		};
		close L;
		##########################################
};
######################################################################################
sub get_chr_band
{
	my ($cnvfile,$chrbandfile,$hash)=@_;
	#####################
	my %tmp;
	open M,"$chrbandfile" or die;
	while (<M>)
	{
		chomp;
		next if(/^$/);
		my @arr=split /\t/,$_;
		$tmp{$arr[0]}{$arr[1]}{$arr[2]}=$arr[3];
	};
	close M;
	################
	open M,"$cnvfile" or die;
	while (<M>)
	{
		chomp;
		next if(/^$/);
		my @arr=split /\t/,$_;
		my $chr=&chr_convert($arr[0]);
		foreach my $start (sort {$a <=> $b} keys %{$tmp{$chr}})
		{
			last if($start>$arr[2]);
			foreach my $end (sort {$a <=> $b} keys %{$tmp{$chr}{$start}})
			{
				next if($end<$arr[1]);
				push @{$hash->{$arr[0]}{$arr[1]}{$arr[2]}},$tmp{$chr}{$start}{$end};
			};
		};
	};
	close M;
	################
};









###############################################################################################
sub get_abbr 
{
	my $last;
	@_=sort {$a <=> $b} @_;
	for (my $i=0;$i<@_ ;$i+=1)
		{
		if ((exists $_[$i-1]) && (($_[$i]-$_[$i-1])==1))
		{
			$last.="-$_[$i]";
		}else
		{
			$last.=",$_[$i]";
		}
		};
	for (@_){$last=~s/-\d*-/-/g};
	$last=~s/^,//g;
	return $last;
};
###############################################################################################
sub get_uniq
{
	my @TMP=@_;
	my (%uniq,@tmp);
	foreach my $A (@TMP)
	{
		if (not exists $uniq{$A})
		{
			push @tmp,$A;
			$uniq{$A}=1;
		};
	};
	return @tmp;
};
###############################################################################################

sub get_report_sh
{
	my ($num,$level,$od,$out)=@_;
	my ($file,$sex)=&get_sample_file($num);
	if (!$file || !-f $file)
	{
		return "NA";
	}else
	{
		my $id=dirname($file);$id=dirname($id);
		my $pro=`grep $num /share/nas1/wangxf/Basecall/All.RAW |grep NT|tail -1|cut -f 4`;chomp $pro;
		if ($file=~/level.report.txt/)
		{
			my $batch=`grep ^batch $id/conf.txt |cut -f 3`;chomp $batch;
			my $outname="$num\_$pro\_b${batch}A\_Poly_v1.5.xlsx";
			if ($level==5)
			{
				$file=~s/tot_3_level.report.txt/tot_5_level.report.txt/;
			};
			$out="perl /share/nas1/heh/bin/Report/GeneticForSmallSingle_v2tov1_v2.0.pl -i $file -id $id -b $batch -all -o $od/Reports/$outname\n";
		}else
		{
			my $batch=`grep ^batch $id/conf.txt |cut -f 2`;chomp $batch;
			my $outname="$num\_$pro\_b${batch}A\_Poly_v1.xlsx";
			if ($level ==5)
			{
				$file=~s/secondary_merge_best_convert_of_SNP_and_Indel.longest.add_sampleID.txt/secondary_merge_best_convert_of_SNP_and_Indel.noFilter.longest.add_sampleID.txt/;
			};
			$out="perl /share/nas1/heh/bin/Report/GeneticReport2ExcelAB.pl -i $file -id $id -b $batch -all -o $od/Reports/$outname\n";
		};
		return $out;
	};
};
###############################################################################################
sub get_sample_file
{
	my ($list,$dir,$sex)=@_;
	my @tmp=(glob "/share/nas1/database/sample/@{[substr($list,0,2)]}*/$list*/Result/secondary_merge_best_convert_of_SNP_and_Indel.longest.add_sampleID.txt");
	$dir=(grep /[^old]/,@tmp)[0];
	if (!$dir)
	{
		my @tmp2=(glob "/share/nas1/database/sample/@{[substr($list,0,2)]}*/$list*/3.3_variation_annotation/tot_3_level.report.txt");
		$dir=(grep /[^old]/,@tmp2)[0];
	};
	if ($dir && $dir=~/2.3_function_region_map_stat/)
	{
		my $sexfile=$dir;		$sexfile=~s/2.3_function_region_map_stat\/bed_depth_coverage.txt/4.1_QC\/QC_report.txt/;
		$sex=`grep sex $sexfile|cut -f 1|cut -d ":" -f 2`;chomp $sex;
	}elsif($dir)
	{
		my $sexfile=$dir;		$sexfile=~s/function_region\/bed_depth.average.txt/map_stat\/sex_test.out/;
		$sex=`cut -f 3 $sexfile`;chomp $sex;
	};
	if ($dir && $sex)
	{
		return ("$dir","$sex");
	};
};
###############################################################################################
sub get_gene_cov_dep
{
	my ($cov_dep_file,$hash,%result)=@_;
	open L,"$cov_dep_file" or die"$!";
	while(<L>)
	{
		chomp;
		next if /^$/;
		my @array=split;
		my ($gene)=$_=~m/Gname=(.*?);/;
		next if (!$gene);
		if (not exists $result{$gene})
		{
			foreach my $A(keys %result)
			{
				my $coverage=$result{$A}{'cover_length'}/$result{$A}{'length'};
				my $average=$result{$A}{'depth'}/$result{$A}{'length'};
				$hash->{$A}="$coverage\t$average";
				undef %result;
			};
			$result{$gene}{'cover_length'}+=(split /\//,$array[-2])[0];
			$result{$gene}{'length'}+=(split /\//,$array[-2])[1];
			$result{$gene}{'depth'}+=(split /\//,$array[-4])[0];
		}else
		{
			$result{$gene}{'cover_length'}+=(split /\//,$array[-2])[0];
			$result{$gene}{'length'}+=(split /\//,$array[-2])[1];
			$result{$gene}{'depth'}+=(split /\//,$array[-4])[0];
		};
	};
	close L;
	foreach my $A(keys %result)
	{
		my $coverage=$result{$A}{'cover_length'}/$result{$A}{'length'};
		my $average=$result{$A}{'depth'}/$result{$A}{'length'};
		$hash->{$A}="$coverage\t$average";
		undef %result;
	};
};
###############################################################################################
sub get_gene_10X_cov	#######&exon::get_gene_10X_cov($bed_depth,\%gene_bed,\%cov_dep,\%genecov_10X);
{
	my ($gene,$depth,$od,$hash,%gene_stat)=@_;
	open L,"$depth" or die;
	my $time=time;
	open M,"> $od/$time\.bed" or die;
	while (my $DEPTH=<L>)
	{
		chomp $DEPTH;
		next if ($DEPTH=~/^$/);
		my @array=split /\t/,$DEPTH;
		next if ($array[2]<10);
		print M "$array[0]\t$array[1]\t$array[1]\t1\n";
	};
	close L;
	close M;
	############################################
	open N,"$gene" or die;
	my $time2=time;
	open Z,"> $od/$time2\.bed" or die;
	while (<N>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		$arr[1]+=1;
		print Z "$arr[0]\t$arr[1]\t$arr[2]\n";
	};
	close N;
	close Z;
	`bedtools window -a $od/$time2\.bed -b $od/$time\.bed -w 0 > $od/$time2\.bed.res1`;
	`bedtools map -a $gene -b $od/$time2\.bed.res1 -c 7 -o sum > $od/$time2\.bed.res2`;
	###############################################
	open K,"$od/$time2\.bed.res2" or die;
	while (<K>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		my ($gene)=$_=~m/Gname=(.*?);/;
		next if (!$gene);
		my $length=(split /\//,$arr[-3])[1];
		$gene_stat{$gene}{len}+=$length;
		if ($arr[-1] =~/\d+/)
		{
			if ($arr[-1]>$length)
			{
				$gene_stat{$gene}{big10}+=$length;
			}else
			{
				$gene_stat{$gene}{big10}+=$arr[-1];
			};
		};
	};
	close K;
	foreach my $GENE (sort keys %gene_stat)
	{
		my $value=0;
		if (exists $gene_stat{$GENE}{big10})
		{
			$value=$gene_stat{$GENE}{big10};
		};
		my $ratio=$value/$gene_stat{$GENE}{len};
		$ratio=sprintf("%.4f",$ratio);
		$hash->{$GENE}="$ratio\t$value\t$gene_stat{$GENE}{len}";
	};
	`rm $od/$time2\.bed $od/$time\.bed $od/$time2\.bed.res1 $od/$time2\.bed.res2`;
};
##########################################################################
sub get_vcf_depth			##########&get_vcf_depth($file,\%hash);
{
	my ($file,$hash)=@_;
	open L,"$file" or die;
	while (<L>)
	{
		chomp;
		next if (/^$/ || /^\#/);
		my @arr=split /\t/,$_;
		my @ALTS=split /\,/,$arr[4];
		my ($MQ)=$_=~m/MQ=(.*?);/;
		my ($chr,$posori,$rs,$refori,$depth,$totdepth)=@arr[0,1,2,3,9];
		($depth,$totdepth)=(split /\:/,$depth)[1,2];
		my @depth=split /\,/,$depth;
		foreach my $i (0..@ALTS-1)
		{
			my $start=$posori;
			my $end=$posori;
			my $ref=$refori;
			my $alt=$ALTS[$i];
			my $ratio;
			if ($totdepth eq '0')
			{
				$ratio=0;
			}elsif($totdepth=~/^\d+$/)
			{
				$ratio=$depth[$i+1]/$totdepth;
			}else
			{
				next;
			};
			$ratio=sprintf("%.4f",$ratio);
			my $depout="$depth[$i+1]".'/'."$totdepth".'='."$ratio";
			if ($ref=~/^[ATCG]$/ && $alt=~/^[ATCG]$/)
			{
				$hash->{"$chr-$start-$end"}{$ref}{$alt}="$rs\t$depout\t$MQ";
			}elsif(length$ref==1 && length$alt>1)
			{
				$end=$start+1;
				$ref='-';
				$alt=~s/^[ATCG]//;
				$hash->{"$chr-$start-$end"}{$ref}{$alt}="$rs\t$depout\t$MQ";
			}elsif(length$alt==1 && length$ref>1)
			{
				$start+=1;
				$ref=~s/^[ATCG]//;
				$alt="-";
				$end+=length$ref;
				$hash->{"$chr-$start-$end"}{$ref}{$alt}="$rs\t$depout\t$MQ";
			}else
			{
				#####################################################  值得注意的是 annovar 格式转换也有不给转换的情况，故原位置也保存，
				my $end0=$start+(length$ref)-1;
				$hash->{"$chr-$start-$end0"}{$ref}{$alt}="$rs\t$depout\t$MQ";
				####################################
				if ($ref=~/^$alt/)
				{
					$ref=~s/^$alt//;
					$start+=length$alt;
					$end=$start+(length $ref)-1;
					$alt='-';
					$hash->{"$chr-$start-$end"}{$ref}{$alt}="$rs\t$depout\t$MQ";
				}elsif($alt=~/^$ref/)
				{
					$alt=~s/^$ref//;
					$start+=(length $ref)-1;
					$end=$start+1;
					$ref='-';
					$hash->{"$chr-$start-$end"}{$ref}{$alt}="$rs\t$depout\t$MQ";
				}else
				{
					my @ref=split //,$ref;
					my @alt=split //,$alt;
					my ($start1,$start2,$end1,$end2)=($start,$start,$end,$end);
					my ($ref1,$ref2,$alt1,$alt2)=($ref,$ref,$alt,$alt);
					for (my $i=0;$i<@ref && $i<@alt;$i++)	#############正向比较
					{
						if ($ref[$i] eq $alt[$i])
						{
							$ref1=~s/^[ATCG]//;
							$alt1=~s/^[ATCG]//;
							next;
						}else
						{
							$ref1='-'if($ref1=~/^$/);
							$alt1='-'if($alt1=~/^$/);
							if ($alt1 eq '-')			#############del
							{
								$start1+=$i;
								$end1=$start1+(length$ref1)-1;
							}elsif($ref1 eq '-')		##############ins
							{
								$start1+=$i-1;
								$end1=$start1+1;
							}else						##############delins
							{
								$start1+=$i;
								$end1=$start1+(length$ref1)-1;
							};
							last;
						};
					};
					$hash->{"$chr-$start1-$end1"}{$ref1}{$alt1}="$rs\t$depout\t$MQ";
					#####################################################
					for (my $i=1;$i<=@ref && $i<=@alt;$i++)	#############反向比较
					{
						if ($ref[-$i] eq $alt[-$i])
						{
							$ref2=~s/[ATCG]$//;
							$alt2=~s/[ATCG]$//;
						}else
						{
							$ref2='-'if($ref2=~/^$/);
							$alt2='-'if($alt2=~/^$/);
							if ($alt2 eq '-')			#############del
							{
								$end2=$start2+(length$ref2)-1;
							}elsif($ref2 eq '-')		##############ins
							{
								$start2-=1;
							}else						##############delins
							{
								$end2=$start2+(length$ref2)-1;
							};
							last;
						};
					};
					$hash->{"$chr-$start2-$end2"}{$ref2}{$alt2}="$rs\t$depout\t$MQ";
				};
			};
		};
	};
	close L;
};
###################################################################################
sub get_chrcnv
{
	my($cnvfile,$ids,$hash,$chrlenfile,$chrlen)=@_;
	for (my $i=0; $i<@{$cnvfile};$i++)
	{
		my $od=dirname($$cnvfile[$i]);
		$od=dirname($od);
		my $chrcnvfile="$od/QC/QC.stat";
		if (!-f $chrcnvfile)
		{
			print "\nno_QC_file\t$chrcnvfile\n";
			next;
		}else
		{
			open L,"$chrcnvfile" or die;
			while (<L>)
			{
				chomp;
				next if(/^$/ || $_!~/^NC/);
				my @arr=split /\t/,$_;
				#next if ($arr[3]=~/YES/);
				$arr[0]=&chr_convert($arr[0]);
				my $ave=(split /\-/,$arr[1])[0];
				my $ratio=$arr[2]/$ave;
				if ($ratio<0.1)
				{
					$hash->{$arr[0]}{$$ids[$i]}="loss2";
				}elsif ($ratio<0.6)
				{
					$hash->{$arr[0]}{$$ids[$i]}="loss1";
				}elsif ($ratio>1.8)
				{
					$hash->{$arr[0]}{$$ids[$i]}="gain2";
				}elsif ($ratio>1.4)
				{
					$hash->{$arr[0]}{$$ids[$i]}="gain1";
				};
			};
			close L;
		};
	};
	open L,"$chrlenfile" or die;
	while (<L>)
	{
		chomp;
		next if(/^$/ || $_!~/^NC/);
		my @arr=split /\t/,$_;
		$arr[0]=&chr_convert($arr[0]);
		$chrlen->{$arr[0]}="$arr[2]";
	};
	close L;
};