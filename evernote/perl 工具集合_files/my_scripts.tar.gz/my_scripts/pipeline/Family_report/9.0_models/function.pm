package function;
{
        $Path::sub_function_package::VERSION = '0.1';
}
use strict;
use File::Basename qw(basename dirname);
use Encode;
use Excel::Writer::XLSX;
use Spreadsheet::WriteExcel;
use Spreadsheet::Read;
use Data::Dumper;
sub sub_format_datetime{#Time calculation subroutine
	my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
	$wday = $yday = $isdst = 0;
	sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}

sub path{ #$pavfile=&ABSOLUTE_DIR($pavfile);获取绝对路径
	my $cur_dir=`pwd`;chomp($cur_dir);
	my ($in)=@_;
	my $return="";

	if(-f $in){
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;chomp $dir;
		$return="$dir/$file";
	}elsif(-d $in){
		chdir $in;$return=`pwd`;chomp $return;
	}else{
		warn "Warning just for file and dir\n";
		exit;
	}
	chdir $cur_dir;
	return $return;
};

sub rmdup{######\@A rm \@B###   去除数组A 中的数组 B
my ($x, $y)=@_;
my @AA=@{$x};my @BB=@{$y};
my @lalal;
	foreach my $AAA (@AA)
	{
	my $tag=0;
		foreach my $BBB(@BB)
		{
		if ($AAA=~/$BBB/){$tag=1;last}
		}
	if ($tag==0){push @lalal,$AAA};
	};
	return @lalal;
};

sub get_abbr {		###########合并所有区间：eg（1,2,3,4 => 1-4）；
my $last;
@_=sort {$a <=> $b} @_;
for (my $i=0;$i<@_ ;$i+=1)
{
        if ((exists $_[$i-1]) && (($_[$i]-$_[$i-1])==1))
        {
                $last.="-$_[$i]";
        }else
        {
                $last.=",$_[$i]";
        }
};
for (@_){$last=~s/-\d*-/-/g};
$last=~s/^,//g;
return $last;
};

sub intersect{		#########(7,10,8,20)
my ($a,$b,$c,$d)=@_[0,1,2,3];
if($d<$a || $c>$b){return 'N'}else{return 'Y'}
};


sub add_comma{
my $b=reverse $_[0];
my @arr=split //,$b;
my @tmp;
	for (my $i=0;$i<@arr ;$i+=3)
	{
		if (exists $arr[$i]) {push (@tmp,$arr[$i])};
		if (exists $arr[$i+1]) {push (@tmp,$arr[$i+1])};
		if (exists $arr[$i+2]) {push (@tmp,$arr[$i+2])};
		if (exists $arr[$i+3]) {push (@tmp,",")};
	};
my $last=join ("",@tmp);
$last=reverse $last;
return $last;
}


my %chrconvert1=(
        "NC_000001.10"=>"chr1","NC_000002.11"=>"chr2","NC_000003.11"=>"chr3","NC_000004.11"=>"chr4","NC_000005.9"=> "chr5","NC_000006.11"=>"chr6",
        "NC_000007.13"=>"chr7","NC_000008.10"=>"chr8","NC_000009.11"=>"chr9","NC_000010.10"=>"chr10","NC_000011.9"=> "chr11","NC_000012.11"=>"chr12",
        "NC_000013.10"=>"chr13","NC_000014.8"=>"chr14","NC_000015.9"=>"chr15","NC_000016.9"=>"chr16","NC_000017.10"=>"chr17","NC_000018.9"=>"chr18" ,
        "NC_000019.9"=>"chr19","NC_000020.10"=>"chr20", "NC_000021.8"=>"chr21", "NC_000022.10"=>"chr22","NC_000023.10" =>"chrX" ,"NC_000024.9"=>"chrY",
	"chr1"=>"NC_000001.10","chr2"=>"NC_000002.11","chr3"=>"NC_000003.11","chr4"=>"NC_000004.11","chr5"=> "NC_000005.9","chr6"=>"NC_000006.11",
        "chr7"=>"NC_000007.13","chr8"=>"NC_000008.10","chr9"=>"NC_000009.11","chr10"=>"NC_000010.10","chr11"=> "NC_000011.9","chr12"=>"NC_000012.11",
        "chr13"=>"NC_000013.10","chr14"=> "NC_000014.8","chr15"=> "NC_000015.9","chr16"=> "NC_000016.9","chr17"=>"NC_000017.10","chr18"=> "NC_000018.9",
        "chr19" =>"NC_000019.9","chr20" =>"NC_000020.10","chr21" =>"NC_000021.8","chr22" =>"NC_000022.10","chrX"  =>"NC_000023.10","chrY"  =>"NC_000024.9",
        );




1;
