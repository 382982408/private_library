package standard_family;
{
		$Path::standard_family::VERSION = '0.1';
};
#!/usr/bin/perl -w
use lib "/share/ofs1a/EXdev/WES_pipe_v1_1.1/pipeline/Family_report/9.0_models/lib64/perl5/";
use lib "/share/ofs1a/EXdev/WES_pipe_v1_1.1/pipeline/Family_report/9.0_models/share/perl5/";
use strict;
use Cwd;
use JSON;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

sub path{
	my $cur_dir=`pwd`;
	chomp($cur_dir);
	my ($in)=@_;
	my $return="";
	if(-f $in){
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;chomp $dir;
		$return="$dir/$file";
	}elsif(-d $in){
		chdir $in;$return=`pwd`;chomp $return;
	}else{
		warn "Warning just for file and dir:$in\n";
		exit;
	}
	chdir $cur_dir;
	return $return;
};
##########################################################################
sub chr_convert
{
	my $chr=(split /0{4,5}|\./,$_[0])[1];
	if ($chr eq '23') {$chr='X'}
	elsif($chr eq '24'){$chr='Y'};
	return "chr$chr";
};
###############################################################################################
sub get_uniq
{
	my @TMP=@_;
	my (%uniq,@tmp);
	foreach my $A (@TMP)
	{
		if (not exists $uniq{$A})
		{
			push @tmp,$A;
			$uniq{$A}=1;
		};
	};
	return @tmp;
};
##########################################################################
sub get_effec_num
{
	my ($a,$res)=@_;
	$a=~s/^ | $//g;
	if ($a=~/^(\d+\.)(0*)(\d+)$/)
	{
		my $bef=$1;
		my $zero=$2;
		my $aft=$3;
		if ($aft==0)
		{
			$zero.=0;
			$aft="";
		};
		my ($tmptwo,$three);
		if (length($aft)>=3)
		{
			$tmptwo=substr($aft,0,2);
			$three=substr($aft,2,1);
			if ($three>=5) {++$tmptwo};
			$res=$bef.$zero.$tmptwo;
		}elsif(length($aft)>0)
		{
			$tmptwo=$aft;
			while (length($tmptwo)<2)
			{
				$tmptwo.=0;
			};
			$res=$bef.$zero.$tmptwo;
		}else
		{
			$res=$bef;
			$res=~s/\.$//;
		};
		while ($res=~/0$|\.$/)
		{
			$res=~s/0$|\.$//g;
		};
		if ($res=~/^$/)
		{
			$res=0;
		};
		return $res;
	}else
	{
		$res=$a;
		return $res;
	};
};
##########################################################################
sub input
{
	my ($level,$input,$file,$bam,$rbam,$genecov,$rmgene_cov,$conf,$stat,$rmstat,$rmdupratio,$depthfile,$rmdepthfile,$name,$bestnm,$getdata)=@_;
####my ($level,$input,$file,$bam,$rbam,$genecov,$rmgene_cov,$rmdepfile,$name,$bestnm,$chr_cnv,$exon_cnv)=@_;

	for (my $i=0;$i<@{$input} ;$i++)
	{
		my $indir;
		if (-d $$input[$i])
		{
			$indir=&path($$input[$i]);
		}elsif($file && -f $$file[$i])
		{
			$$file[$i]=&path($$file[$i]);
		}else
		{
			print STDERR "\n\tplease check your inputs !\t$$input[$i]\n";exit;
		};
		if($indir)
		{
			$$input[$i]=$indir;
			if (!$file || (! $$file[$i]) || ($$file[$i] && !-f $$file[$i]))
			{
				$$file[$i]="$indir/3.3_variation_annotation/tot_3_level.report.txt" if($level==3);
				$$file[$i]="$indir/3.3_variation_annotation/tot_5_level.report.txt" if($level==5);
			};
			$$bam[$i]="$indir/1.2_Merged_bam/sum_merged.bam";
			$$rbam[$i]="$indir/1.2_Merged_bam/sum_merged.rmdup.bam";
			$$genecov[$i]="$indir/2.3_function_region_map_stat/gene_coverage_depth.txt";
			$$rmgene_cov[$i]="$indir/2.3_function_region_map_stat/gene_coverage_depth_rmdup.txt";
			$$conf[$i]="$indir/conf.txt";
			$$stat[$i]="$indir/2.1_map_stat/stat_report.txt";
			$$rmstat[$i]="$indir/2.1_map_stat/stat_report.txt";
			$$rmdupratio[$i]="$indir/1.2_Merged_bam/rmdup_stat.txt";
			$$depthfile[$i]="$indir/2.1_map_stat/bed_depth.txt";
			$$rmdepthfile[$i]="$indir/2.2_rmdup_map_stat/bed_depth.txt";
				my $tmp=basename($indir);
			$$name[$i]=(split /[-_.]/,$tmp)[0];
			$$bestnm[$i]="$indir/3.3_variation_annotation/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication.genetictype.rmdepth.bestNM.Aadd_dis_path";
			$$getdata{$$name[$i]}=$i;
			$$getdata{$i}=$$name[$i];
		}else
		{
			print STDERR "\n\tplease check your inputs !\t$$input[$i]\n";exit;
		};
	};
};
##########################################################################
sub get_fam_relative
{
	my ($conf_file,$number,$stdout)=@_;
	$number=(split /\D+/,$number)[0];
	my $od=dirname($stdout);
	my $pro;
	my $num=`grep $number $conf_file|wc -l`;chomp $num;
	if ($num>1)
	{
		if (`grep $number $conf_file|grep F`)
		{
			$pro=`grep $number $conf_file|grep -E 'NT0|WGS'|grep F|tail -1|cut -f 3`;chomp $pro;	
		}else
		{
			$pro=`grep $number $conf_file|grep -E 'NT0|WGS'|tail -1|cut -f 3`;chomp $pro;
		};
	}elsif($num==1)
	{
		$pro=`grep $number $conf_file|tail -1|cut -f 3`;chomp $pro;
	}else
	{
		print STDERR "$number not in ALL_RAW \n";
		return 0;
	};

	my $outfile="$od/$number\_origin.txt";
#	if (!-f $outfile)
	{
		`wget -O $outfile -P ./ http://sample.zhiyindongfang.com/sample-app/desktop/sale/SpecialExam/findSpecialExamList.action?taskCode=$number\_$pro`;
	};
	my $jsfile="$od/$number\_json.txt";
	&read_js($outfile,$jsfile);

	my @springs=split /\n/,`grep -v callName $jsfile`;

	open OUT,">$stdout" or die;
	my $i=1;
	foreach (@springs)
	{
		chomp $_;
		my @result;
		my @arr=split /\t/,$_;
		my $realnumber;
		if (`grep $arr[-1] $conf_file|grep F`)
		{
			$realnumber=`grep $arr[-1] $conf_file|grep -v Nmt|grep F|tail -1|cut -f 2`;
		}elsif(`grep $arr[-1] $conf_file`)
		{
			$realnumber=`grep $arr[-1] $conf_file|grep -v Nmt|tail -1|cut -f 2`;
		}else
		{
			print STDERR "\n\t$arr[-1] not in ALL_RAW !!!\n\n";
			print OUT "$arr[-1]\n";
			next;
		};
		chomp $realnumber;
		push @result,$realnumber,$arr[1];

		if ($arr[5]=~/女/)
		{
			push @result,'FM';
		}elsif($arr[5]=~/男/)
		{
			push @result,'M';
		}else
		{
			my $two=substr($arr[-1],0,2);
			my $sex_file=(glob "/share/ofs1a/prod/sample/$two*/$arr[-1]*/4.1_QC/QC_report.txt")[0];
			if (!$sex_file || !-f $sex_file)
			{
				print STDERR "$arr[-1]\tno_sex\n";
				push @result,'FM';
#				die;
			}else
			{
				if (`grep sex $sex_file` =~/XX/)
				{
					push @result,'FM';
				}elsif(`grep sex $sex_file` =~/XY/)
				{
					push @result,'M';
				}else
				{
					print STDERR "$arr[-1]\tno_sex\n";
					die;
				};
			};
		};
		push @result,$arr[4],$arr[4],$arr[3];
		
		my $relate='NA';
		if (($arr[0] eq '先证者') || ($arr[0] eq 'NA'))
		{
			if ($result[2] eq 'M')
			{
				push @result,"先证者男";
				$relate='son';
			}else
			{
				push @result,"先证者女";
				$relate='daughter';
			};
		}elsif($arr[0] eq "父")
		{
			push @result,$arr[0].$arr[2];
			$relate='father';
		}elsif($arr[0] eq "母")
		{
			push @result,$arr[0].$arr[2];
			$relate='mother';
		}else
		{
			push @result,"成员$i\-$arr[0]".$arr[2];
			$i++;
			##################
			if ($arr[0]=~/兄|弟|姐|妹/)
			{
				if($arr[2]=~/患者|轻微表型/)
				{
					if ($result[2] eq 'FM')
					{
						$relate='daughter';
					}elsif($result[2] eq 'M')
					{
						$relate='son';
					};
				}else
				{
					$relate='other';
				};
			}else
			{
				$relate='other';
			};
		};
		push @result,$arr[1];

		if ($arr[2]=~/患者/)
		{
			push @result,"患者","4";
		}elsif($arr[2]=~/轻微表型/)
		{
			push @result,"轻微表型","2";
		}elsif($arr[2]=~/正常/)
		{
			push @result,"正常","0";
		}elsif($arr[2]=~/其它表型/)
		{
			push @result,"正常","0";
		};
		push @result,$relate;

		my $res=join "\t",@result;
		print OUT "$res\n";
	};
	close OUT;
};
#########################################
sub read_js
{
	my($js_file,$outfile)=@_;
	#################
	my $js;
	open L,"$js_file" or die "\n\t:no_file:$js_file\n";
	while(<L>) 
	{
		$js .= "$_";
	};
	close L;
	#################
	open OUT,">$outfile" or die;
	my $obj = new JSON ->decode($js);
	my @head=("callName","checkerName","disease_condition","examCode","family_code","gender","member_sequence","report_code","resource_code");
	print OUT (join "\t",@head),"\n";
	foreach my $key1 (sort keys %{$obj})
	{
		next if (ref($obj->{$key1}) ne "ARRAY");
		for(my $num=0; $num<@{$obj->{$key1}}; $num++)###(0..@{$obj->{$key1}})
		{
			if ((ref($obj->{$key1}[$num]) eq 'HASH'))
			{
				foreach my $key2 (@head)
				{
					if(not exists $obj->{$key1}[$num]{$key2})
					{
						$obj->{$key1}[$num]{$key2}="NA";
					};
					print OUT "$obj->{$key1}[$num]{$key2}\t";
				};
			};
			print OUT "\n";
		};
	};
	close OUT;
};
##########################################################################
sub read_sinfo		###############&standard_family::read_sinfo($Sinfo,\%relation);
{
	my ($info,$hash)=@_;
	open L,"$info" or die;
	while (<L>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t+/,$_;
		($arr[0])=split /xb|sl|zj|xj|\s+|\_/,$arr[0];
		$hash->{$arr[0]}{'sex'}=$arr[2];		#######性别
		$hash->{$arr[0]}{'path'}=$arr[9];		#######是否患病
		$hash->{$arr[0]}{'name_ms'}=$arr[6];		#######样本名
		$hash->{$arr[0]}{'status'}=$arr[10];		#######家系关系
	};
	close L;
};
##########################################################################
#config(\@sampname,\@genecov,$genepos,$genestrand,\%geneinf,$omomphen,\%omiminf,$for_report,$MS,\%translation);
sub config{
	my ($sampname,$gene,$genepos,$genestrand,$geneinf,$omim,$omiminf,$for_report,$MS,$translation)=@_;
		for (my $i=0;$i<@{$gene};$i++)
		{
			open L,"$$gene[$i]" or next;
			while (<L>)
			{
				chomp;	next if (/^$/);	my @arr=split /\t/,$_;
				$arr[1]=sprintf("%.2f",$arr[1]);$arr[2]=sprintf("%.2f",$arr[2]);
				$geneinf->{$arr[0]}{$$sampname[$i]}{'cov'}=$arr[1];
				$geneinf->{$arr[0]}{$$sampname[$i]}{'dep'}=$arr[2];
				$geneinf->{$arr[0]}{$$sampname[$i]}{'cov10X'}=$arr[3];
			};
			close L;
		};
		##########################################
		open L,"$genepos" or die;
		<L>;
		while (<L>)
		{
			chomp;	next if (/^$/ || /^\#/);
			my @arr=split /\t/,$_;
			if ($arr[1] eq '-') {$arr[2]='NA'};
			$geneinf->{$arr[1]}{'id'}=$arr[0];
			$geneinf->{$arr[1]}{'pos'}=$arr[2];
		};
		close L;
		################################################
		open L,"$genestrand" or die;
		while (<L>)
		{
			chomp;	next if (/^$/);
			my @arr=split /\t/,$_;
			$geneinf->{$arr[0]}{'fx'}=$arr[1];
		};
		close L;
		################################################
		open L,"$omim" or die "\t\tAttention:\tplease check the OMIM file !\n\n";
		while (<L>)
		{
			chomp;
			next if (/^$/);
			my ($gene,$gene_arr,$gene_OMIM,$dis_OMIM,$inherit,$disease)=split /\t/,$_;
			next if(!defined $gene || !defined$gene_OMIM);
			if (!$inherit || $inherit!~/[A-Z]+/)
			{
				$inherit="NA";
			};
			push @{$omiminf->{omim}{$dis_OMIM}},"$gene|$gene_OMIM|$dis_OMIM|$inherit|$disease";
			push @{$omiminf->{gene}{$gene}},"$gene|$gene_OMIM|$dis_OMIM|$inherit|$disease";
		};
		close L;
		##########################################
		open L,"$for_report" or die;
		while (<L>)
		{
			last if (/^LAST/);
			chomp;
			next if (/^$/ || /^\#/);
			my @arr=split /\t/,$_;
			$translation->{$arr[0]}=$arr[1];
		};
		close L;
		###############################################
		open L,"$MS" or die;
		while (<L>)
		{
			chomp;
			next if (/^$/);
			my @arr=split /\t/,$_;
			if ($_=~/err/)
			{
				next;
				$arr[1]=100;
				$arr[2]="err";
				$arr[3]="err";
			};
			$translation->{$arr[0]}="$arr[1]|$arr[2]|$arr[3]";
		};
		close L;
};
####################################################################################################################
my %chrconvert1=(
        "NC_000001.10"=>"chr1","NC_000002.11"=>"chr2","NC_000003.11"=>"chr3","NC_000004.11"=>"chr4","NC_000005.9"=> "chr5","NC_000006.11"=>"chr6",
        "NC_000007.13"=>"chr7","NC_000008.10"=>"chr8","NC_000009.11"=>"chr9","NC_000010.10"=>"chr10","NC_000011.9"=> "chr11","NC_000012.11"=>"chr12",
        "NC_000013.10"=>"chr13","NC_000014.8"=>"chr14","NC_000015.9"=>"chr15","NC_000016.9"=>"chr16","NC_000017.10"=>"chr17","NC_000018.9"=>"chr18" ,
        "NC_000019.9"=>"chr19","NC_000020.10"=>"chr20", "NC_000021.8"=>"chr21", "NC_000022.10"=>"chr22","NC_000023.10" =>"chrX" ,"NC_000024.9"=>"chrY",
        "chr1"=>"NC_000001.10","chr2"=>"NC_000002.11","chr3"=>"NC_000003.11","chr4"=>"NC_000004.11","chr5"=> "NC_000005.9","chr6"=>"NC_000006.11",
        "chr7"=>"NC_000007.13","chr8"=>"NC_000008.10","chr9"=>"NC_000009.11","chr10"=>"NC_000010.10","chr11"=> "NC_000011.9","chr12"=>"NC_000012.11",
        "chr13"=>"NC_000013.10","chr14"=> "NC_000014.8","chr15"=> "NC_000015.9","chr16"=> "NC_000016.9","chr17"=>"NC_000017.10","chr18"=> "NC_000018.9",
        "chr19" =>"NC_000019.9","chr20" =>"NC_000020.10","chr21" =>"NC_000021.8","chr22" =>"NC_000022.10","chrX"  =>"NC_000023.10","chrY"  =>"NC_000024.9",
);
sub get_cominfo		#######	&standard_family::get_cominfo(\@infile,\%geneinf,\%phenotype,\%translation,\%num2type,\%com);
{	
	my ($samname,$snps,$geneinfo,$omiminf,$translation,$com,$singelresult,$open,$genemut,$befdepth,$rmdepth)=@_;
	my $return="";
	my %tmpexon1;
	my %tmpexon2;
	my %for_rmdup;
	my %for_combine;
	my %for_detail;
	my $wrong_tag=1;
	my $wrong_file;
	for (my $i=0;$i<@{$snps} ;$i++)
	{
		open L,"$$snps[$i]" or die "nofile:$$snps[$i]\n\n";
		<L>;
		my $ssrsize="4";
		while (<L>)
		{
			chomp;
#			next if ($_!~/89970013/);
			next if (/^$/);
			my @arr=split /\t/,$_;
			my ($gene6,$genefx7)=(split /\|/,$arr[1]);
			my @tmp_chr=split /[:]/,$arr[4];
			if ($tmp_chr[0]=~/NC/)
			{
				$tmp_chr[0]=&chr_convert($tmp_chr[0]);
			};
			$arr[4]=join ":",@tmp_chr;

			my $bianhao1=&get_mut_compile($arr[4],$arr[6],$arr[1]);
			if ($bianhao1=~/err/)
			{
				print STDERR "error: get err mut_tag:$_\n";
				$return.="error: get err mut_tag:$_\n";
				next;
			};
			my $key=$bianhao1;

			my ($muttot2,$mutdep3,$mutrat4,$aftmuttot39,$aftmutdep40,$aftmutrat41,$hete11,$hetechina);
				if ($arr[22]=~/(.*)\:(.*)\=(.*)\/(.*);(.*)\=(.*)\/(.*)/)
				{
					$hete11=$1;
					$muttot2=$4;
					$mutdep3=$3;
					$mutrat4=$2;
					$aftmuttot39=$7;
					$aftmutdep40=$6;
					$aftmutrat41=$5;
				};
				next if($mutrat4=~/NA/);
				$mutrat4=sprintf ("%.2f",$mutrat4);			$aftmutrat41=sprintf ("%.2f",$aftmutrat41);
				my $yuanxu5=(split /[-_]/,$arr[0])[0];
				my $chrpos8="$arr[4]";
				my $cpos9=$arr[6];
				my $animo10=$arr[7];
				my $type12=$arr[8];if (exists $translation->{$type12}) {$type12=$translation->{$type12}};
				my $LEVEL13=$arr[21];
				if ($LEVEL13!~/^\d+$/)
				{
					print STDERR "\n\t$bianhao1 bio-level is error !\n";
					$return.="\n\t$bianhao1 bio-level is error !\n";
					next;
				};
				my $rs14=$arr[9];
				my $MAF15=$arr[10];
				my $Kren16=$arr[11];
				my $south17=$arr[12];
				my $north18=$arr[13];
				my ($meMAF19,$meMAF_dis)=split /\|/,$arr[14];if(!$meMAF_dis){$meMAF_dis='NA'};

				my $exacEA20=$arr[15];
				my $exacSA21=$arr[16];
				my $exacMAX22=$arr[17];
				my $ESP23=$arr[18];
				my $pub24=$arr[26];
					if ($pub24=~/dbSNP/)
					{
						$pub24=(split /dbSNP/,$pub24)[0];		##############dbSNP pubmedid 去掉
					};
					
				if ($pub24=~/\d+/)	################by luozw 20161027
				{
					my @tmp=$pub24=~m/\d+/g;
					$pub24=join ";",@tmp;
				}else
				{
					$pub24='NA';
				};

				my $HGMD25=$arr[31];
				my $CLINVAR26=$arr[28];
				my $OMIM27=$arr[29];
				my $SWISS28=$arr[30];
				my $Disease29='NA';
				my $relative30='NA';
					my $tmp1=$arr[19];
						if ($arr[8]=~/stoploss/i && $tmp1=~/15100|15300|15400/)
						{
							$tmp1.="E";
						}elsif($arr[8]=~/stopgain/i && $tmp1=~/15100|15300|15400/)
						{
							$tmp1.="X";
						};
				if (exists $translation->{$tmp1})
				{
					$relative30=$translation->{$tmp1};
					if ($relative30=~/有疾病相关报道/)
					{
#						&get_dis_revise(\$relative30,\$arr[26]);
					};
				}else
				{
					print STDERR "no_relative_information!\t$tmp1\n";
					die;
				};
				if (exists $translation->{"r$LEVEL13"}){$Disease29=$translation->{"r$LEVEL13"}};
				my $OMIMid32='NA';
				my $yichuan33='NA';
					if ($arr[23]=~/.*\|(\d+)\|(.*)/)
					{
						$OMIMid32=$1;
						$yichuan33=$2;
					};
				my $biaoxing31='NA';
				if (exists $omiminf->{omim}{$OMIMid32})
				{
					foreach my $AA (@{$omiminf->{omim}{$OMIMid32}})
					{
						my($t_gene,$t_geneomim,$t_disomim,$t_inherit,$t_phe)=split /\|/,$AA;
						if ($t_gene eq $gene6)
						{
							$biaoxing31=$t_phe;
							last;
						};
					};
				};
				my $yichuanlevel34=$arr[25];
				my $gene35=$gene6;
				my $geneid36='NA';if (exists $geneinfo->{$gene35}{'id'}){$geneid36=$geneinfo->{$gene35}{'id'}};
				my $genepos36='NA';if (exists $geneinfo->{$gene35}{'pos'}){$genepos36=$geneinfo->{$gene35}{'pos'}};
				my $coverage37='NA';if (exists $geneinfo->{$gene35}{$$samname[$i]}{'cov'}){$coverage37=$geneinfo->{$gene35}{$$samname[$i]}{'cov'}}else{$coverage37='NA'};
				my $depth38='NA';if (exists $geneinfo->{$gene35}{$$samname[$i]}{'dep'}){$depth38=$geneinfo->{$gene35}{$$samname[$i]}{'dep'}}else{$depth38='NA'};
				my $genenum42=$arr[2];
				my $disenum43=$arr[3];
				my $NM44=$arr[5];
				my $repeat45='NA';
					if ($chrpos8!~/\-/)
					{
						$repeat45='Snp';
					}else{$repeat45='Indel'};
###print "$arr[27]\t\t";
					if ($arr[27]=~/(.*)\|(.*)\=(.*)/)
					{
						my $temp1=$1;
						my $temp2=$2;
						my $temp3=$3;
						if ($temp1=~/YES/)
						{
							$repeat45.='Rep';
						}else{$repeat45.='No'};
						if ($temp3 > $ssrsize)
						{
							$repeat45.='Ssr';
						}else{$repeat45.='No';};
					};
###print "$repeat45\n";
				my $repeatssr=$repeat45;
				if (exists $translation->{$repeat45}){$repeat45=$translation->{$repeat45}};
				my $class46=$arr[19];
				my $yangxing46='NA';my $yangxtag='else';
					my $tmpMAF15=$MAF15;
					if ($tmpMAF15=~/NA/i){$tmpMAF15=0};
						###	$MAF15	$hete11	$yichuan33	$LEVEL13	$OMIMid32
					if ($tmpMAF15>0.01 && $hete11=~/hete|wild/i)
					{
						$yangxtag='mafgt1hete';
					}elsif($tmpMAF15>0.03 && $hete11=~/homo|hemi/i)
					{
						$yangxtag='mafgt3homo';
					}elsif($LEVEL13>=3)
					{
						$yangxtag='levelget3';
					}elsif($OMIMid32 eq 'NA')
					{
						$yangxtag='noomim';
					}elsif($yichuan33=~/XR/i && $hete11=~/hete|wild/i)
					{
						$yangxtag='chrarhete';
					}elsif($tmpMAF15<=0.01 && $hete11=~/hete|wild/i && ($yichuan33=~/AD|XD/i || $yichuan33 eq 'NA'))
					{
						$yangxtag='maflet1hetead';
					}elsif($tmpMAF15<=0.03 && $hete11=~/homo|hemi/i)
					{
						$yangxtag='maflet3homo';
					}elsif($LEVEL13<=2 && $yichuan33=~/XD|AD|Y|NA/i)
					{
						$yangxtag='levellet2ad';
					}else
					{
			###			print "$MAF15\t$hete11\t$yichuan33\t$LEVEL13\t$OMIMid32\n";#######都是maf<0.01 + AR + Hete + level<=2
					};
				if (exists $translation->{$yangxtag}){$yangxing46=$translation->{$yangxtag}};
#print "$hete11\t$yangxtag\t$yangxing46\t$yichuan33\n";
#die;


				my $deyiweihai47='NA';
				my $yiju48='NA';
				my $ACMG49='NA';
				my $ACMGyj50='NA';
				my ($provean,$polyphen_hdiv,$polyphen_hvar,$sift,$muttas,$mcup,$revel)=split /[\|\_]/,$arr[32];

				if ($provean =~/\d+/)
				{
					$provean=~s/D/deleterious/;$provean=~s/N/neutral/;
				}else
				{
					$provean='NA';
				};
				if ($polyphen_hdiv =~/\d+/)
				{
					$polyphen_hdiv=~s/D/porobably damaging/;$polyphen_hdiv=~s/P/possibly damaging/;$polyphen_hdiv=~s/B/benign/;
				}else
				{
					$polyphen_hdiv='NA';
				};
				if ($polyphen_hvar =~/\d+/)
				{
					$polyphen_hvar=~s/D/porobably damaging/;$polyphen_hvar=~s/P/possibly damaging/;$polyphen_hvar=~s/B/benign/;
				}else
				{
					$polyphen_hvar="NA";
				};
				if ($sift =~/\d+/)
				{
					$sift=~s/D/damaging/;$sift=~s/T/tolerated/;
				}else
				{
					$sift="NA";
				};
				if ($muttas =~/\d+/)
				{
					$muttas=~s/A/disease_causing_automatic/;$muttas=~s/D/disease_causing/;$muttas=~s/N/polymorphism/;$muttas=~s/P/polymorphism_automatic/;
				}else
				{
					$muttas="NA";
				};
				if ($mcup =~/\d+/)
				{
					$mcup=~s/D/deleterious/;$mcup=~s/N/neutral/;
				}else
				{
					$mcup='NA';
				};
				if ($revel =~/\d+/)
				{
					$revel=~s/D/deleterious/;$revel=~s/N/neutral/;
				}else
				{
					$revel='NA';
				};
				my $protein_predict="NA";
				my $construct_path="NA";
				&get_sift($arr[32],$type12,\$protein_predict,\$construct_path);
				
				my $SPLICE=lc($arr[33]);
				my (@for_family,@for_genetic);

				my $genome_mut=$arr[35];

				if ($hete11=~/Wild/i)
				{
					print STDERR "\n\terror:$$snps[$i]\n\tWild\t$_\n";
					die;
				};

				if ($open==0)
				{
###					$befdepth->{$key}{"$$samname[$i]"}="$mutrat4\=$mutdep3\/$muttot2";				###########my $d="$ratio\=$altdepth\/$T";
					$rmdepth->{$key}{"$$samname[$i]"}="$aftmutrat41\=$aftmutdep40\/$aftmuttot39";	########有可能最开始就call出来了，但是野生型，还是保留

					push @for_family,$bianhao1,$deyiweihai47,$yiju48;		#################放在注释com之前
					push @for_family,$gene6,$genefx7,$chrpos8,$cpos9,$animo10,$type12,$LEVEL13,$rs14,$MAF15;
					push @for_family,$Kren16,$south17,$north18,$meMAF19,$exacEA20,$exacSA21,$exacMAX22,$ESP23,$pub24,$HGMD25,$CLINVAR26,$OMIM27,$SWISS28;
					push @for_family,$provean,$sift,$polyphen_hdiv,$polyphen_hvar,$muttas,$Disease29,$relative30;
					push @for_family,$biaoxing31,$OMIMid32,$yichuan33,$geneid36,$genepos36,$NM44,"$repeatssr|$repeat45",$class46,$yangxing46,$meMAF_dis,$mcup,$revel,$protein_predict,$construct_path,$SPLICE,$genome_mut;
					if (not exists $com->{$key}{$OMIMid32})
					{
						$com->{$key}{$OMIMid32}=\@for_family;				############保证有先证者结果的存储先证者的结果
					};
				}elsif($open==1)
				{
					push @for_genetic,$bianhao1,$aftmuttot39,$aftmutdep40,$aftmutrat41,$hete11,$LEVEL13,$yichuanlevel34;
					push @for_genetic,$yuanxu5,$gene6,$genefx7,$chrpos8,$cpos9,$animo10,$type12,$rs14,$MAF15;
					push @for_genetic,$Kren16,$south17,$north18,$meMAF19,$exacEA20,$exacSA21,$exacMAX22,$ESP23,$pub24,$HGMD25,$CLINVAR26,$OMIM27,$SWISS28,$provean,$sift,$polyphen_hdiv,$polyphen_hvar,$muttas,$Disease29,$relative30;
					push @for_genetic,$biaoxing31,$OMIMid32,$yichuan33,$geneid36,$genepos36,$coverage37,$depth38;		#######$gene35,
					push @for_genetic,$muttot2,$mutdep3,$mutrat4,$genenum42,$disenum43,$NM44,$repeat45,$class46,$yangxing46,$meMAF_dis,$mcup,$revel,$protein_predict,$construct_path,$SPLICE,$genome_mut;

					$singelresult->{$key}{$OMIMid32}=\@for_genetic;

					if (($yichuan33 =~ /AR/) && $hete11=~/Hete/i && $LEVEL13<=3)
					{
						$genemut->{$gene6}{$key}{$LEVEL13}=1;
					};
				};
		};
		close L;
		#######################################################
		my $tagfile="$$snps[$i]\.muttag";
			$tagfile=~s/tot_3_level.report.txt/tot_5_level.report.txt/g;
		open L,"$tagfile" or die "no file :\t$tagfile\n";
		while (<L>)
		{
			chomp;
			next if (/^$/);
			my @arr=split /\t/,$_;
			$translation->{$arr[7]}=$arr[0];
		};
		close L;
		############################################################
		next if($open == 1);
		next if($$snps[$i]!~/NT01/ || $$snps[0]!~/F/);
		next if($$snps[$i]!~/NT01/ && $$snps[$i]!~/NCUF/);

		my $ID=(split /\D+/,$$samname[$i])[0];
		my $norm_tag=`grep $ID /share/ofs1a/prod/warriors_assemble.txt`;
		next if(!$norm_tag);
		##########################################
		open L,"/share/ofs1a/EXdev/WES_pipe_v1/db/Z_lzw_database/EXON.longestNM.bed" or die;
		my %exon;
		while (<L>)
		{
			chomp;
			next if(/^$/);
			my @arr=split /\t/,$_;
			$arr[0]=&chr_convert($arr[0]);
			$arr[1]-=1;
			my $exon=(split /\:/,$arr[-1])[-1];
			$exon{$arr[0]}{$arr[1]}{$arr[2]}=$exon;
		};
		close L;
		##########################################
		if ($i==0)
		{
				my $exonfile=$$snps[$i];
				$exonfile=~s/3.3_variation_annotation\/tot_3_level.report.txt|3.3_variation_annotation\/tot_5_level.report.txt/5.3_Batch_EXON_deletion\/positive_cnv_region_exon_reliable_anno/g;
				if (!-f $exonfile || !-f "$exonfile.muttag")
				{
					$wrong_tag=0;
					$wrong_file.="\t$exonfile\n";
					next;
				};
				open L,"$exonfile" or die "no file :$exonfile \n";
				<L>;
				while (<L>)
				{
					chomp;
					next if (/^$/);
#					next if ($_!~/6674126/);
					my @arr=split /\t/,$_;
					$for_rmdup{$arr[8]}{$arr[9]}{$arr[10]}=$arr[0];
					$com->{$arr[0]}{$arr[38]}=\@arr;
					$rmdepth->{$arr[0]}{"$$samname[$i]"}=$arr[11];
				};
				close L;
				############################################################
				open L,"$exonfile\.muttag" or die "no file :\t$exonfile\.muttag\n";
				while (<L>)
				{
					chomp;
					next if (/^$/);
					my @arr=split /\t/,$_;
					$translation->{$arr[7]}=$arr[0];
				};
				close L;
		}else
		{
				my $exonfile=$$snps[$i];
				my $exon10bp=$$snps[$i];
				$exonfile=~s/3.3_variation_annotation\/tot_3_level.report.txt|3.3_variation_annotation\/tot_5_level.report.txt/5.3_Batch_EXON_deletion\/exon_cnv_result.txt/g;
				$exon10bp=~s/3.3_variation_annotation\/tot_3_level.report.txt|3.3_variation_annotation\/tot_5_level.report.txt/5.3_Batch_EXON_deletion\/exon_cnv_result_10bp.txt/g;

				if (!-f $exonfile || !-f $exon10bp)
				{
					$wrong_tag=0;
					$wrong_file.="\t$exonfile\n\t$exon10bp\n";
					next;
				};

				my $line1=`cat $exonfile|wc -l`;chomp $line1;
				my $line2=`cat $exon10bp|wc -l`;chomp $line2;
				if ($line1 != $line2)
				{
				        print STDERR "\n\terror:\n\t$exonfile\n\t$exon10bp\n";
				        die;
				};

				open L,"$exonfile" or die "no file :$exonfile \n";
				open M,"$exon10bp" or die "no file :$exonfile \n";
				<L>;
				<M>;
				while (my $A=<L>,my $B=<M>)
				{
					chomp $A;
					next if ($A=~/^$/);
					my @arr=split /\t/,$A;
					my @arrB=split /\t/,$B;
					if (exists $for_rmdup{$arr[0]})
					{
						foreach my $start (sort {$a <=> $b} keys %{$for_rmdup{$arr[0]}})
						{
							last if ($start > $arr[2]);
							foreach my $end (sort {$a <=> $b} keys %{$for_rmdup{$arr[0]}{$start}})
							{
								if ($rmdepth->{$for_rmdup{$arr[0]}{$start}{$end}}{$$samname[0]}=~/ALL/)
								{
									next;
								};
					
								next if($end < $arr[1]);
								if ($arr[1] <= $end && $arr[2]>=$start)
								{
									###############################
									my $EXON;
									if ($arr[3]=~/.*?EXON\:(.*)/)
									{
											$EXON=$1;
									}elsif(exists $exon{"$arr[0]-$arr[1]-$arr[2]"} && $exon{"$arr[0]-$arr[1]-$arr[2]"}=~m/.*?EXON\:(.*)/)
									{
											$EXON=$1;
									}else
									{

next;
print "$A\n";
print Dumper \%exon;
die;
									};


									next if (!defined $EXON);
									CASE_A:
									$arr[-2]=1 if ($arr[-2]=~/NA/);
									$arrB[-2]=1 if ($arrB[-2]=~/NA/);
									
									if ($arr[-2] <0.2 || $arrB[-2]<0.2)
									{
										push @{$for_combine{$for_rmdup{$arr[0]}{$start}{$end}}{"$$samname[$i]"}},"$EXON|loss2";
										$for_detail{$for_rmdup{$arr[0]}{$start}{$end}}{$EXON}{num}+=1;
									}elsif($arr[-2] <0.75 || $arrB[-2]<0.75)
									{
										push @{$for_combine{$for_rmdup{$arr[0]}{$start}{$end}}{"$$samname[$i]"}},"$EXON|loss1";
										$for_detail{$for_rmdup{$arr[0]}{$start}{$end}}{$EXON}{num}+=1;
									}elsif($arr[-2] >1.7 || $arrB[-2]>1.7)
									{
										push @{$for_combine{$for_rmdup{$arr[0]}{$start}{$end}}{"$$samname[$i]"}},"$EXON|gain2";
										$for_detail{$for_rmdup{$arr[0]}{$start}{$end}}{$EXON}{num}+=1;
									}elsif($arr[-2] >1.25 || $arrB[-2]>1.25)
									{
										push @{$for_combine{$for_rmdup{$arr[0]}{$start}{$end}}{"$$samname[$i]"}},"$EXON|gain1";
										$for_detail{$for_rmdup{$arr[0]}{$start}{$end}}{$EXON}{num}+=1;
									}else
									{
										$for_detail{$for_rmdup{$arr[0]}{$start}{$end}}{$EXON}{num}+=0;
									};
									$for_detail{$for_rmdup{$arr[0]}{$start}{$end}}{$EXON}{rat}+=$arr[-2];
									$for_detail{$for_rmdup{$arr[0]}{$start}{$end}}{$EXON}{num}+=0;
									$for_detail{$for_rmdup{$arr[0]}{$start}{$end}}{$EXON}{reg}="$arr[0]:$arr[1]-$arr[2]";
								#	goto CASE_D;
								};
							};
						};
					};
					
					CASE_D:
				};
				close L;
		};
	};
	#########################################
	if ($wrong_tag==0)
	{
		print STDERR "error:\n$wrong_file\n";
		$return.="\nerror:$wrong_file\n";
		return $return;
	};
	foreach my $key (keys %for_detail)
	{
		my $best;
		my $num;
		my $rat;
		foreach my $exon (sort {$a <=> $b} keys %{$for_detail{$key}})
		{
			if (!defined $best)
			{
				$best=$for_detail{$key}{$exon}{reg}."(EXON:$exon)";
				$num=$for_detail{$key}{$exon}{num};
				$rat=$for_detail{$key}{$exon}{rat};
			}else
			{
				if($for_detail{$key}{$exon}{num}=~/NA/)
				{
					print "$key\n$exon\n$for_detail{$key}{$exon}{num}\n";
					die;
				}elsif ($for_detail{$key}{$exon}{num} > $num)
				{
					$best=$for_detail{$key}{$exon}{reg}."(EXON:$exon)";
					$num=$for_detail{$key}{$exon}{num};
					$rat=$for_detail{$key}{$exon}{rat};
				}elsif($for_detail{$key}{$exon}{num} == $num)
				{
					if (($key=~/loss/) && ($for_detail{$key}{$exon}{rat} < $rat))
					{
						$best=$for_detail{$key}{$exon}{reg}."(EXON:$exon)";
						$num=$for_detail{$key}{$exon}{num};
						$rat=$for_detail{$key}{$exon}{rat};
					}elsif(($key=~/gain/) && ($for_detail{$key}{$exon}{rat} > $rat))
					{
						$best=$for_detail{$key}{$exon}{reg}."(EXON:$exon)";
						$num=$for_detail{$key}{$exon}{num};
						$rat=$for_detail{$key}{$exon}{rat};
					};
				};
			};
		};
		$best="NA" if(!defined $best);
		$rmdepth->{$key}{yanzh}=$best;
		############################################
		next if (not exists $for_combine{$key});
		foreach my $name (keys %{$for_combine{$key}})
		{
			$rmdepth->{$key}{$name}=&get_abbr(@{$for_combine{$key}{$name}});
		};
		#####################################
	};
	return $return;
};

sub get_abbr
{
	my @tmp=@_;
	my %hash;
	my @number;
	foreach my $A (@tmp)
	{
		my @tmp_b=split /\|/,$A;
		++$hash{$tmp_b[-1]};
		push @number,$tmp_b[0];
	};
	my $last;
	@number=sort {$a <=> $b} @number;
	for (my $i=0;$i<@number ;$i+=1)
		{
		if ((exists $number[$i-1]) && (($number[$i]-$number[$i-1])==1))
		{
			$last.="-$number[$i]";
		}else
		{
			$last.=",$number[$i]";
		}
		};
	for (@number){$last=~s/-\d*-/-/g};
	$last=~s/^,//g;
	foreach my $type (sort {$hash{$b} <=> $hash{$a}} keys %hash)
	{
		$last="$type(EXON:$last)";
		last;
	};
	return $last;
};


sub revese_cons_whx
{
	my ($baosh,$dishot,$revise)=@_;
	if ($baosh=~/是/ && $dishot=~/是/)
	{
		$$revise.=",该变异所在外显子:保守性高、致病数据库报道热点区";
	}elsif($baosh=~/是/)
	{
		$$revise.=",该变异所在外显子:保守性高";
	}elsif($dishot=~/是/)
	{
		$$revise.=",该变异所在外显子:致病数据库报道热点区";
	};
};


sub get_mut_compile
{
	my ($g_pos,$c_pos,$gene_inf)=@_;
	my ($gene6,$genefx7)=(split /\|/,$gene_inf);

	my @tmp_chr=split /[:-]/,$g_pos;
	if ($tmp_chr[0]=~/NC/)
	{
		$tmp_chr[0]=&chr_convert($tmp_chr[0]);
	};
	if (!$tmp_chr[2])
	{
		$tmp_chr[2]=$tmp_chr[1];
	};
	my $mut="err";
	my @c=split /[:;]/,$c_pos;
	foreach my $pos (@c)
	{
		next if($pos !~/c\./);
		if ($pos=~/.*([ATCG])\>([ATCG]).*/)
		{
			my $bef=$1;my $aft=$2;
			if ($genefx7=~/-/)
			{
				$bef=~tr/ATCG/TAGC/;$bef=reverse $bef;
				$aft=~tr/ATCG/TAGC/;$aft=reverse $aft;
			};
			$mut="$bef\_$aft\_S";
		}elsif($pos=~/.*del([ATCG]+)ins([ATCG]+)$/)
		{
			my $bef=$1;my $aft=$2;
			if ($genefx7=~/-/)
			{
				$bef=~tr/ATCG/TAGC/;$bef=reverse $bef;
				$aft=~tr/ATCG/TAGC/;$aft=reverse $aft;
			};
			$mut="$bef\_$aft\_D";
		}elsif($pos=~/.*del([ATCG]+)$/)
		{
			my $aft=$1;
			if ($genefx7=~/-/)
			{
				$aft=~tr/ATCG/TAGC/;$aft=reverse $aft;
			};
			$mut="$aft\_\-\_D";
		}elsif($pos=~/.*ins([ATCG]+)$/)
		{
			my $aft=$1;
			if ($genefx7=~/-/)
			{
				$aft=~tr/ATCG/TAGC/;$aft=reverse $aft;
			};
			$mut="\-\_$aft\_D";
		}else
		{
			next;
		};
	};

	if ($mut=~/err/)
	{
#		print STDERR "$g_pos\t$c_pos\t$gene_inf\n";
#		die;
	};
	return (join "_",@tmp_chr,$mut);
};

sub get_dis_revise
{
	my ($relative,$tag)=@_;
	if ($$tag=~/CLINVAR/i)
	{
		$$relative=~s/有疾病相关报道/有疾病数据库Clinvar报道/;
	}else
	{
		my @database;
		if ($$tag=~/OMIM/i){push @database,"OMIM"};
		if ($$tag=~/HGMD/i){push @database,"HGMD"};
		if ($$tag=~/SWISS/i){push @database,"SWISS"};
		my $data=join ",",@database;
		$$relative=~s/有疾病相关报道/有数据库${data}报道/;
	};
};
sub get_sift
{
	my ($predict,$amino,$pre_MS,$con_MS)=@_;
	my @arr=split /\|/,$predict;
	my $delete=0;
	my $nature=0;
	my @soft;
####($provean,$polyphen_hdiv,$polyphen_hvar,$sift,$muttas,$mcup,$revel)=split /[\|\_]/,$arr[32];
	if ($arr[0]=~/D/)
	{
		$delete++;
		push @soft,"Provean";
	}elsif($arr[0] =~/\d+/)
	{
		$nature++;
	};
	if ($arr[1]=~/D/)
	{
		$delete++;
		push @soft,"Polyphen2";
	}elsif($arr[1] =~/\d+/)
	{
		$nature++;
	};
	if ($arr[2]=~/D/)
	{
		$delete++;
		push @soft,"Sift";
	}elsif($arr[2] =~/\d+/)
	{
		$nature++;
	};
	if ($arr[3]=~/^A|D/)
	{
		push @soft,"Mutationtaster";
		$delete++;
	}elsif($arr[3] =~/\d+/)
	{
		$nature++;
	};
	if ($arr[4]=~/D/)
	{
		push @soft,"M-CAP";
		$delete++;
	}elsif($arr[4] =~/\d+/)
	{
		$nature++;
	};
	if ($arr[5]=~/D/)
	{
		push @soft,"REVEL";
		$delete++;
	}elsif($arr[5] =~/\d+/)
	{
		$nature++;
	};
	###########################
	if ($delete>=2 || ($delete>=1 && $amino=~/移码/))
	{
		$$pre_MS="蛋白结构预测可能有害"."(".(join ",",@soft).")";	#######return "deleterious";
		$$con_MS="本变异为"."$amino".","."$$pre_MS";
	}elsif($nature>=2)
	{
		$$pre_MS="蛋白结构预测容忍或无害";		##############return "neutral";
		$$con_MS="本变异为"."$amino".","."$$pre_MS";
	}else
	{
		$$con_MS="本变异为"."$amino";
	};
};

sub get_genetic_conclusion
{
	my($HOMO,$AD,$uniq,$denovo,$fuhezahe)=@_;
	my $return="ERR";
	if ($denovo=~/YESHETE/)
	{
		if ($AD=~/AD/)
		{
			$return="P30";
		}elsif($AD=~/AR/)
		{
			$return="P31";
		}elsif($AD=~/XD|X-linked|XL/)
		{
			$return="P32";
		}elsif($AD=~/XR/)
		{
			$return="P33";
		};
	}elsif($denovo=~/YES/)
	{
			if($HOMO=~/homo|纯合|1/i)
			{
				if ($AD=~/AD/)
				{
					$return="P19";
				}elsif($AD=~/AR/)
				{
					$return="P20";
				}elsif($AD=~/XD|X-linked|XL/)
				{
					$return="P21";
				}elsif($AD=~/XR/)
				{
					$return="P22";
				};
			}elsif($HOMO=~/hete|杂合|2/i)
			{
				if ($AD=~/AD/)
				{
					$return="P26";
				}elsif($AD=~/AR/)
				{
					$return="P27";
				}elsif($AD=~/XD|X-linked|XL/)
				{
					$return="P28";
				}elsif($AD=~/XR/)
				{
					$return="P29";
				};
			}elsif($HOMO=~/hemi|半合子|5/i)
			{
				if ($AD=~/Y/)
				{
					$return="P23";
				}elsif($AD=~/XD|X-linked|XL/)
				{
					$return="P24";
				}elsif($AD=~/XR/)
				{
					$return="P25";
				};
			};
	}elsif($HOMO=~/homo|纯合|1/i)
	{
		if ($AD=~/AD/)
		{
			$return="P1";
		}elsif($AD=~/AR/)
		{
			$return="P2";
		}elsif($AD=~/XD|X-linked|XL/)
		{
			$return="P3";
		}elsif($AD=~/XR/)
		{
			$return="P4";
		};
	}elsif($HOMO=~/hete|杂合|2/i)
	{
		if ($AD=~/AD/)
		{
			$return="P8";
		}elsif($AD=~/AR/)
		{
			if ($uniq=~/YES/)
			{
				$return="P9";
			}elsif($fuhezahe=~/m\(/)
			{
				$return="P10";
			}else
			{
				$return="P11";
			};
		}elsif($AD=~/XD|X-linked|XL/)
		{
			$return="P12";
		}elsif($AD=~/XR/)
		{
			$return="P13";
		};
	}elsif($HOMO=~/hemi|半合子|5/i)
	{
		if ($AD=~/Y/)
		{
			$return="P5";
		}elsif($AD=~/XD|X-linked|XL/)
		{
			$return="P6";
		}elsif($AD=~/XR/)
		{
			$return="P7";
		};
	}elsif($HOMO=~/wild|野生型|4/i)
	{
		if ($AD=~/AD/)
		{
			$return="P14";
		}elsif($AD=~/AR/)
		{
			$return="P15";
		}elsif($AD=~/XD|X-linked|XL/)
		{
			$return="P16";
		}elsif($AD=~/XR/)
		{
			$return="P17";
		}elsif($AD=~/Y/)
		{
			$return="P18";
		};
	}elsif($HOMO=~/uncov|未覆盖|3/i)
	{
		$return="P34";
	};
	return $return;
};


sub get_SMN1	#########&standard_family::get_SMN1(\@sampname,\@rmdepthfile,$gene2OMIM,\%phenotype,\%num2type,\%SMN1_mut,\%SMN1_com);get_mut_compile
{
	my($samplename,$bam,$rmdupbam,$omiminf,$geneid,$path,$smn_com,$open,$DETAIL)=@_;
	my $name=(split /\D+/,$$samplename[0])[0];
	my ($mut,$conclusion,$dep,$detail,$genetic_score,$tot_score,$gene,$genestrand,$chr,$start,$end)=("NA","NA","NA","NA","NA","NA","SMN1","+","chr5","70247773","70247773");
	my ($cpos,$relative,$shuom,$AD,$geneID,$geneloc,$NM,$struct)=("c.840C>T(exon7)","未知","NA","AR","NA","NA","NM_000344","位于基因组多拷贝区域+DNA结构正常");
	my ($tmpcom,@last,$level);
	my $smndoor=1;
	my $RAT;
	for (my $i=0;$i<@{$samplename} ;$i++)
	{
		my $tmpres;
		my $smn1="chr5:70247773-70247773";
		my $smn2="chr5:69372353-69372353";
		my %hash;
		if (-f "$$rmdupbam[$i]")
		{
			&get_point_depth($$rmdupbam[$i],$smn1,\%hash);
			&get_point_depth($$rmdupbam[$i],$smn2,\%hash);
		}elsif(-f "$$bam[$i]")
		{
			&get_point_depth($$bam[$i],$smn1,\%hash);
			&get_point_depth($$bam[$i],$smn2,\%hash);
		}else
		{
			$smndoor=0;
			print "\n\t$$rmdupbam[$i]\tError:no_depth_file\n";
			next;
		};

		my $SMN1=$hash{$smn1}{C}+$hash{$smn2}{C}+$hash{$smn1}{G}+$hash{$smn2}{G};
		my $SMN2=$hash{$smn1}{T}+$hash{$smn2}{T}+$hash{$smn1}{A}+$hash{$smn2}{A};
		my $tot=$SMN1+$SMN2;

		my ($res,$depend,$ratio)=("NA","NA","NA");
		if($tot==0)
		{
			$res="纯合";
			$depend="相对可靠";
			$tmpres='del2';
		}elsif($SMN1/$tot<0.1)
		{
			$res="纯合";
			$depend="相对可靠";
			$tmpres='del2';
			$ratio=$SMN1/$tot;$ratio=sprintf("%.2f",$ratio);
		}elsif($SMN1/$tot<=0.3)
		{
			$res="杂合";
			$depend="相对可靠";
			$tmpres='del1';
			$ratio=$SMN1/$tot;$ratio=sprintf("%.2f",$ratio);
		}elsif($i>0 && $last[3]=~/纯合|杂合/ && $SMN1/$tot<=0.4)
		{
			$res="杂合";
			$depend="相对可靠";
			$tmpres='del1';
			$ratio=$SMN1/$tot;$ratio=sprintf("%.2f",$ratio);
		}else
		{
			$res="野生型";
			$tmpres='wild';
			$ratio=$SMN1/$tot;$ratio=sprintf("%.2f",$ratio);
		};
		
		push @last,$ratio,$SMN1,$tot,$res,$depend;
		if ($i==0)
		{
			$RAT="C:T=$SMN1:$SMN2";
			#$shuom="C:T=$SMN1:$SMN2";
			if ($tmpres eq 'del2')
			{
				$conclusion='支持致病';
				$dep='先证者SMN1纯合缺失,符合AR遗传疾病发病机制';
				$detail='家系共分离';
				$genetic_score=1;
				$tot_score=1*1;
				$level=1;
				$relative="较高";
				$shuom="SMN1纯合缺失";
				$mut="chr5_70247773_70247773_D_loss2_C";
			}elsif($tmpres eq 'del1')
			{
				$conclusion='可能致病';
				$dep='先证者SMN1杂合缺失,不符合AR遗传疾病发病机制';
				$detail='SMN1杂合缺失';
				$genetic_score=4;
				$tot_score=1*4;
				$level=1;
				$relative="可能有害";
				$shuom="SMN1杂合缺失";
                                $mut="chr5_70247773_70247773_D_loss1_C";
			}else
			{
				$conclusion='排除致病';
				$dep='先证者SMN1正常,不符合AR遗传疾病发病机制';
				$detail='家系不共分离';
				$genetic_score=30;
				$tot_score=30*6;
				$level=3;
				$relative="不确定";
				$shuom="SMN1正常";
                                $mut="chr5_70247773_70247773_D_norm0_C";
			};
			if ($tot<40)
			{
			#	$shuom.='(C+T总深度<40)';
			};
		};
	};
	if ($smndoor==0)
	{
		print STDERR "\n\t\t\tError:no smn detected !\n";
		return;
	};
	my @na;for (my $i=0;$i<20;$i++){push @na,"NA"};
	####################################
	if (exists $omiminf->{gene}{$gene})
	{
		my @tmp=@{$omiminf->{gene}{$gene}};
		foreach my $AA (@tmp)
		{
			my @farm;
			my ($o_gene,$o_geneomim,$o_disomim,$o_inherit,$o_phe)=split /\|/,$AA;
			if ($open==0)
			{
				push @farm,$mut,@last,$genetic_score,$conclusion,$dep,$tot_score,$gene,$genestrand,$chr,$start,$end,$cpos,"NA","NA",$level;
				&add_blank(\@farm,10);
				push @farm,"17884807";
				&add_blank(\@farm,9);
				push @farm,$relative,$shuom,$o_phe,$o_disomim,$o_inherit,$geneid->{$gene}{id},$geneid->{$gene}{pos},$NM,$struct;
				&add_blank(\@farm,20);
				push @farm,"NA","NA","NA","C>T",$RAT."(EXON:7)";
			}elsif($open==1)
			{
				push @farm,$mut,$last[2],$last[1],$last[0],$last[3],$last[4],$level,$genetic_score,$conclusion,$dep,$tot_score,"$$samplename[0]",$gene,$genestrand,$chr,$start,$end,$cpos;
				&add_blank(\@farm,10);
				push @farm,"17884807";
				&add_blank(\@farm,9);
				push @farm,"NA","NA",$relative,$shuom,$o_phe,$o_disomim,$o_inherit,$geneid->{$gene}{id},$geneid->{$gene}{pos},"NA","NA","NA","NA","NA","NA","NA",$NM,$struct;
				&add_blank(\@farm,20);
				push @farm,"C>T";	#$RAT."(EXON:7)";
			};
			push @{$smn_com->{$$samplename[0]}},\@farm;
		};
	}else
	{
		print STDERR "\tError:\tplease check the file named omim.txt in the analysised directory !\n";
		die;
	};
};
################
sub add_blank
{
        my($old,$num)=@_;
        for(my $i=0;$i<$num;$i++)
        {
                push @{$old},"NA"
        };
};
##########################################
sub get_point_depth
{
	my($bam,$pos,$hash)=@_;
	my $bai=$bam;$bai=~s/bam$/bai/;
	if (!-f $bam || (!-f "$bam.bai" && !-f $bai))
	{
		print STDERR "\n\t no index :$bam\n\n";
		die;
	};

	my @ARR=split /\n/,`/share/ofs1a/EXdev/WES_pipe_v1/bin/samtools view $bam $pos|cut -f 4,6,10 `;

	my ($chr,$start,$end)=split /[:-]/,$pos;
	foreach ("A","T","C","G")
	{
		if (not exists $hash->{$pos}{$_})
		{
			$hash->{$pos}{$_}=0;
		};
	};
	foreach my $read (@ARR)
	{
		my @arr=split /\t/,$read;
		next if($arr[1]=~/\*/);
		my @base=split //,$arr[2];
		#############
		my @num=$arr[1]=~m/\d+/g;
		my @tag=$arr[1]=~m/\D+/g;
		my @true_base;
		my $now=0;
		for (my $i=0;$i<@num ;$i++)
		{
			if ($tag[$i]=~/M/)
			{
				push @true_base,@base[$now..$num[$i]-1];
				$now+=$num[$i];
			}elsif ($tag[$i]=~/D/)
			{
				for (my $j=0;$j<$num[$i] ;$j++)
				{
					push @true_base,"S";
				};
			}elsif ($tag[$i]=~/I/)
			{
				$now+=$num[$i];
			}elsif ($tag[$i]=~/S/)
			{
				$now+=$num[$i];
			}else
			{
				print "$read \n";
				die;
			};
		}
		next if (not exists $true_base[$start-$arr[0]]);
		++$hash->{$pos}{$true_base[$start-$arr[0]]};
	};
};
#########################################################################################
sub get_chrcnv	###############&standard_family::get_chrcnv(\@indir,\@sampname,\%chrcnv);
{
	my($dir,$ids,$hash,$chrlenfile,$chrlen)=@_;
	for (my $i=0;$i<@{$dir} ;$i++)
	{
		open L,"$$dir[$i]/5.2_EXON_deletion/chr_UPD.txt" or next;
		while (<L>)
		{
			chomp;
			next if (/^$/);
			my @arr=split /\t/,$_;
			if ($arr[3] && $arr[4])
			{
				$hash->{$arr[0]}{$$ids[$i]}{tag}=$arr[4];
				$hash->{$arr[0]}{$$ids[$i]}{value}=$arr[3];
			};
		};
		close L;
	};
	open L,"$chrlenfile" or next;
	while (<L>)
	{
		chomp;
		next if(/^$/ || $_!~/^NC/);
		my @arr=split /\t/,$_;
		$arr[0]=&chr_convert($arr[0]);
		$chrlen->{$arr[0]}="$arr[2]";
	};
	close L;
};
####################################################


##############################################################
sub get_del_tag
{
	my ($del,$tag)=@_;
	if ($del=~/gain2/)
	{
		$tag="双倍重复"
	}elsif($del=~/gain1/)
	{
		$tag="单倍重复"
	}elsif($del=~/gain/)
	{
		$tag="重复"
	}elsif($del=~/loss2/)
	{
		$tag="纯合缺失"
	}elsif($del=~/loss1/)
	{
		$tag="杂合缺失"
	}elsif($del=~/loss/)
	{
		$tag="缺失"
	}elsif($del=~/UPD/)
	{
		$tag="单亲二倍体"
	}else
	{
		$tag="正常"
	};
	return $tag;
};
#########################################################################################
sub call_depth			##&standard_family::call_depth($len,$out,\@infile,\@bam,\@rbam,\%depth,\%rmdepth);
{
	my ($toolsbed,$call,$len,$out,$snps,$bam,$rmdupbam,$depth,$rmdepth)=@_;
	my $return="";
	open Z,">$out\.call_depth.bed" or die $!;
	for (my $i=0;$i<@{$snps} ;$i++)
	{
		my $file=$$snps[$i];
		$file=~s/tot_3_level.report.txt/tot_5_level.report.txt/;
		open L,"$file" or die $!;
		<L>;
		while (<L>)
		{
			chomp;
			next if (/^$/);
			my @arr=split /\t/,$_;
			my @tmp_chr=split /[:]/,$arr[4];
			if ($tmp_chr[0]=~/NC/)
			{
				$tmp_chr[0]=&chr_convert($tmp_chr[0]);
			};
			$arr[4]=join ":",@tmp_chr;

			my $bianhao1=&get_mut_compile($arr[4],$arr[6],$arr[1]);
			if ($bianhao1=~/err/)
			{
				print STDERR "error: get err mut_tag:$_\n";
				$return.="error: get err mut_tag:$_\n";
			};
			if ((exists $rmdepth->{$bianhao1}) && ((keys %{$rmdepth->{$bianhao1}})==@{$snps}))
			{
				next;
			};

			my ($chr,$start,$end)=split /[:-]/,$arr[4];#			$chr=$chrconvert1{$chr};
			$end=$start if (!$end);
			$start-=$len;
			$end+=$len;
			print Z "$chr\t$start\t$end\n";
		};
		close L;
	};
	close Z;
	`$toolsbed sort -i $out\.call_depth.bed >$out\.call_depth.bed.sorted `;
	`$toolsbed merge -i $out\.call_depth.bed.sorted >$out\.call_depth.bed.sorted.merge `;
	`rm $out\.call_depth.bed.sorted && mv $out\.call_depth.bed.sorted.merge $out\.call_depth.bed`;
	for(my $i=0;$i<@{$rmdupbam};$i++)
	{
		if(!-f $$rmdupbam[$i])
		{
			$$rmdupbam[$i]=$$rmdupbam[$i]."_reset.bam";
		};
	};

	my $bam_info=join " -I ",@{$bam};
	my $rmbam_info=join " -I ",@{$rmdupbam};
	my $gatk="/mnt/rhd1/EXdev/bin/GenomeAnalysisTK.jar";
	my $hg19="/mnt/rhd1/EXdev/db/J_hg19_reference/hg19_reference_with_NC.fasta";
	my $dbsnp="/mnt/rhd1/EXdev/db/A_maf_database/dbSNP_rs_in_exon.database";
	my $dir=dirname($out);
	my $time=time();
	my $shname=basename($out);
	$shname="$dir/fam.$shname\.sh";
	open H,">$shname" || die $!;
##	print H "java -jar $gatk -R $hg19 -T HaplotypeCaller -I $bam_info -D $dbsnp -o $out\_$len.vcf -L $out\.call_depth.bed \n";
	print H "java -jar $gatk -R $hg19 -T HaplotypeCaller -I $rmbam_info -D $dbsnp -o $out\_$len.rmdup.vcf -L $out\.call_depth.bed \n";
	close H;

	my $queue;
	my %QUEUE;
	foreach my $infile(@{$rmdupbam})
	{
		if ($infile=~/share\/(ofs.*?)\//)
		{
	 	     	my $dir_name=$1;
        		if($dir_name=~/ofs1b|ofs3a/)
		        {
				$QUEUE{ofs1b}=1;
				$queue="sge01";
		        }elsif($dir_name=~/ofs2a|ofs3b/)
		        {
				$QUEUE{ofs2a}=1;
				$queue="sge02";
		        }elsif($dir_name=~/ofs2b|ofs3c/)
		        {
				$QUEUE{ofs2b}=1;
				$queue="sge03";
		        }else
			{
				print STDERR "\n\terror:unknown queue\n\t$bam\n";
				die;
			};
		};
	};
	################
	if(-f "$out\_$len.rmdup.vcf")
	{
		my $line=`cat $out\_$len.rmdup.vcf |wc -l`;
		chomp $line;
		if($line>100)
		{
			$call=0
		};
	};
	##########################
	
	my $qsub="/share/ofs1a/EXdev/WES_pipe_v1_1.1/bin/qsub_for_master_2017-06-14.pl";
	if((keys %QUEUE)>1)
	{
		if ($call==1)
		{
			`ssh node-0-11 \'sh $shname >$shname.err \'`;
		};
	}else
	{
		if (`hostname`=~/master/)
		{
			if ($call==1)
			{
				`perl $qsub --queue $queue --independent yes $shname `;
			};
		}else
		{
			if ($call==1)
			{
				print "ssh master perl $qsub --queue $queue --independent yes $shname \n";
				`ssh master \'perl $qsub --queue $queue --independent yes $shname \' `;
			};
		};
	};
##	&get_famvcf_depth("$out\_$len.vcf",$depth);
	&get_vcf_depth("$out\_$len.rmdup.vcf","$out\_$len.rmdup.vcf.table",$rmdepth);
	return $return;
};

sub get_vcf_depth		########&get_depth($out\_$len.vcf,$depth);
{
	my ($file,$out,$hash)=@_;
	open L,"$file" or die;
	open OUT,">$out" or die;
	my @names;
	while (<L>)
	{
		chomp;
		next if(/^$/);
		if (/^\#/)
		{
			next if($_!~/^\#CHROM\s+/);
			my ($chrori,$posori,$rs,$refori,$altori,$un1,$un2,$un3,$un4,@tmp)=(split/\s+/,$_);
			my $last=join "\t","chr","start","end","ref","alt","mut_tag","rs","MQ",@tmp;
			print OUT "$last\n";
			@names=@tmp;
			next;
		};

		my ($chrori,$posori,$rs,$refori,$altori,$un1,$un2,$un3,$un4,@depth)=(split/\s+/,$_);
		my @ALTS=split /\,/,$altori;

		for (my $k=0;$k<@ALTS ;$k++)
		{
			my $start=$posori;
			my $end=$start;
			my $ref=$refori;
			my $mut=$ALTS[$k];

			if($ref=~/^[ATCG]$/ && $mut=~/^[ATCG]$/)
			{
			}elsif($ref=~/-|I/)
			{
				$ref="I";
				$end=$start+1;
			}elsif($ref=~/D|DI/)
			{
				$end=$start+length($mut)-1;
			}elsif($mut=~/-/)
			{
				$mut=$ref;
				$ref="D";
				$end=$start+length($mut)-1;
			}else
			{
					my @REF=split //,$ref;
					my @ALT=split //,$mut;
					while (1)
					{
							if (@REF<1 || @ALT<1)
							{
									 last;
							}elsif ($REF[0] eq $ALT[0])
							{
									$start+=1;
									shift @REF;
									shift @ALT;
							}else
							{
									last;
							};
					};
					while (1)
					{
							if (@REF<1 || @ALT<1)
							{
									 last;
							}elsif($REF[-1] eq $ALT[-1])
							{
									pop @REF;
									pop @ALT;
							}else
							{
									last;
							};
					};

					if(@REF==1 && @ALT==1)
					{
							$end=$start;
							$ref=$REF[0];
							$mut=$ALT[0];
					}elsif(@REF<1 && @ALT>=1)
					{
							$ref="I";
							$mut=join "",@ALT;
							$start-=1;
							$end=$start+1;
					}elsif(@REF>=1 && @ALT<1)
					{
							$ref="D";
							$mut=join "",@REF;
							$end=$start+length($mut)-1;
					}else
					{
							$ref="DI";
							$mut=(join "",@REF)."-".(join "",@ALT);
							$end=$start+@REF-1;
					};
			};
			########################################

			my $muttag="$chrori\_$start\_$end\_$ref\_$mut";
			if ($rs!~/rs/)
			{
				$rs="NA";
			};
			my $MQ="NA";
			if ($un3=~/MQ=(.*?);/)
			{
				$MQ=$1;
			};

			my $key;
			if ($ref=~/^[ATCG]$/ && $mut=~/^[ATCG]$/)
			{
				$key="$chrori\_$start\_$end\_$ref\_$mut\_S";
			}elsif($ref=~/I/)
			{
				$key="$chrori\_$start\_$end\_\-\_$mut\_D";
			}elsif($ref=~/D/)
			{
				$key="$chrori\_$start\_$end\_$mut\_\-\_D";
			}else
			{
				die;
			};

			print OUT "$chrori\t$start\t$end\t$ref\t$mut\t$muttag\t$rs\t$MQ";
			foreach my $i (0..@depth-1)
			{
				my($mutdep,$alldep,$ratio)=("NA","NA","NA");
				if ($depth[$i]=~/\:/)
				{
					my @INFO=split /\:/,$depth[$i];
					my @DEPTH=split /\,/,$INFO[1];
					my $number=@ALTS+1;
					if (@DEPTH==$number && $INFO[2]=~/\d+/)
					{
						$alldep=$INFO[2];
						$mutdep=$DEPTH[$k+1];
						if ($alldep==0)
						{
							$ratio=0;
						}else
						{
							$ratio=$mutdep/$alldep;
							die if($ratio>1);
						};
						$ratio=sprintf("%.4f",$ratio);
					};
				};
				print OUT "\t".$mutdep."/".$alldep."=".$ratio;

				my $dep=$ratio."=".$mutdep."/".$alldep;
				if(exists $hash->{$key}{$names[$i]} && $hash->{$key}{$names[$i]}=~/\d+/)
				{
				}else
				{
					$hash->{$key}{$names[$i]}=$dep;
				};
			};
			print OUT "\n";
		};
	};
	close L;
	close OUT;
};

sub get_famvcf_depth		########&get_depth($out\_$len.vcf,$depth);
{
	my ($file,$hash)=@_;
	open L,"$file" or die "can_not_open_file:$file\n";
	my @tmp_name;
	my %QC;
	while (<L>)
	{
		chomp;
		next if(/^$/);
		if (/^\#/)
		{
			next if($_!~/^\#CHROM\s+/);
			my ($chrori,$posori,$rs,$refori,$altori,$un1,$un2,$un3,$un4,@tmp)=(split/\s+/,$_);
##			for (my $i=0;$i<@tmp;$i++)
##			{
##				$tmp[$i]=(split /\D+/,$tmp[$i])[0];
##			};
			@tmp_name=@tmp;
			next;
		};
		my @arr=split /\t/,$_;
		my @ALTS=split /\,/,$arr[4];
		my ($chrori,$posori,$rs,$refori,$altori,$un1,$un2,$un3,$un4,@depth)=(split/\s+/,$_);
		if ($chrori=~/^NC/){$chrori=$chrconvert1{$chrori}};
##print Dumper \@depth;
		$QC{$chrori}=1;
		foreach my $i (0..@depth-1)
		{
			my $name=$tmp_name[$i];
			my @depth=split /\:/,$depth[$i];
			my ($mutdepth,$totdepth);
			if ($depth[1]){$mutdepth=$depth[1]}
			else{$mutdepth='NA'};
			if ($depth[2]){$totdepth=$depth[2]}
			else{$totdepth='NA'};
			my @mutdepth=split /\,/,$mutdepth;
			foreach my $j (0..@ALTS-1)
			{
				my ($chr,$pos,$ref,$alt)=($chrori,$posori,$refori,$ALTS[$j]);
				my ($start,$end)=($pos,$pos);
				my ($Mdepth,$Tdepth,$R);
				if ($totdepth=~/^\d+$/ && ($totdepth ne '0'))
				{
					$Tdepth=$totdepth;
					if ($mutdepth[$j+1] && $mutdepth[$j+1]=~/^\d+$/)
					{
						$Mdepth=$mutdepth[$j+1];
					}else
					{
						$Mdepth='0';
					};
					$R=$Mdepth/$Tdepth;
					$R=sprintf ("%.4f",$R);
				}else
				{
					$R=$Mdepth=$Tdepth='0';
				};
				my $d="$R\=$Mdepth\/$Tdepth";
				my $key;
				if ($ref=~/^[ATCG]$/ && $alt=~/^[ATCG]$/)
				{
					$key="$chr\_$start\_$start\_$ref\_$alt\_S";
					next if (exists $hash->{$key}{$name});###########如果已存在，说明先证者报告中已有，不做覆盖
					$hash->{$key}{$name}=$d;
				}elsif(length$ref==1 && length$alt>1)
				{
					$end=$start+1;
					$ref='-';
					$alt=~s/^[ATCG]//;
					$key="$chr\_$start\_$end\_\-\_$alt\_D";
					next if (exists $hash->{$key}{$name});###########如果已存在，说明先证者报告中已有，不做覆盖
					$hash->{$key}{$name}=$d;
				}elsif(length$alt==1 && length$ref>1)
				{
					$start+=1;
					$ref=~s/^[ATCG]//;
					$alt="-";
					$end+=length$ref;
					$key="$chr\_$start\_$end\_$ref\_\-\_D";
					next if (exists $hash->{$key}{$name});	###########如果已存在，说明先证者报告中已有，不做覆盖
					$hash->{$key}{$name}=$d;
				}else
				{
					#####################################################  值得注意的是 annovar 格式转换也有不给转换的情况，故原位置也保存，
					my $end0=$start+(length$ref)-1;
					$key="$chr\_$start\_$end0\_$ref\_$alt\_D";
					if (not exists $hash->{$key}{$name}){$hash->{$key}{$name}=$d};	###########如果已存在，说明先证者报告中已有，不做覆盖
					
					my @ref=split //,$ref;
					my @alt=split //,$alt;
					my ($start1,$start2,$end1,$end2)=($start,$start,$end,$end);
					my ($ref1,$ref2,$alt1,$alt2)=($ref,$ref,$alt,$alt);
					for (my $i=0;$i<@ref && $i<@alt;$i++)	#############正向比较
					{
						if ($ref[$i] eq $alt[$i])
						{
							$ref1=~s/^[ATCG]//;
							$alt1=~s/^[ATCG]//;
							next;
						}else
						{
							$ref1='-'if($ref1=~/^$/);
							$alt1='-'if($alt1=~/^$/);
							if ($alt1 eq '-')			#############del
							{
								$start1+=$i;
								$end1=$start1+(length$ref1)-1;
								$key="$chr\_$start1\_$end1\_$ref1\_\-\_D";
							}elsif($ref1 eq '-')		##############ins
							{
								$start1+=$i-1;
								$end1=$start1+1;
								$key="$chr\_$start1\_$end1\_\-\_$alt1\_D";
							}elsif($ref1=~/^[ATCG]$/ && $alt1=~/^[ATCG]$/)###########SNP
							{
								$start1+=$i;
								$key="$chr\_$start1\_$start1\_$ref\_$alt\_S";
							}else						##############delins
							{
								$start1+=$i;
								$end1=$start1+(length$ref1)-1;
								$key="$chr\_$start1\_$end1\_$ref1\_$alt1\_D";
							};
							next if (exists $hash->{$key}{$name});###########如果已存在，说明先证者报告中已有，不做覆盖
							$hash->{$key}{$name}=$d;
							last;
						};
					};
					#####################################################
					for (my $i=1;$i<=@ref && $i<=@alt;$i++)	#############反向比较
					{
						if ($ref[-$i] eq $alt[-$i])
						{
							$ref2=~s/[ATCG]$//;
							$alt2=~s/[ATCG]$//;
						}else
						{
							$ref2='-'if($ref2=~/^$/);
							$alt2='-'if($alt2=~/^$/);
							if ($alt2 eq '-')			#############del
							{
								$end2=$start2+(length$ref2)-1;
								$key="$chr\_$start2\_$end2\_$ref2\_\-\_D";
							}elsif($ref2 eq '-')		##############ins
							{
								$start2-=1;
								$key="$chr\_$start2\_$end2\_\-\_$alt2\_D";
							}elsif($ref2=~/^[ATCG]$/ && $alt2=~/^[ATCG]$/)###########SNP
							{
								$key="$chr\_$start2\_$start2\_$ref2\_$alt2\_D";
							}else						##############delins
							{
								$end2=$start2+(length$ref2)-1;
								$key="$chr\_$start2\_$end2\_$ref2\_$alt2\_D";
							};
							next if (exists $hash->{$key}{$name});###########如果已存在，说明先证者报告中已有，不做覆盖
							$hash->{$key}{$name}=$d;
							last;
						};
					};
				};
			};
		};
	};
	if ((keys %QC) <23)
	{
		print STDERR "\n\t rm_dup_vcf  error !!! \n\n";
		die;
	};
};

sub get_revise_genetic
{
	my ($chr,$genetic)=@_;
	if ($chr=~/chrX|NC_000023/)
	{
		if($$genetic=~/chr_AD/)
		{
			$$genetic="chr_XD";
		}else
		{
			$$genetic=~s/AD|AR|Y|Y-linked|NA|DR//g;
		};
	}elsif($chr=~/chrY|NC_000024/)
	{
		if($$genetic=~/chr_AD/)
		{
			$$genetic="chr_Y";
		}else
		{
			$$genetic='Y';
		};
	}else
	{
		$$genetic=~s/XD|XR|Y|X-linked|XL|Y-linked|NA|DR//g;
	};
	$$genetic=~s/^,|,$|\s+//g;
	if ($$genetic!~/AD|AR|XD|XR|Y|X-linked|XL/)
	{
		$$genetic="NA";
	};
};

sub get_model		#################从excel获得家系判断依据		&standard_family::get_model($model,$sheet,\%family);
{
	my ($file,$sheet,$hash)=@_;
	my $parser = Spreadsheet::ParseExcel->new();
	my $workbook=$parser->parse($file);
	my $Msheet=$workbook->worksheet($sheet);
	my ($row_min,$row_max )=$Msheet->row_range();
	my ($col_min,$col_max )=$Msheet->col_range();
	for (my $i=$row_min+1;$i<=$row_max ;$i++)
	{
			my $way = $Msheet->get_cell($i,0);
			next if( !$way );
			$way=$way->value();
			my @cols;
			for (my $j=1;$j<15;$j++)
			{
				my $tmp=$Msheet->get_cell($i,$j);
				next if (!$tmp);
				$tmp=$tmp->value();
				Encode::_utf8_on($tmp);
				push @cols,$tmp;
			};
			if ($cols[3] && $cols[4] && $cols[5])
			{
				$hash->{"$way"}{"$cols[0]:M$cols[1]:FM$cols[2]"}{"FM1:M0:FM0"}="$cols[3]\t$cols[4]\t$cols[5]";
				$hash->{"$way"}{"$cols[0]:M$cols[1]:FM$cols[2]"}{"M1:M0:FM0"}="$cols[3]\t$cols[4]\t$cols[5]";
			};
			if ($cols[6] && $cols[7] && $cols[8])
			{
				$hash->{"$way"}{"$cols[0]:M$cols[1]:FM$cols[2]"}{"FM1:M1:FM0"}="$cols[6]\t$cols[7]\t$cols[8]";
				$hash->{"$way"}{"$cols[0]:M$cols[1]:FM$cols[2]"}{"M1:M1:FM0"}="$cols[6]\t$cols[7]\t$cols[8]";
			}
			if ($cols[9] && $cols[10] && $cols[11])
			{
				$hash->{"$way"}{"$cols[0]:M$cols[1]:FM$cols[2]"}{"FM1:M0:FM1"}="$cols[9]\t$cols[10]\t$cols[11]";
				$hash->{"$way"}{"$cols[0]:M$cols[1]:FM$cols[2]"}{"M1:M0:FM1"}="$cols[9]\t$cols[10]\t$cols[11]";
			}
			if ($cols[12] && $cols[13] && $cols[14])
			{
				$hash->{"$way"}{"$cols[0]:M$cols[1]:FM$cols[2]"}{"FM1:M1:FM1"}="$cols[12]\t$cols[13]\t$cols[14]";
				$hash->{"$way"}{"$cols[0]:M$cols[1]:FM$cols[2]"}{"M1:M1:FM1"}="$cols[12]\t$cols[13]\t$cols[14]";
			};
	};
};

##########################################################################
sub get_comp_hete		####&standard_family::get_comp_hete(\@famsample,\%com,\%rmdepth,\%relation,\%tmp_hete,\%tmp_fuhezahe);
{
	my ($names,$com,$rmdepth,$farm,$hash,$fuhezahe,%keys,%forcal1,%forcal2,%genemut)=@_;
	my $father=$farm->{$$names[1]}{'path'};
	my $mother=$farm->{$$names[2]}{'path'};

	if (($father eq '4') || ($mother eq '4'))	##########父母患病非复合杂合模型
	{
		print "\tunnormal parants whitout compound heterozygous !\n";
	};
		
		foreach my $muttag (sort keys %{$com})
		{
			foreach my $omimid (sort keys %{$com->{$muttag}})
			{
				foreach my $number (@{$names})
				{
					if (not exists $rmdepth->{$muttag}{$number})
					{
						$rmdepth->{$muttag}{$number}="NA";
					};
					my ($ratio,$mutdep,$totdep)=split /[=\/]/,$rmdepth->{$muttag}{$number};
					my $homo;
					my $key=$muttag;
					my $key2="$key;$omimid";
					my $yichuan=${$com->{$muttag}{$omimid}}[34];
					my $gene=${$com->{$muttag}{$omimid}}[3];
					my $LEVEL=${$com->{$muttag}{$omimid}}[9];

					if ($muttag=~/gain|loss/)
					{
						if($number eq $$names[0])
						{
							if (exists $rmdepth->{$muttag}{$number} && $rmdepth->{$muttag}{$number}=~/gain1|gain2|loss1/)
							{
								$homo="Hete";
							}elsif(exists $rmdepth->{$muttag}{$number} && $rmdepth->{$muttag}{$number}=~/loss2/)
							{
								$homo="Homo";
							}elsif(exists $rmdepth->{$muttag}{$number} && $rmdepth->{$muttag}{$number}=~/gain|loss/)
							{
								$homo="Hemi";
							}else
							{
								$homo="Wild";
							};
						}else
						{
							if ($rmdepth->{$muttag}{$$names[0]}=~/loss/)
							{
								if (exists $rmdepth->{$muttag}{$number} && $rmdepth->{$muttag}{$number}=~/loss1/)
								{
									$homo="Hete";
								}elsif(exists $rmdepth->{$muttag}{$number} && $rmdepth->{$muttag}{$number}=~/loss2/)
								{
									$homo="Homo";
								}elsif(exists $rmdepth->{$muttag}{$number} && $rmdepth->{$muttag}{$number}=~/loss/)
								{
									$homo="Hemi";
								}else
								{
									$homo="Wild";
								};
							}elsif($rmdepth->{$muttag}{$$names[0]}=~/gain/)
							{
								if (exists $rmdepth->{$muttag}{$number} && $rmdepth->{$muttag}{$number}=~/gain1|gain2/)
								{
									$homo="Hete";
								}elsif(exists $rmdepth->{$muttag}{$number} && $rmdepth->{$muttag}{$number}=~/gain/)
								{
									$homo="Hemi";
								}else
								{
									$homo="Wild";
								};
							}else
							{
								print STDERR "\tproband exon deletion error ! \n\n";
								print STDERR "$muttag\t$$names[0]\t$rmdepth->{$muttag}{$$names[0]}\n";
								print Dumper \%{$rmdepth->{$muttag}};
								die;
							};
						};
						################
						$yichuan=${$com->{$muttag}{$omimid}}[39];
						$gene=${$com->{$muttag}{$omimid}}[6];
						$LEVEL=${$com->{$muttag}{$omimid}}[14];
#next if($gene ne 'VPS13C');
#print STDERR "@{$com->{$muttag}{$omimid}}[0]\t$number\t$gene\t$rmdepth->{$muttag}{$number}\t$homo\n";
##						print "$yichuan\n$gene\n$LEVEL\n";						die;
					}elsif (($totdep eq 0) || ($totdep eq "NA"))
					{
						$homo="uncov";
					}elsif ($mutdep < 2 || $ratio < 0.1)
					{
						$homo="Wild";
					}elsif($mutdep >= 2 && $ratio >= 0.85)
					{
						$homo="Homo";
					}elsif($mutdep >= 2 && $ratio >= 0.1 && $ratio < 0.85)
					{
						$homo="Hete";
					}else
					{
						print "\t\tHomo err !\n$rmdepth->{$muttag}{$number}\n";
						die;
					};

					if ($yichuan=~/AR/i || $yichuan eq 'NA')
					{
						next if ($LEVEL >3);	###########4_5 级突变不做复合杂合分析	20161104
						$forcal1{$key2}{$number}=$homo;
						$forcal2{$key2}{$number}=$LEVEL;##################生物学分级
						if ($homo=~/Hete/i)
						{
							$genemut{$number}{$gene}{$key}=1;
							$keys{$number}{$gene}{$key2}=1;
						};
					};
				};
			};
		};
		########################################
###print Dumper \%forcal1;
###print Dumper \%keys;die;

			my %close;
			foreach my $gene (keys %{$keys{$$names[0]}})
			{
				my $num=keys %{$genemut{$$names[0]}{$gene}};
				if ($num<2)
				{
					foreach my $key (keys %{$keys{$$names[0]}{$gene}})
					{
						my ($tmp1,$tmp2)=split /\;/,$key;
						$hash->{$tmp1}{$tmp2}='e_2,n_1';
					};
				}else
				{
					next if (($father eq '4') || ($mother eq '4'));	##########父母患病非复合杂合模型

					foreach my $key (sort keys %{$keys{$$names[0]}{$gene}})
					{
						foreach my $key22 (sort keys %{$keys{$$names[0]}{$gene}})
						{
							next if ($key eq $key22);
							if (($forcal1{$key}{$$names[1]}=~/Hete/i) && ($forcal1{$key}{$$names[2]}=~/Wild/i) && ($forcal1{$key22}{$$names[1]}=~/Wild/i) && ($forcal1{$key22}{$$names[2]}=~/Hete/i))
							{
								my @values;
								push @values,$forcal2{$key}{$$names[2]},$forcal2{$key22}{$$names[1]};
								@values=sort {$a <=> $b} @values;
								my $tag="$values[0]".'+'."$values[1]";
								my $number=$values[0]+$values[1];
								push @{$close{$key}{$number}},"e_2,m($tag)";
								$fuhezahe->{$key}.="=$key22";
							}elsif (($forcal1{$key}{$$names[1]}=~/Wild/i) && ($forcal1{$key}{$$names[2]}=~/Hete/i) && ($forcal1{$key22}{$$names[1]}=~/Hete/i) && ($forcal1{$key22}{$$names[2]}=~/Wild/i))
							{
								my @values;
								push @values,$forcal2{$key}{$$names[1]},$forcal2{$key22}{$$names[2]};
								@values=sort {$a <=> $b} @values;
								my $tag="$values[0]".'+'."$values[1]";
								my $number=$values[0]+$values[1];
								push @{$close{$key}{$number}},"e_2,m($tag)";
								$fuhezahe->{$key}.="=$key22";
							}else
							{
								push @{$close{$key}{10}},"e_2,n_2";
							};
						};
					};
				};
			};
			foreach my $key (keys %close)
			{
			INSIDE:foreach my $num (sort {$a <=> $b} keys %{$close{$key}})
				{
					my ($tmp1,$tmp2)=split /\;/,$key;
					my @tmp1=@{$close{$key}{$num}};
					my @tmp2=grep /\+/,@tmp1;
					if (@tmp2>=1)
					{
						$hash->{$tmp1}{$tmp2}=$tmp2[0];
					}else
					{
						$hash->{$tmp1}{$tmp2}=$tmp1[0];
					};
					last INSIDE;
				}
			};
};

##########################################################################
sub get_AD_number
{
	my($tag,$num)=@_;
	if ($tag eq 'AD')
	{
		$num=1;
	}elsif($tag eq 'AR')
	{
		$num=2;
	}elsif($tag eq 'XD')
	{
		$num=3;
	}elsif($tag eq 'XR')
	{
		$num=4;
	}elsif($tag eq 'Y')
	{
		$num=5;
	}elsif($tag eq 'NA')
	{
		$num=1;
	};
	return $num;
};

##########################################################################
sub get_fam_conclusion
{
	my ($tag,$hash,$mut,$res,$fuhezahe)=@_;
	$res='NA|ERR';
	if ($tag=~/p/)
	{
		if ($tag=~/e_1/)
		{
			if($tag=~/p_1/)
			{
				$res='A_4|F2';
			}elsif($tag=~/p_2_1/)
			{
				$res='A_5_1|F2';
			}elsif($tag=~/p_2_2/)
			{
				$res='A_5_2|F2';
			}elsif($tag=~/p_3/)
			{
				$res='A_6|F2';
			};
		}elsif($tag=~/e_2/)
		{
			if ($tag=~/p_1/)
			{
				$res='A_7|F2';
			}else
			{
				$res='A_7|F2';
			};
		}else
		{
			if($tag=~/p_1/)
			{
				$res='A_1|F1';
			}elsif($tag=~/p_2_1/)
			{
				$res='A_2_1|F1';
			}elsif($tag=~/p_2_2/)
			{
				$res='A_2_2|F1';
			}elsif($tag=~/p_3/)
			{
				$res='A_3|F1';
			};
			#############
			if ($tag=~/b/)
			{
				$res='A_1|F4';
			}elsif($tag=~/c/)
			{
				$res='A_1|F5';
			};
		};
	}elsif($tag=~/e_1/)
	{
		$res="F|F2";
	}elsif($tag=~/e_2/)
	{
		if($tag=~m/m(\(.*?\))/)
		{
			$res='B|F1';
			$fuhezahe=$1;
		}elsif($tag=~/n_1/)
		{
			$res='E_1|F2';
		}elsif($tag=~/n_2/)
		{
			$res='E_2|F2';
		}else
		{
			$res="F|F2";
		};
	}elsif($tag=~/d/)
	{
		$res='G|F6';
	}elsif($tag=~/b/)
	{
		$res='C|F4';
	}elsif($tag=~/c/)
	{
		$res='D|F5';
	}elsif($tag=~/a/)
	{
		$res='A|F1';
	}elsif($tag=~/z/)
	{
		$res='mutation_in_XX_chrY|F3';
	};
	return $res;
};

=cut
		$hash->{$arr[0]}{'off'}=$arr[2];		#######性别
		$hash->{$arr[0]}{'path'}=$arr[9];		#######是否患病
		$hash->{$arr[0]}{'rea'}=$arr[6];		#######样本名
		$hash->{$arr[0]}{'rel'}=$arr[10];		#######家系关系
=cut

######################################################################################################################################
######################################################################################################################################
sub get_ACMG		###################&standard_family::get_ACMG(\@bestNM,$cds,$pm1,\%acmg11);
{
	my ($bestnms,$cds,$pm1,$mut_genetic,$hash,$dis_hot,$mq,$sampname)=@_;
	my (%PM1,%cds,%reference);
	open (CDS,"$cds") || die ;
	while (<CDS>) 
	{
		chomp;	next if (/^$/);
		my @line=split "\t",$_;
		push @{$cds{$line[0]}},"$line[2]\-$line[3]";
	};
	close CDS;
	open (PM1,"$pm1") || die ;
	while (<PM1>) 
	{
		chomp;	next if (/^$/); 
		my @line=split "\t",$_;
		$PM1{$line[0]}{$line[1]}=$_;
	};
	close PM1;
	my (%path,%data,%ACMG);
	for (my $i=0;$i<@{$bestnms} ;$i++)
	{
			open (IN,"$$bestnms[$i]") || die ;
			while (<IN>) 
			{
				chomp;
				next if (/^$/ || /^Chr/);
##				next if ($_!~/124605505/);
				
				my @line=split "\t",$_;
				if ($line[0]=~/NC/)
				{
					$line[0]=&chr_convert($line[0]);####$line[0]=~s/chr//g;
				};

			my $key=&get_mut_compile("$line[0]:$line[1]-$line[2]",$line[8],$line[6]);

			if ($key=~/err/)
			{
				print STDERR "error: get mut tag !\t $key\n";
				die;
			};

				my @omim=split /\|/,$line[22];
				my $omimid='NA';$omimid=$omim[1] if(defined $omim[1]);

				next if (not exists $mut_genetic->{$key}{$omimid});

				$data{$key}{$omimid}=\@line;
				if (($omim[0] eq "OMIM") || ($line[24] eq "SWISS") || ($line[26] eq "HGMD") || ($line[29]=~/Pathogenic/i))
				{
					$path{$line[6]}{$key}{$omimid}=1;
				};
			};
			close IN;
	};

			foreach my $KEY (keys %data)
			{
				foreach my $omimid (keys %{$data{$KEY}})
				{
						my @line=@{$data{$KEY}{$omimid}};
								my $ref=$line[3];
								my $mut=$line[4];
								my $nm=(split ":",$line[8])[0];
								my @omim=split /\|/,$line[22];

                                                                my $signal=0;
                                                                if (exists $cds{$nm})
                                                                {
                                                                        my @beds=@{$cds{$nm}};
                                                                OUT:foreach (@beds)
                                                                        {
                                                                                my ($start,$end)=split /\-/,$_;
                                                                                if ($start<=$line[2] && $end>=$line[1])
                                                                                {
                                                                                        $signal=1;
                                                                                        last OUT;
                                                                                }
                                                                        }
                                                                };
                                                                if ($mut_genetic->{$KEY}{$omimid}=~/NA/)
                                                                {
                                                                        $mut_genetic->{$KEY}{$omimid}=10000;
                                                                };

                                                                if ($line[7]=~/stopgain/i && $signal==0 && ($mut_genetic->{$KEY}{$omimid}==1 || $mut_genetic->{$KEY}{$omimid}==4))
                                                                {
                                                                                push @{$ACMG{$KEY}{$omimid}},"PVS1(无义截断变异)";
                                                                };
                                                                if ($line[7]=~/^frameshift/i && $signal==0 && ($mut_genetic->{$KEY}{$omimid}==1 || $mut_genetic->{$KEY}{$omimid}==4))
                                                                {
                                                                                push @{$ACMG{$KEY}{$omimid}},"PVS1(移码变异)";
                                                                };


								my @class=split /\|/,$line[32];
								my @splice=("16104","16304","16404","16204","2310","2320","2330","2340");
								if ($class[0]~~@splice && $signal==0 && ($mut_genetic->{$KEY}{$omimid}==1 || $mut_genetic->{$KEY}{$omimid}==4))
								{
									push @{$ACMG{$KEY}{$omimid}},"PVS1(经典剪切位点上的变异)";
								}elsif(($line[31]!~/^Deleterious/i) && ($line[5]=~/^intronic/i))
								{
									push @{$ACMG{$KEY}{$omimid}},"BP7(不影响剪切的内含子变异)";
								};

                                                                if ($line[7]=~/initiation/i && $signal==0 && ($mut_genetic->{$KEY}{$omimid}==1 || $mut_genetic->{$KEY}{$omimid}==4))
                                                                {
                                                                        my $insdel=$line[32];
                                                                        if (($insdel=~/^1/ && ($line[8]!~/p\.M1M/i)) || ($insdel=~/^2/))
                                                                        {
                                                                                        push @{$ACMG{$KEY}{$omimid}},"PVS1(起始密码子变异)";
                                                                        };
                                                                };

								if (exists $path{$line[6]})
								{
									if(exists $path{$line[6]}{$KEY}{$omimid})
									{
										push @{$ACMG{$KEY}{$omimid}},"PS1(有疾病报道变异)";
									}else
									{
										push @{$ACMG{$KEY}{$omimid}},"BP5(该基因发现致病变异则其他变异获得BP5)";
									};
								};
								my $gene_name=(split /\|/,$line[6])[0];
								if ($line[8]=~m/.*p.\D+(\d+)\D+.*/) 
								{
									my $psite="p.".$1;
									if ((exists $PM1{$gene_name}{$psite}) && ($line[7]=~/nonsynonymous/i || $line[7]=~/frameshift/i)) 
									{
										push @{$ACMG{$KEY}{$omimid}},"PM1(致病氨基酸左右的变异)";
									};
								};
								$line[19]=~s/NA/0/g;
								my ($east,$esp)=(split /[|;]/,$line[19])[0,3];
								if ($line[15] eq "NA"){$line[15]=0}; 
								if ($line[20] eq "NA"){$line[20]=0}; 
								if ($line[9]!~/rs/i && $line[21]!~/rs/i) 
								{
									push @{$ACMG{$KEY}{$omimid}},"PM2(无rs号的变异)";
								}elsif($line[15]<0.05 && $east<0.05 && $esp<0.05 && $line[20]<0.05)
								{
									push @{$ACMG{$KEY}{$omimid}},"PM2(有rs号的低频变异)";
								};

								if($line[15]>=0.05 || $east>=0.05 || $esp>=0.05 || $line[20]>=0.05)
								{
									push @{$ACMG{$KEY}{$omimid}},"BA1(千人/ExAC东亚/ESP/dbSNP数据库中任一MAF>5%)";
								};
								#####################
								my @maf=split /\s+|\||\;/,(join "|",@line[15..20]);
								my $meMAF_dis=(split /\|/,$line[18])[1];
								my $big="NA";
								foreach my $tmp_maf(@maf)
								{
									if ($tmp_maf=~/\d+/ && $big=~/NA/)
									{
										$big=$tmp_maf;
									}elsif($tmp_maf=~/\d+/ && $tmp_maf>$big)
									{
										$big=$tmp_maf;
									};
								};
								if($big=~/\d+/ && $big==0)
								{
								}elsif (defined $meMAF_dis && $meMAF_dis=~/\d+/ && $big=~/\d+/ && ($meMAF_dis/$big > 1.5))
								{
									push @{$ACMG{$KEY}{$omimid}},"PS4(患者频率>>普通人频率)";
								};
								#################################
								if ($line[7]=~/non-frameshift/i) 
								{
									push @{$ACMG{$KEY}{$omimid}},"PM4(非移码变异)";
								};
								if ($line[7]=~/stoploss/i) 
								{
									push @{$ACMG{$KEY}{$omimid}},"PM4(终止密码子变异导致的蛋白延长)";
								};
								if ($line[32]=~/a/) 
								{
									push @{$ACMG{$KEY}{$omimid}},"PM5(已报道致病位点上的其它类型变异)";
								};
								##############################
								my $rubish="NA";
								my $jielun="NA";
								&get_sift($line[30],$rubish,\$jielun,\$rubish);
						########&get_sift($arr[32],$type12,\$protein_predict,\$construct_path);
								if($jielun=~/有害/)
								{
									push @{$ACMG{$KEY}{$omimid}},"PP3(至少2个软件预测有害)";
								}elsif($jielun=~/无害/)
								{
									push @{$ACMG{$KEY}{$omimid}},"BP4(至少2个软件预测无害)";
								};

								my @ssr=split /[=\|]/,$line[14];
								if (($line[13] eq "YES" || $ssr[1]>7) && ($line[32]=~/^2/)) 
								{
									push @{$ACMG{$KEY}{$omimid}},"BP3(重复区域/ssr>7区域的indel)"
								};
								if ($line[29]=~/Benign/i) 
								{
									push @{$ACMG{$KEY}{$omimid}},"BP6(Clinvar为benign)";
								};
								if ($line[7]=~/^synonymous/i && ($line[31]!~/^Deleterious/i))
								{
									push @{$ACMG{$KEY}{$omimid}},"BP7(不影响剪切的同义变异)";
								};
								if ($line[45]=~/Y/ && $line[9]!~/rs/i && $line[21]!~/rs/i)
								{
									push @{$ACMG{$KEY}{$omimid}},"PM1(位于多次被报道过存在致病变异的外显子上的新发突变)";	##########by lzw 20160707
								};
								$hash->{$KEY}{$omimid}=\@{$ACMG{$KEY}{$omimid}};
								################################################################
								if ($line[44]=~/Y/){$line[44]="是"}else{$line[44]="否"};
								if ($line[45]=~/Y/){$line[45]="是"}else{$line[45]="否"};
								my @dishot=@line[40..45];
								foreach my $AA (@dishot)
								{
									$AA=~s/\s+//g;
									if ($AA=~/^$/)
									{
										$AA="NA";
									};
								};
								$dis_hot->{$KEY}=\@dishot;
#print "$KEY\n";
=cut
								################################################################
								$mq->{$KEY}{$omimid}{$$sampname[$i]}{'mq'}=$line[11];
								$mq->{$KEY}{$omimid}{$$sampname[$i]}{'repeat'}=$line[13];
								if ($line[9]!~/rs/i && $line[21]!~/rs/i)
								{
									$mq->{$KEY}{$omimid}{$$sampname[$i]}{'rs'}='NO';
								}else
								{
									$mq->{$KEY}{$omimid}{$$sampname[$i]}{'rs'}="YES";
								};
=cut
				};
			};
};
######################################################################################################################################
######################################################################################################################################
sub get_acmg_value		####################&standard_family::get_acmg_value(\@relys,\$acmgre);
{
	my ($acmg,$result,$tag)=@_;
	my ($pvs1,$ps,$pm,$pp,$ba,$bs,$bp,$sig_path,$sig_beni,$class)=(0,0,0,0,0,0,0,0,0,0,0);
	for (my $i=0;$i<@{$acmg};$i++) 
	{
		next if ($$acmg[$i]=~/Y/ && $tag==0);
		if ($$acmg[$i]=~/PVS1/)
		{
			$pvs1++;
		}elsif ($$acmg[$i]=~/^PS/)
		{
			$ps++;
		}elsif ($$acmg[$i]=~/^PM/)
		{
			$pm++;
		}elsif ($$acmg[$i]=~/^PP/)
		{
			$pp++;
		}elsif ($$acmg[$i]=~/^BA/)
		{
			$ba++;
		}elsif ($$acmg[$i]=~/^BS/)
		{
			$bs++;
		}elsif ($$acmg[$i]=~/^BP/)
		{
			$bp++;
		};
	};
	if ($pvs1==1)
	{
		$sig_path=1;
		if ($ps>=1)
		{
			$$result="致病突变|Pathogenic(I)(a)";
		}elsif($pm>=2)
		{
			$$result="致病突变|Pathogenic(I)(b)";
		}elsif($pm==1 and $pp==1)
		{
			$$result="致病突变|Pathogenic(I)(c)";
		}elsif($pp>=2)
		{
			$$result="致病突变|Pathogenic(I)(d)";
		}else
		{
			$sig_path=0;
		};
	}elsif ($ps>=2)
	{
		$sig_path=1;
		$$result="致病突变|Pathogenic(II)";
	}elsif ($ps==1)
	{
		$sig_path=1;
		if ($pm>=3)
		{
			$$result="致病突变|Pathogenic(III)(a)";
		}elsif($pm==2 and $pp>=2)
		{
			$$result="致病突变|Pathogenic(III)(b)";
		}elsif($pm==1 and $pp>=4)
		{
			$$result="致病突变|Pathogenic(III)(c)";
		}else
		{
			$sig_path=0;
		};
	};
	if ($ba==1)
	{
		$sig_beni=1;
		$$result="良性突变|Benign(I)";
	}elsif($bs>=2)
	{
		$sig_beni=1;
		$$result="良性突变|Benign(II)";
	};
	if ($sig_path==1 && $sig_beni==1) 
	{
		$$result="不确定致病性|Uncertain significance(II)";
	}elsif ($sig_path==0 && $sig_beni==0)
	{
		if ($bs==1 and $bp==1)
                {
                        $$result="可能良性突变|Likely benign(I)";
                }elsif($bp>=2)
                {
                        $$result="可能良性突变|Likely benign(II)";
                }elsif ($pvs1==1 and $pm==1)
		{
			$$result="可能致病突变|Likely pathogenic(I)";
		}elsif($ps==1 and ($pm==1 or $pm==2))
		{
			$$result="可能致病突变|Likely pathogenic(II)";
		}elsif($ps==1 and $pp>=2)
		{
			$$result="可能致病突变|Likely pathogenic(III)";
		}elsif($pm>=3)
		{
			$$result="可能致病突变|Likely pathogenic(IV)";
		}elsif($pm==2 and $pp>=2)
		{
			$$result="可能致病突变|Likely pathogenic(V)";
		}elsif($pm==1 and $pp>=4)
		{
			$$result="可能致病突变|Likely pathogenic(VI)";
		}else
		{
			$$result="不确定致病性|Uncertain significance(I)";
		};
	};
};
######################################################################################################

sub get_acmg_result
{
	my($array,$conyes,$conno,$match,$reaYES,$reaNO)=@_;
	my @arr=@{$array};
	my %uniq;
	@arr=grep ++$uniq{$_}<2,@arr;
	my ($tmp,@arr11,@ms11,%arr11,@arr22,@ms22,%arr22);
	$$match=0;
	foreach (@arr)
	{
		if ($_=~/Y/)
		{
			$$match=1;
			$_=~s/Y//g;
			push @arr11,$_;
			if ($_=~m/([a-zA-Z]+)(\d+)\((.*)\)/)
			{
				my $zimu=$1;
				my $shuzi=$2;
				my $ms=$3;
				push @{$arr11{$zimu}},$shuzi;
				push @ms11,$_;
			};
		}else
		{
			push @arr11,$_;
			push @arr22,$_;
			if ($_=~m/([a-zA-Z]+)(\d+)\((.*)\)/)
			{
				my $zimu=$1;
				my $shuzi=$2;
				my $ms=$3;
				push @{$arr11{$zimu}},$shuzi;
				push @{$arr22{$zimu}},$shuzi;
				push @ms11,$_;
				push @ms22,$_;
			};
		};
	};
	&get_acmg_value(\@arr11,\$tmp,1);
	$tmp.="--";
	foreach my $AA (sort keys %arr11)
	{
		my $tmpAA;
		if(@{$arr11{$AA}}==1)
		{
			$tmpAA="$AA"."@{$arr11{$AA}}[0]";
		}else
		{
			my $sum=join ",",sort {$a<=>$b} @{$arr11{$AA}};
			$tmpAA="$AA"."\($sum\)";
		};
		$tmp.="$tmpAA+";
	};
	$tmp=~s/\+$//;
	($$reaYES,$$conyes)=split /\|/,$tmp;
	$$reaYES.="(".(join ",",@ms11).")";
	############################
	&get_acmg_value(\@arr22,\$tmp,0);
	$tmp.="--";
	foreach my $AA (sort keys %arr22)
	{
		my $tmpAA;
		if (@{$arr22{$AA}}==1)
		{
			$tmpAA="$AA"."@{$arr22{$AA}}[0]";
		}else
		{
			my $sum=join ",",sort {$a<=>$b} @{$arr22{$AA}};
			$tmpAA="$AA"."\($sum\)";
		};
		$tmp.="$tmpAA+";
	};
	$tmp=~s/\+$//;
	($$reaNO,$$conno)=split /\|/,$tmp;
	$$reaNO.="(".(join ",",@ms22).")";
};
########################################
sub get_separation
{
	my($com,$depend,$fam,$AR_het,@arr)=@_;
	if ($com eq '1')
	{
		$arr[0]=1;
	}elsif($com eq '4' || $com eq '15' || $com eq '30')
	{
		$arr[0]=0;
	}else
	{
		$arr[0]=-1;
	};
	#####################
	if ($depend=~/denovo/)
	{
		$arr[1]=1;
	}elsif($fam=~/YES/)
	{
		$arr[1]=0;
	}else
	{
		$arr[1]=-1;
	};
	############################
	if ($depend=~/\(\d\+\d\)/)
	{
		$arr[2]=1;
	}elsif($fam=~/NO/ && $AR_het=~/AR_poly/)
	{
		$arr[2]=-1;
	}else
	{
		$arr[2]=0;
	};
	return @arr;
};

1;
