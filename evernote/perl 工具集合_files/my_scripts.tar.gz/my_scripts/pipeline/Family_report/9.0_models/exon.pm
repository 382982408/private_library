package exon;
{
	$Path::exon::VERSION = '0.1';
};
#!/usr/bin/perl -w
use strict;
use Cwd;
use Getopt::Long;
use Data::Dumper;
use Spreadsheet::WriteExcel;
use Excel::Writer::XLSX;
use Spreadsheet::ParseExcel;
use Encode;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

sub path{
	my $cur_dir=`pwd`;
	chomp($cur_dir);
	my ($in)=@_;
	my $return="";
	if(-f $in){
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;chomp $dir;
		$return="$dir/$file";
	}elsif(-d $in){
		chdir $in;$return=`pwd`;chomp $return;
	}else{
		warn "Warning just for file and dir:$in\n";
		exit;
	}
	chdir $cur_dir;
	return $return;
};
##########################################################################
sub chr_convert{
	my $chr=(split /0{4,5}|\./,$_[0])[1];
	if ($chr eq '23') {$chr='X'}
	elsif($chr eq '24'){$chr='Y'};
	return "chr$chr";
};
###############################################################################################
sub get_uniq
{
	my @TMP=@_;
	my (%uniq,@tmp);
	foreach my $A (@TMP)
	{
		if (not exists $uniq{$A})
		{
			push @tmp,$A;
			$uniq{$A}=1;
		};
	};
	return @tmp;
};
##########################################################################
sub get_base_seq
{
	my ($pos,$genenome)=@_;
	my $seq=`samtools faidx $genenome $pos|grep -v chr`;
	$seq=~s/\s+//g;
	return $seq;
};

#################################################
sub get_vcf_depth			##########&get_vcf_depth($file,\%hash);
{
	my ($file,$hash)=@_;
	open L,"$file" or die;
	while (<L>)
	{
		chomp;
		next if (/^$/ || /^\#/);
		my @arr=split /\t/,$_;
		my @ALTS=split /\,/,$arr[4];
		my ($MQ)=$_=~m/MQ=(.*?);/;
		my ($chr,$posori,$rs,$refori,$depth,$totdepth)=@arr[0,1,2,3,9];
		($depth,$totdepth)=(split /\:/,$depth)[1,2];
		my @depth=split /\,/,$depth;
		foreach my $i (0..@ALTS-1)
		{
			my $start=$posori;
			my $end=$posori;
			my $ref=$refori;
			my $alt=$ALTS[$i];
			my $ratio;
			if ($totdepth eq '0')
			{
				$ratio=0;
			}elsif($totdepth=~/^\d+$/)
			{
				$ratio=$depth[$i+1]/$totdepth;
			}else
			{
				next;
			};
			$ratio=sprintf("%.4f",$ratio);
			my $depout="$depth[$i+1]".'/'."$totdepth".'='."$ratio";
			if ($ref=~/^[ATCG]$/ && $alt=~/^[ATCG]$/)
			{
				$hash->{"$chr-$start-$end"}{$ref}{$alt}="$rs\t$depout\t$MQ";
			}elsif(length$ref==1 && length$alt>1)
			{
				$end=$start+1;
				$ref='-';
				$alt=~s/^[ATCG]//;
				$hash->{"$chr-$start-$end"}{$ref}{$alt}="$rs\t$depout\t$MQ";
			}elsif(length$alt==1 && length$ref>1)
			{
				$start+=1;
				$ref=~s/^[ATCG]//;
				$alt="-";
				$end+=length$ref;
				$hash->{"$chr-$start-$end"}{$ref}{$alt}="$rs\t$depout\t$MQ";
			}else
			{
				#####################################################  值得注意的是 annovar 格式转换也有不给转换的情况，故原位置也保存，
				my $end0=$start+(length$ref)-1;
				$hash->{"$chr-$start-$end0"}{$ref}{$alt}="$rs\t$depout\t$MQ";
				####################################
				if ($ref=~/^$alt/)
				{
					$ref=~s/^$alt//;
					$start+=length$alt;
					$end=$start+(length $ref)-1;
					$alt='-';
					$hash->{"$chr-$start-$end"}{$ref}{$alt}="$rs\t$depout\t$MQ";
				}elsif($alt=~/^$ref/)
				{
					$alt=~s/^$ref//;
					$start+=(length $ref)-1;
					$end=$start+1;
					$ref='-';
					$hash->{"$chr-$start-$end"}{$ref}{$alt}="$rs\t$depout\t$MQ";
				}else
				{
					my @ref=split //,$ref;
					my @alt=split //,$alt;
					my ($start1,$start2,$end1,$end2)=($start,$start,$end,$end);
					my ($ref1,$ref2,$alt1,$alt2)=($ref,$ref,$alt,$alt);
					for (my $i=0;$i<@ref && $i<@alt;$i++)	#############正向比较
					{
						if ($ref[$i] eq $alt[$i])
						{
							$ref1=~s/^[ATCG]//;
							$alt1=~s/^[ATCG]//;
							next;
						}else
						{
							$ref1='-'if($ref1=~/^$/);
							$alt1='-'if($alt1=~/^$/);
							if ($alt1 eq '-')			#############del
							{
								$start1+=$i;
								$end1=$start1+(length$ref1)-1;
							}elsif($ref1 eq '-')		##############ins
							{
								$start1+=$i-1;
								$end1=$start1+1;
							}else						##############delins
							{
								$start1+=$i;
								$end1=$start1+(length$ref1)-1;
							};
							last;
						};
					};
					$hash->{"$chr-$start1-$end1"}{$ref1}{$alt1}="$rs\t$depout\t$MQ";
					#####################################################
					for (my $i=1;$i<=@ref && $i<=@alt;$i++)	#############反向比较
					{
						if ($ref[-$i] eq $alt[-$i])
						{
							$ref2=~s/[ATCG]$//;
							$alt2=~s/[ATCG]$//;
						}else
						{
							$ref2='-'if($ref2=~/^$/);
							$alt2='-'if($alt2=~/^$/);
							if ($alt2 eq '-')			#############del
							{
								$end2=$start2+(length$ref2)-1;
							}elsif($ref2 eq '-')		##############ins
							{
								$start2-=1;
							}else						##############delins
							{
								$end2=$start2+(length$ref2)-1;
							};
							last;
						};
					};
					$hash->{"$chr-$start2-$end2"}{$ref2}{$alt2}="$rs\t$depout\t$MQ";
				};
			};
		};
	};
	close L;
};
###############################################################################################
sub get_OMIM_inf
{
	my ($file,$hash)=@_;
	open L,"$file" or die;
	<L>;
	while (<L>)
	{
		chomp;
		next if (/^$/);
		my ($gene,$gene_arr,$gene_OMIM,$dis_OMIM,$inherit,$disease)=split /\t/,$_;
		next if(!$gene || !$gene_OMIM);
		if (!$inherit || $inherit!~/[A-Z]+/)
		{
			$inherit="NA";
		};
		push @{$hash->{$gene}},"$gene_OMIM|$dis_OMIM|$inherit|$disease";
	};
	close L;
};
###############################################################################################

sub get_fam_relative
{
	my ($number,$stdout)=@_;
	my $outfile="./$number\.txt";
	my $pro=`grep $number /share/nas1/wangxf/Basecall/All.RAW|wc -l`;chomp $pro;
	if ($pro == 1)
	{
		$pro=`grep $number /share/nas1/wangxf/Basecall/All.RAW|cut -f 4`;chomp $pro;
	}else
	{
		$pro=`grep $number /share/nas1/wangxf/Basecall/All.RAW|grep NT|cut -f 4`;chomp $pro;
	};
	`wget -O $outfile -P ./ http://sample.deyidongfang.com/sample-app/desktop/sale/SpecialExam/findSpecialExamList.action?taskCode=$number\_$pro`;
	my $tmp=`grep $number $outfile`;chomp $tmp;
	`rm $outfile`;
	my @springs=split /\;/,$tmp;
	foreach (@springs)
	{
		my @arr=split /\,/,$_;
		$arr[0]=`grep $arr[0] /share/nas1/wangxf/Basecall/All.RAW|tail -1|cut -f 2`;chomp $arr[0];
		if ($arr[2]=~/女/){$arr[2]='FM';}else{$arr[2]='M'};
		if ($arr[14]=~/患者/){$arr[14].="\t4"}
		elsif($arr[14]=~/轻微表型/){$arr[14].="\t2"}
		elsif($arr[14]=~/正常/){$arr[14].="\t0"};
		my $relate='NA';
		if($arr[12]!~/先证者/)
		{
			if ($arr[12]=~/父/)
			{
				$relate='father';
			}elsif($arr[12]=~/母/)
			{
				$relate='mother';
			}elsif(($arr[12]=~/兄/ || $arr[12]=~/弟/ ||$arr[12]=~/姐/ ||$arr[12]=~/妹/) && ($arr[14]=~/2|4/))
			{
				if ($arr[2] eq 'FM')
				{
					$relate='daughter';
				}elsif($arr[2] eq 'M')
				{
					$relate='son';
				};
			}else
			{
				$relate='other';
			};
			$arr[12]='先证者之'."$arr[12]";
		}elsif($arr[2] eq 'FM')
		{
			$relate='daughter';
		}elsif($arr[2] eq 'M')
		{
			$relate='son';
		};
		my $res=join "\t",@arr[0,1,2,9..14],$relate;
		$stdout.="$res\n";
	};
	return $stdout;
};
###############################################################################################
sub get_report_sh
{
	my ($num,$level,$od,$out)=@_;
	my ($file,$sex)=&get_sample_file($num);
	if (!$file || !-f $file)
	{
		return "NA";
	}else
	{
		my $id=dirname($file);$id=dirname($id);
		my $pro=`grep $num /share/nas1/wangxf/Basecall/All.RAW |grep NT|tail -1|cut -f 4`;chomp $pro;
		if ($file=~/level.report.txt/)
		{
			my $batch=`grep ^batch $id/conf.txt |cut -f 3`;chomp $batch;
			if ($batch!~/\d+/)
			{
				$batch=`grep ^batch $id/conf.txt |cut -f 2`;chomp $batch;
			};
			my $outname="$num\_$pro\_b${batch}A\_Poly_v1.5.xlsx";
			if ($level==5)
			{
				$file=~s/tot_3_level.report.txt/tot_5_level.report.txt/;
			};
			$out="perl /share/nas1/heh/bin/Report/GeneticForSmallSingle_v2tov1_v2.0.pl -i $file -id $id -b $batch -all -o $od/Reports/$outname\n";
		}else
		{
			my $batch=`grep ^batch $id/conf.txt |cut -f 3`;chomp $batch;
			if ($batch!~/\d+/)
			{
				$batch=`grep ^batch $id/conf.txt |cut -f 2`;chomp $batch;
			};
			my $outname="$num\_$pro\_b${batch}A\_Poly_v1.xlsx";
			if ($level ==5)
			{
				$file=~s/secondary_merge_best_convert_of_SNP_and_Indel.longest.add_sampleID.txt/secondary_merge_best_convert_of_SNP_and_Indel.noFilter.longest.add_sampleID.txt/;
			};
			$out="perl /share/nas1/heh/bin/Report/GeneticReport2ExcelAB.pl -i $file -id $id -b $batch -all -o $od/Reports/$outname\n";
		};
		return $out;
	};
};
###############################################################################################
sub get_sample_file
{
	my ($list,$dir,$sex)=@_;
	my @tmp;
	if (length$list==5)
	{
		@tmp=(glob "/share/nas1/database/sample/@{[substr($list,0,2)]}*/$list*/Result/secondary_merge_best_convert_of_SNP_and_Indel.longest.add_sampleID.txt");
	}elsif(length$list==4)
	{
		@tmp=(glob "/share/nas1/database/sample/@{[substr($list,0,1)]}*/$list*/Result/secondary_merge_best_convert_of_SNP_and_Indel.longest.add_sampleID.txt");
	};
	
	$dir=(grep /[^old]/,@tmp)[0];
	if (!$dir)
	{
		my @tmp2;
			if (length$list==5)
			{
				@tmp2=(glob "/share/nas1/database/sample/@{[substr($list,0,2)]}*/$list*/3.3_variation_annotation/tot_3_level.report.txt");
			}elsif(length$list==4)
			{
				@tmp2=(glob "/share/nas1/database/sample/@{[substr($list,0,1)]}*/$list*/3.3_variation_annotation/tot_3_level.report.txt");
			};
		$dir=(grep /[^old]/,@tmp2)[0];
	};
	if ($dir && $dir=~/2.3_function_region_map_stat/)
	{
		my $sexfile=$dir;		$sexfile=~s/2.3_function_region_map_stat\/bed_depth_coverage.txt/4.1_QC\/QC_report.txt/;
		$sex=`grep sex $sexfile|cut -f 1|cut -d ":" -f 2`;chomp $sex;
	}elsif($dir)
	{
		my $sexfile=$dir;		$sexfile=~s/function_region\/bed_depth.average.txt/map_stat\/sex_test.out/;
		$sex=`cut -f 3 $sexfile`;chomp $sex;
	};
	if ($dir && $sex)
	{
		return ("$dir","$sex");
	};
};
###############################################################################################
sub get_gene_cov_dep
{
	my ($cov_dep_file,$hash,%result)=@_;
	open L,"$cov_dep_file" or die"$!";
	while(<L>)
	{
		chomp;
		next if /^$/;
		my @array=split;
		my $gene=$array[4];
		next if (!$gene);
		$result{$gene}{'cover_length'}+=(split /\//,$array[-2])[0];
		$result{$gene}{'length'}+=(split /\//,$array[-2])[1];
		$result{$gene}{'depth'}+=(split /\//,$array[-4])[0];
	};
	close L;
	foreach my $A(keys %result)
	{
		my $coverage=$result{$A}{'cover_length'}/$result{$A}{'length'};
		my $average=$result{$A}{'depth'}/$result{$A}{'length'};
		$hash->{$A}="$coverage\t$average";
	};
};
###############################################################################################
sub get_expression		############&exon::get_expression($tiger_file,$gtex_file,$tissu_tran,\%tiger,\%gtex);
{
	my ($bestNM,$fanyi,$tiger_file,$hash_tiger)=@_;
	my (%gene,%trans);
	open L,"$bestNM" or die;
	while (<L>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		my $genename=(split /\|/,$arr[6])[0];
		$gene{$genename}=1;
	};
	close L;
	##########################
	open L,"$fanyi" or die;
	while (<L>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		$arr[0]=~s/ /_/g;
		$trans{$arr[0]}=$arr[1];
	};
	close L;
	###########################
	open M,"$tiger_file" or die;
	<M>;
	while (<M>)
	{
		chomp;
		next if(/^$/ || /^\#/);
		my @arr=split /\t/,$_;
		my @GENES=split /\,/,$arr[1];
		foreach my $GENE (@GENES)
		{
			next if(not exists $gene{$GENE});
			my @high=split /\,/,$arr[2];
			foreach my $high_ex (@high)
			{
				if (exists $trans{$high_ex})
				{
					push @{$hash_tiger->{$GENE}{high}},"$trans{$high_ex}";
				}else
				{
				##	print STDERR "$high_ex\n";
					next if($high_ex eq 'NA');
					push @{$hash_tiger->{$GENE}{high}},"$high_ex";
				};
			};
			my @low=split /\,/,$arr[3];
			foreach my $low_ex (@low)
			{
				if (exists $trans{$low_ex})
				{
					push @{$hash_tiger->{$GENE}{low}},"$trans{$low_ex}";
				}else
				{
				##	print STDERR "$low_ex\n";
					next if($low_ex eq 'NA');
					push @{$hash_tiger->{$GENE}{low}},"$low_ex";
				};
			};
		};
	};
	close M;
};
#######################################################################################
sub get_diseasehot		#################&exon::get_diseasehot($bestNM,$dishot_file,\%disease_hot);
{
	my ($bestnm,$dishot,$out,$hash)=@_;
	open L,"$bestnm" or die;
	open K,">$out\.tmp1.bed" or die;
	<L>;
	while (<L>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		my $genename=(split /\|/,$arr[6])[0];
		my $NM=(split /[:.]/,$arr[8])[0];
		$arr[2]+=1;
		print K "chr$arr[0]\|$genename\|$NM\t$arr[1]\t$arr[2]\n";
	};
	close L;
	close K;
	`bedtools sort -i $out\.tmp1.bed >$out\.tmp2.bed`;
	`bedtools window -a $out\.tmp2.bed -b $dishot -w 1 >$out\.tmp3.bed`;
	open M,"$out\.tmp3.bed" or die;
	while (<M>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		$arr[2]-=1;
		$hash->{"$arr[0]|$arr[1]|$arr[2]"}{cons}=$arr[8];
		$hash->{"$arr[0]|$arr[1]|$arr[2]"}{path}=$arr[11];
	};
	close M;
	`rm $out\.tmp1.bed $out\.tmp2.bed $out\.tmp3.bed`;
};
###################################################################################
###############################################################################################
sub get_nX_ratio	#######&exon::get_gene_10X_cov($bed_depth,\%gene_bed,\%cov_dep,\%genecov_10X);
{
	my ($gene,$depth,$out,$hash)=@_;
	my($totlen,$totdepth,%totpoint);
	open L,"$depth" or die;
	open M,"> $out\.tmp1.bed" or die;
	while (my $DEPTH=<L>)
	{
		chomp $DEPTH;
		next if ($DEPTH=~/^$/);
		my @array=split /\t/,$DEPTH;
		my $start=$array[1]-1;
		print M "$array[0]\t$start\t$array[1]\t$array[2]\n";
	};
	close L;
	close M;
	############################################
	open N,"$gene" or die;
	open Z,"> $out\.tmp2.bed" or die;
	while (<N>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		$totlen+=$arr[2]-$arr[1];
		print Z "$arr[0]\t$arr[1]\t$arr[2]\n";
	};
	close N;
	close Z;
	`bedtools window -a $out\.tmp2.bed -b $out\.tmp1.bed -w 0 >$out\.tmp.result.bed`;
	###############################################
	open K,"$out\.tmp.result.bed" or die;
	while (<K>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		++$totpoint{$arr[6]};
		$totdepth+=$arr[6];
	};
	close K;
	foreach my $num (1,2,5,10,20,30)
	{
		my $point=0;
		foreach my $dep (sort {$b <=> $a} keys %totpoint)
		{
			last if ($dep<$num);
			$point+=$totpoint{$dep};
		};
		$hash->{$num}=$point/$totlen;
	};
	$hash->{ave}=$totdepth/$totlen;
	`rm $out\.tmp*`;
};
###################################################################################
###############################################################################################
sub get_UPD
{
	my ($infile,$outfile)=@_;
	my ($filter_dep,$filter_rat,$homo,%depth,%uniq,%chr_cnv)=(10,0.3,0.85);
	############################################
	my $chrcnv=$infile;
	$chrcnv=~s/3.3_variation_annotation\/tot_5_level.report.txt/5.2_EXON_deletion\/chr_cnv.txt/;
	open K,"$chrcnv" or die;
	<K>;
	while (<K>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		$chr_cnv{$arr[0]}=$arr[-1];
	};
	close K;
	#############################
	my $sexQC=$infile;
	$sexQC=~s/3.3_variation_annotation\/tot_5_level.report.txt/4.1_QC\/QC_report.txt/;
	$sexQC=`grep sex $sexQC`;chomp $sexQC;
	#############################
	open L,"$infile" or die;
	open M,">$outfile" or die;
	<L>;
	while (<L>)
	{
		chomp;
		next if (/^$/);
		my @arr=split /\t/,$_;
		if (exists $uniq{$arr[4]})
		{
			next;
		}else
		{
			$uniq{$arr[4]}=1;
		};
		my $chr=(split /\:/,$arr[4])[0];
		my @depth=split /[:=;\/]/,$arr[22];
		next if($depth[-2]<$filter_dep || $depth[-3]<$filter_rat);
		if ($depth[0]!~/Hemi/)
		{
			if ($depth[-3]>$homo)
			{
				$depth{$chr}{homo}+=1;
			}else
			{
				$depth{$chr}{hete}+=1;
			};
		}else
		{
			$depth{$chr}{hemi}+=1;
		};
	};
	close L;
	foreach my $key (sort keys %depth)
	{
		my $cnv='NA';
		if (exists $chr_cnv{$key}){$cnv=$chr_cnv{$key}};

		if (not exists $depth{$key}{hemi}) 
		{
			if (not exists $depth{$key}{homo}) {$depth{$key}{homo}=0};
			if (not exists $depth{$key}{hete}) {$depth{$key}{hete}=0};
			my $ratio=$depth{$key}{homo}/($depth{$key}{hete}+$depth{$key}{homo});
			$ratio=sprintf("%.4f",$ratio);
			print M "$key\t$depth{$key}{homo}\t$depth{$key}{hete}\t$ratio";
			if ($sexQC=~/YES/)
			{
				if ($cnv ne 'NA')
				{
					print M "\t$cnv\n";
				}elsif($ratio>0.8)
				{
					print M "\tUPD\n";
				}else
				{
					print M "\n";
				};
			}else
			{
				print M "\tsex_err\n";
			
			};
		}else
		{
			print M "$key\tHemi\t$depth{$key}{hemi}\t$cnv\n";
		}
	};
	close M;
};
