#!/usr/bin/perl -w
use strict;
use Cwd;
use Getopt::Long;
use Data::Dumper;

my $file=shift;
my $ms=shift;
my $out=shift;


if (!defined $file || !defined $ms || !defined $out)
{
	print "\n\tperl $0 <list> <MS_detail> <out> \n\n";
	exit;
};
##########################
my %list;

open L,"$file" or die;
while (<L>)
{
	chomp;
	next if(/^$/);
	my @arr=split /\t/,$_;
	$list{$arr[0]}{chinese}=$arr[1];
	$list{$arr[0]}{english}=$arr[2];
};
close L;

##########################
open L,"$ms" or die;
while (<L>)
{
	chomp;
	next if(/^$/);
	my @arr=split /\t/,$_;
	$list{$arr[0]}{chinese}=$arr[1];
	$list{$arr[0]}{english}=$arr[2];
};
close L;

######################################
open OUT1,">$out\.chinese" or die;
open OUT2,">$out\.english" or die;
for(my $aa=1;$aa<35;$aa++)
{
	for(my $bb=1;$bb<7;$bb++)
	{
		for(my $cc=1;$cc<7;$cc++)
		{
			my $true_a=$list{"P$aa"}{chinese};
			my $true_b=$list{"F$bb"}{chinese};
			my $true_c=$list{"O$cc"}{chinese};

			my $last_chinese=join ";",$list{"P$aa"}{chinese},$list{"F$bb"}{chinese},$list{"O$cc"}{chinese};
			$last_chinese=~s/;-//g;
			my $last_english=join ";",$list{"P$aa"}{english},$list{"F$bb"}{english},$list{"O$cc"}{english};
			$last_chinese=~s/;-//g;
			
			my $value;
			my $value_english;
#			print "P$type_a:$type_b:$type_c\t$_\t$true_b\t$true_c\t$last\n";

			if ($true_a=~/野生型/)
			{
				$value="24\t排除致病";
				$value_english="24\tPathogenic Excluded";
			}elsif ($true_a=~/不符合/)
			{
				if ($true_a=~/野生型/)
				{
					$value="24\t排除致病";
					$value_english="24\tPathogenic Excluded";
				}elsif($true_a=~/denovo/)
				{
					$value="24\t排除致病";
					$value_english="24\tPathogenic Excluded";
				}elsif($true_a=~/AR/)
				{
					$value="8\t不支持致病";
					$value_english="8\tPathogenic Not Supported";
				}else
				{
					print STDERR "$_\t$true_b\t$true_c\n";
					die;
				};
			}elsif($true_a=~/未覆盖/)
			{
				$value="24\t排除致病";
				$value_english="24\tPathogenic Excluded";
					if (($true_b eq '-') && ($true_c eq '-'))
					{
						$value="err\terr";
						$value_english="err\terr";
					};
			}else
			{
				if ($true_b=~/不符合/ || $true_c=~/不符合/)
				{
					$value="24\t排除致病";
					$value_english="24\tPathogenic Excluded";
				}elsif($true_b=~/考虑不完全外显/ || $true_c=~/考虑不完全外显/ || $true_a=~/考虑不完全外显/)
				{
					$value="4\t可能致病";
					$value_english="4\tLikely Pathogenic";
				}elsif ($true_b=~/补测/ || $true_c=~/补测/ || $true_a=~/补测/)
				{
					$value="4\t可能致病";
					$value_english="4\tLikely Pathogenic";
				}elsif($true_b=~/考虑X/ || $true_c=~/考虑X/ || $true_a=~/考虑X/)
				{
					$value="2\t支持致病";
					$value_english="2\tPathogenic Supported";
				}elsif($true_b=~/符合/ || $true_c=~/符合/ || $true_a=~/符合/)
				{
					$value="1\t支持致病";
					$value_english="1\tPathogenic Supported";
				}else
				{
					print STDERR "$true_a\t$true_b\t$true_c\n";
					die;
				};
			};


				if(($true_b=~/考虑X/ || $true_c=~/考虑X/ || $true_a=~/考虑X/) && ($true_a!~/X/))
				{
					$value="err\terr";
					$value_english="err\terr";
				}elsif(($true_a=~/考虑X/) && ($true_b=~/三者符合家系共分离遗传学原则/ || $true_c=~/三者符合家系共分离遗传学原则/))
				{
					$value="err\terr";
					$value_english="err\terr";
				};

				if(($true_b=~/考虑不完全外显/ || $true_c=~/考虑不完全外显/ || $true_a=~/考虑不完全外显/) && ($true_a!~/AD/))
				{
					$value="err\terr";
					$value_english="err\terr";
				}elsif(($true_a=~/考虑不完全外显/) && ($true_b=~/三者符合家系共分离遗传学原则/ || $true_c=~/三者符合家系共分离遗传学原则/))
				{
					$value="err\terr";
					$value_english="err\terr";
				};
				if (($true_a=~/野生型/) && ($true_b eq '-') && ($true_c eq '-'))
				{
					$value="err\terr";
					$value_english="err\terr";
				}elsif(($true_a=~/野生型/) && ($true_b!~/三者不符合家系共分离遗传学原则/) && ($true_b ne '-'))
				{
					$value="err\terr";
					$value_english="err\terr";
				};

				if(($aa>=19) && ($aa<=33) && ($bb==3))
				{
					$value="err\terr";
					$value_english="err\terr";
				};
				if(($true_a=~/AR/) && ($true_a=~/不符合/) && $aa!=9 && ($true_b eq '-'))
				{
					$value="err\terr";
					$value_english="err\terr";
				};
				if ($true_a=~/不符合/)
				{
					if ($true_b=~/不符合/ || ($bb==3))
					{
					}else
					{
						$value="err\terr";
						$value_english="err\terr";
					};
				};
				if ($aa==10 && ($bb==3))
				{
					$value="err\terr";
					$value_english="err\terr";
				};

			
			my $yiju=$list{"P$aa"}{chinese}.$list{"F$bb:O$cc"}{chinese};

			my $yiju_english=$list{"P$aa"}{english}.$list{"F$bb:O$cc"}{english};


			if($aa=~/14|15|16|17|18|34/)
			{
				$value="24\t排除致病";
				$value_english="24\tPathogenic Excluded";
			};

			print OUT1 "P$aa:F$bb:O$cc\t$value\t$yiju\n";
			print OUT2 "P$aa:F$bb:O$cc\t$value_english\t$yiju_english\n";
		};
	};
};
close OUT1;
close OUT2;