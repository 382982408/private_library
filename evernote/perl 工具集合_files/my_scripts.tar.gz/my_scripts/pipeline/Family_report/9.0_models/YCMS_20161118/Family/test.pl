#!/usr/bin/perl -w
use strict;
use Cwd;
use Getopt::Long;
use Data::Dumper;

my $file=shift;
my $ms=shift;

if (!$file || !$ms)
{
	print "\n\tperl $0 <list> <MS_detail> \n\n";
	die;
};
##########################
my %hash;
open L,"$ms" or die;
while (<L>)
{
	chomp;
	next if(/^$/);
	my @arr=split /\t/,$_;
	if ($_=~/P/)
	{
		$hash{$arr[0]}=$arr[1];
	}elsif($_=~/F/ && $_=~/O/)
	{
		my @tmp;
		for (my $i=2;$i<5 ;$i++)
		{
			if ($arr[$i] && $arr[$i]!~/^$/)
			{
				push @tmp,$arr[$i];
			};
		};
		$hash{"$arr[0]:$arr[1]"}=join "",@tmp;
	};
};
close L;

######################################



my @BB=("F1:父,母,先证者三者符合家系共分离遗传学原则","F2:父,母,先证者三者不符合家系共分离遗传学原则","F3:-","F4:父,母,先证者三者考虑X失活符合家系共分离遗传学原则","F5:父,母,先证者三者考虑不完全外显符合家系共分离遗传学原则","F6:父,母,先证者三者补测后可能符合家系共分离遗传学原则");
my @CC=("O1:其他成员符合家系共分离遗传学原则","O2:其他成员不符合家系共分离遗传学原则","O3:-","O4:其他成员考虑X失活符合家系共分离遗传学原则","O5:其他成员考虑不完全外显符合家系共分离遗传学原则","O6:其他成员补测后可能符合家系共分离遗传学原则");

open L,"$file" or die;

my $type_a=0;
while (<L>)
{
	chomp;
	next if(/^$/);
	++$type_a;
	foreach my $bb (@BB)
	{
		my ($type_b,$true_b)=split /\:/,$bb;
		foreach my $cc (@CC)
		{
			my ($type_c,$true_c)=split /\:/,$cc;

			my $last=join ";",$_,$true_b,$true_c;
			$last=~s/;-//g;
			my $value;
#			print "P$type_a:$type_b:$type_c\t$_\t$true_b\t$true_c\t$last\n";
			if ($_=~/不符合/)
			{
				if ($_=~/野生型/)
				{
					$value="24\t排除致病";
				}elsif($_=~/denovo/)
				{
					$value="24\t排除致病";
				}elsif($_=~/AR/)
				{
					$value="8\t不支持致病";
				}else
				{
					print STDERR "$_\t$true_b\t$true_c\n";
					die;
				};
			}elsif($_=~/未覆盖/)
			{
				$value="24\t排除致病";
					if (($true_b eq '-') && ($true_c eq '-'))
					{
						$value="err\terr";
					};
			}else
			{
				if ($true_b=~/不符合/ || $true_c=~/不符合/)
				{
					$value="24\t排除致病";
				}elsif($true_b=~/考虑不完全外显/ || $true_c=~/考虑不完全外显/ || $_=~/考虑不完全外显/)
				{
					$value="4\t可能致病";
				}elsif ($true_b=~/补测/ || $true_c=~/补测/ || $_=~/补测/)
				{
					$value="4\t可能致病";
				}elsif($true_b=~/考虑X/ || $true_c=~/考虑X/ || $_=~/考虑X/)
				{
					$value="2\t支持致病";
				}elsif($true_b=~/符合/ || $true_c=~/符合/ || $_=~/符合/)
				{
					$value="1\t支持致病";
				}else
				{
					print STDERR "$_\t$true_b\t$true_c\n";
					die;
				};
			};


				if(($true_b=~/考虑X/ || $true_c=~/考虑X/ || $_=~/考虑X/) && ($_!~/X/))
				{
					$value="err\terr";
				}elsif(($_=~/考虑X/) && ($true_b=~/三者符合家系共分离遗传学原则/))
				{
					$value="err\terr";
				};

				if(($true_b=~/考虑不完全外显/ || $true_c=~/考虑不完全外显/ || $_=~/考虑不完全外显/) && ($_!~/AD/))
				{
					$value="err\terr";
				}elsif(($_=~/考虑不完全外显/) && ($true_b=~/三者符合家系共分离遗传学原则/))
				{
					$value="err\terr";
				};
				if (($_=~/野生型/) && ($true_b eq '-') && ($true_c eq '-'))
				{
					$value="err\terr";
				}elsif(($_=~/野生型/) && ($true_b!~/三者不符合家系共分离遗传学原则/) && ($true_b ne '-'))
				{
					$value="err\terr";
				};

				if(($_=~/denovo/) && ($true_b eq '-'))
				{
					$value="err\terr";
				};
				if(($_=~/AR/) && ($_=~/不符合/) && $_!~/单杂合/&& ($true_b eq '-') && ($true_c eq '-'))
				{
					$value="err\terr";
				};
				if ($_=~/不符合/)
				{
					if ($true_b=~/不符合/ || ($true_b eq '-'))
					{
					}else
					{
						$value="err\terr";
					};
				};
				if ($_=~/,符合AR复合杂合/ && ($true_b eq '-') && ($true_c ne '-'))
				{
					$value="err\terr";
				};
				if (!$hash{"P$type_a"} || !$hash{"$type_b:$type_c"})
				{
					print STDERR "no_yiju:\tP$type_a:$type_b:$type_c\n";
#					die;
				};
			
			my $yiju;
				my $phy_f=$hash{"P$type_a"};
				my $phy_o=$hash{"$type_b:$type_c"};
				if ($type_a==9 || $type_a==11 || $type_a==27 || $type_a==34 || ($type_a>=14 && $type_a<=18 ))
				{
					$phy_o=~s/：符合/：不符合/g;
				};
			$yiju=$phy_f.$phy_o;


			if($type_a=~/14|15|16|17|18|34/)
			{
				$value="24\t排除致病";	
			};

			print STDOUT "P$type_a:$type_b:$type_c\t$value\t$yiju\n";
		};
	};
};
close L;
