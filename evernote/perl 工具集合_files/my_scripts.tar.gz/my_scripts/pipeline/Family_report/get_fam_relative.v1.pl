#!/usr/bin/perl -w
use strict;
use Cwd;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);
use lib "$Bin/9.0_models/";
use standard_family;
###########################################################################Start_Time
my (@yuanxu,$od);
GetOptions
(
	"list=s{,}"	=>	\@yuanxu,
	"od=s"	=>	\$od,
);
if (!@yuanxu || !$od)
{
	print "\n\tperl $0 -list <sample_number> -od <out_dir>\n\n";
	exit;
};

foreach my $xu (@yuanxu)
{
	my $OUT=&standard_family::get_fam_relative("/share/ofs1a/prod/warriors_assemble.txt",$xu,"$od/$xu\_handel.txt");
};

