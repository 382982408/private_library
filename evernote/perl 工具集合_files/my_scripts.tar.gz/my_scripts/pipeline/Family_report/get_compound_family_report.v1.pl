#!/usr/bin/perl -w
use strict;
use Cwd;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);
use lib "$Bin/9.0_models/";
use standard_family;
###########################################################################Start_Time
my $conf_file="/share/ofs1a/EXdev/WES_pipe_v1_1.1/db/Z_lzw_database/CONFIG_ALL.txt";
my %parameters;
&initialize($conf_file,\%parameters);

my $code1="gb2312";
my $code2="utf-8";
my $pl=basename($0);
my (@infile,@indir,$level,$out,$call,$panel_list,$cov,$bam,$genelist,$all);
GetOptions
(
	"i=s{,}"		=>\@infile,
	"id=s{,}"		=>\@indir,
	"level=s"		=>\$level,
	"call=s"		=>\$call,
	"panel=s"		=>\$panel_list,
	"o=s"			=>\$out,
	"cov=s"			=>\$cov,
	"bam=s"			=>\$bam,
	"genelist=s"		=>\$genelist,
	"all=s"			=>\$all,
);
&help if(!@indir || !$out);
sub help
{
	print <<"Usage_end";
	Usage:
		perl $pl
		-i		input_files
		-id		input_dirs
		-level		3|5
		-call		default:call_snp || 0:do_not_recall_depth
		-panel		panel_gene_list
		-o		output_file
		-cov		cov_Sinfo.txt ? || default:yes
		-bam		is bam available ??? || default:YES
		-genelist	gene_list_file
		-all		Whether the output all the mutations ?

eg:
perl $pl -id <child_dir> <father_dir> <mother_dir> -o <33135_NT01F_b765A765A765A_Trios_v2.xlsx>
perl $pl -i <child_result> <father_result> <mother_result> -id <child_dir> <father_dir> <mother_dir> -o <33135_NT01F_b765A765A765A_Trios_v2.xlsx>

Usage_end
	exit;
};
#########################my ($level,$input,$file,$bam,$rbam,$genecov,$rmgene_cov,$conf,$stat,$rmstat,$rmdupratio,$depthfile,$rmdepthfile)=@_;
if (!defined $call){$call=1};
if (!defined $level){$level=3};
if (!defined $cov){$cov="yes"};
$all ||="no";
$bam ||="yes";

my $ids=join " ",@indir;
print "perl $0 -id $ids -level $level -o $out \n";

my(@bam,@rbam,@genecov,@rmgenecov,@rmdepthfile,@sampname,@bestNM,%getdata,@chr_cnv_res,@exon_cnv_res);
print "get files and dirs...\n";
if (@infile || @indir)
{
	&input($level,\@indir,\@infile,\@bam,\@rbam,\@genecov,\@rmgenecov,\@rmdepthfile,\@sampname,\@bestNM,\@chr_cnv_res,\@exon_cnv_res);
}else
{
	print STDERR "\n\tplease check your inputs !\n";
	exit;
};

##########################################################
my $all_raw="/share/ofs1a/prod/warriors_assemble.txt";

print "get family relationships...\n";
my $sinfo="$out\.Sinfo.txt";

if ($cov=~/yes/ || !-f $sinfo)
{
	&standard_family::get_fam_relative($all_raw,$sampname[0],$sinfo);
};
##########################################################
print "read family relationships...\n";
my %relation;
&standard_family::read_sinfo($sinfo,\%relation);
########################################################
my %gene_list;
if ($genelist && (-f $genelist))
{
		$gene_list{OK}=1;
		&get_list_gene($genelist,\%gene_list);
};
#######################################################
my %gene_filter;
my $filter_gene_file="$Bin/report_filter/filter_gene_list.txt";
&get_list_gene($filter_gene_file,\%gene_filter);

##########################################################
my (@sons,@father,@mother,@other);
for (my $i=0;$i<@sampname ;$i++)
{
	my $tmp=$relation{$sampname[$i]}{'rel'};
	if (!$tmp)
	{
		print STDERR "please check you Sinfo_config_file !\t$sampname[$i]\n\n";
		print Dumper \%relation;
		die;
	};
	if ($tmp=~/son|daughter/i)
	{
		push @sons,$sampname[$i];
	}elsif($tmp=~/father/i)
	{
		push @father,$sampname[$i];
	}elsif($tmp=~/mother/i)
	{
		push @mother,$sampname[$i];
	}else
	{
		push @other,$sampname[$i];
	};
};
my $famflag;
my $fam_std="YES";
if ((@sons==1) && (@father==1) && (@mother==1) && (!@other || (@other==0)))
{
	$famflag=1;
	print "standard_family of one child...\n";
}elsif((@sons>=1) && (@father==1) && (@mother==1) && (!@other || (@other==0)))
{
	$famflag=2;
	print "standard_family or many children...\n";
}elsif((@sons==1) && (@father==1) && (@mother==1) && (@other>=1))
{
	$famflag=3;
	print "standard_family of one child! + others relatives...\n";
}elsif((@sons>=1) && (@father==1) && (@mother==1) && (@other>=1))
{
	$famflag=4;
	print "standard_family of many children! + others relatives...\n";
}else
{
	$famflag=5;
	$fam_std="NO";
	print "unstandard_family... \n";
};
########################my ($geneanno,$genepos,$genestrand,$genecov,$omim,$phenotype,$for_report,$translation,$first,$second,$num2type)=@_;
my $genepos="$parameters{T3}/C_mut_anno_database/gene_id_chrpos.txt";
my $genestrand="$parameters{T3}/C_mut_anno_database/gene_strand.txt";
my $for_report="$parameters{T3}/Z_lzw_database/for_report_convert.txt";

my $omomphen="$indir[0]/3.3_variation_annotation/OMIM_database/omim.txt";

my (%geneinf,%omiminf,%translation);

my $MS="$Bin/9.0_models/family_MS";
print "input the report configs...\n";
&standard_family::config(\@sampname,\@genecov,$genepos,$genestrand,\%geneinf,$omomphen,\%omiminf,$for_report,$MS,\%translation);

my ($len,%depth,%rmdepth,%com,%singel,%singleresult,%genemut)=(50);
my $open=0;
`touch $out`;
$out=&standard_family::path($out);


########################
my $return;
print "get anno information of all variants...\n";
$return.=&standard_family::get_cominfo(\@sampname,\@infile,\%geneinf,\%omiminf,\%translation,\%com,\%singleresult,$open,\%genemut,\%depth,\%rmdepth);

########################
my (%SMN1_com);
if ($bam=~/yes/i)
{
	print "get SMN1 mut info...\n";
	&standard_family::get_SMN1(\@sampname,\@bam,\@rbam,\%omiminf,\%geneinf,\%relation,\%SMN1_com,$open);
	print "call depth...\n";
	$return.=&standard_family::call_depth("$parameters{T2}/bedtools",$call,$len,$out,\@infile,\@bam,\@rbam,\%depth,\%rmdepth);
};

if ($return=~/error/)
{
	die "$return\n\n";
};

########################
print "test the family relationship...\n";
my @all_sam=(@sons,@father,@mother,@other);
if ($level==5)
{
	&get_real_relation(\@all_sam,\%rmdepth,"$out\.relation");
};

##################
##################
my ($number)=split /\D+/,$all_sam[0];
my $prog=`grep $number $all_raw|grep NT|tail -1|cut -f 3`;chomp $prog;
my $oldprog=$prog;
my %panel_gene;

if((defined $panel_list) && ($panel_list eq "NT01"))
{
}elsif(defined $panel_list)
{
	$prog=$panel_list;
	my $gene_file="$out\.gene.list";
        `wget http://192.168.1.169:8090/omim/panel/find2.do?panelName=$prog -O $gene_file`;
        if ($gene_file && -f $gene_file)
        {
                $panel_gene{OK}=1;
                open L,"$gene_file" or die;
                while (<L>)
                {
                        chomp;
                        next if (/^$/);
                        my @arr=split /\<br\>/,$_;
                        foreach my $gene (@arr)
                        {
                                $panel_gene{$gene}=1;
                        };
                };
                close L;
        }else
        {
                print STDERR "\nError:\tno_gene_list !!!\t";
        };
}elsif ($prog=~/e$|eF$/)
{
	$prog=~s/F//g;
	my $gene_file="$out\.gene.list";
	`wget http://192.168.1.169:8090/omim/panel/find2.do?panelName=$prog -O $gene_file`;
	if ($gene_file && -f $gene_file)
	{
		$panel_gene{OK}=1;
		open L,"$gene_file" or die;
		while (<L>)
		{
			chomp;
			next if (/^$/);
			my @arr=split /\<br\>/,$_;
			foreach my $gene (@arr)
			{
				$panel_gene{$gene}=1;
			};
		};
		close L;
	}else
	{
		print STDERR "\nError:\tno_gene_list !!!\t";
	};
}else
{
	##########不做筛选；
};
##print Dumper \%panel_gene;die;
#########################

foreach my $muttag (sort keys %com)
{
	foreach my $number (@all_sam)
	{
		if($muttag=~/gain|loss/)
		{
			if ($oldprog!~/F$/)
			{
				delete $com{$muttag};
			}elsif ($muttag=~/gain/)
			{
#				delete $com{$muttag};		############重复暂且不报。
			};
		}else
		{
			if ($bam=~/YES/i && (not exists $rmdepth{$muttag}{$number}))
			{
				####如果任何一个样本没有深度信息，说明rmdup.vcf文件中没有此突变，不知道此样本此位点是未覆盖还是野生型还是其他情况，无法判定，不做输出
				delete $com{$muttag};
			}elsif(not exists $rmdepth{$muttag}{$number})
			{
				if (($number eq $all_sam[0]) && $all=~/no/)
				{
						delete $com{$muttag};
				}else
				{
						$rmdepth{$muttag}{$number}='0=0/1000000';
				};
			};
		};
	};
};

##################
##################
my (@comp_hete,@fuhezahe);
if ($famflag<=4)
{
	print "get compound heterozygous...\n";
	for (my $i=0;$i<1;$i++)	##my $i=0;$i<@sons;$i++
	{
			my (@famsample,%tmp_hete,%tmp_fuhezahe);
			push @famsample,$sons[$i],@father,@mother;
			&standard_family::get_comp_hete(\@famsample,\%com,\%rmdepth,\%relation,\%tmp_hete,\%tmp_fuhezahe);
			push @comp_hete,\%tmp_hete;
			push @fuhezahe,\%tmp_fuhezahe;
	};
}else
{
	my (@famsample,%tmp_hete,%tmp_fuhezahe);
	push @famsample,$sons[0],$sons[0],$sons[0];
	&standard_family::get_comp_hete(\@famsample,\%com,\%rmdepth,\%relation,\%tmp_hete,\%tmp_fuhezahe);
	push @comp_hete,\%tmp_hete;
	push @fuhezahe,\%tmp_fuhezahe;
};
##########################################
##print Dumper \%family;die;
print "write to txt...\n";
open OUT1,">$out\.Mutation" or die;

if($level==5)
{
	open ALL,">$out\.Mutation_allgene" or die;
};
open OUT2,">$out\.Quality" or die;

my (@head,@cnvhead,@quahead);
push @head,"突变编号";
push @quahead,"基因";
foreach my $number ((@sons,@father,@mother,@other))############### == @sampname
{
	my $famname1="($relation{$number}{'rea'},$number)";
	$famname1=~s/正常/\(表型正常\)/;
	push @head,"突变率$famname1","突变深度$famname1","总深度$famname1","杂合/纯合$famname1","突变可靠性$famname1";
	push @quahead,"覆盖度$famname1","平均深度$famname1","基因大于等于10x覆盖度$famname1","基因突变数$famname1";
	push @cnvhead,"CNV类型:拷贝数$famname1";
};
push @head,"遗传学评分","结论","依据","生物学+遗传学总分","基因","基因方向","染色体名称","起始位置","终止位置","核酸改变","氨基酸改变","突变类型","突变级别";
push @head,"rs编号","次要基因型频率",'千人基因组(中国)','千人基因组(中国南方)','千人基因组(中国北方)',"德易东方MAF频率";
push @head,"EXAC东亚频率","EXAC南亚频率","EXAC最大频率","ESP数据库频率","PubMed文献号","HGMD数据库注释";
push @head,"Clinvar数据库注释","OMIM数据库注释","SWISS数据库注释","Provean危害性预测","SIFT危害性预测","Polyphen2_HDIV危害性预测","Polyphen2_HVAR危害性预测","mutationtaster危害性预测","与疾病相关性","相关性说明","疾病表型名称";
push @head,"基因所关联疾病表型","遗传方式","基因ID","基因Location";
push @head,"mRNA变体名称(NM)","是否重复区域","生物学意义编号","疑似阳性/非阳性","ACMG临床支持依据","ACMG临床不支持依据","是否需要临床判断","ACMG临床支持结论","ACMG临床不支持结论";
push @head,"基因在tiger数据库中高表达组织","基因在tiger数据库中有表达组织","基因在GTEx数据库中高表达组织","基因在GTEx数据库中有表达组织","是否位于保守性区域","是否位于致病热点区域";
push @head,"德易东方患者MAF频率","M-CAP危害性预测","REVEL危害性预测","预测危害性","结构危害性","剪切位点危害性预测","是否共分离","是否denovo","是否复合杂合","打分所用遗传方式","染色体碱基变化","外显子验证信息";


push @quahead,"是否目标基因";

print OUT1 (join "\t",@head)."\n";
print ALL (join "\t",@head)."\n"if($level==5);
print OUT2 (join "\t",@quahead)."\n";
##print Dumper \%acmg11;die;

my (%resultdata,%acmgfam,%gene_mut,%add_new);
my %gene_choice;
my %mut_genetic;


foreach my $muttag (sort keys %com)
{
#	next if ($muttag !~/chrX_1_155270560_D_loss1_C/);
#	next if (not exists $depth{$muttag} || not exists $rmdepth{$muttag});
	next if (not exists $rmdepth{$muttag});

	foreach my $omimid (sort keys %{$com{$muttag}})
	{
		my @arr=@{$com{$muttag}{$omimid}};
		my (@results);
		push @results,$arr[0];

		my $reporttag=0;
		my %mut_digital;
		my $k=0;
		foreach my $number (@all_sam)
			{
				my $SEX_digital=$relation{$number}{off};
				if ($SEX_digital eq 'FM')
				{
					$SEX_digital=1;
					if ($results[0]=~/chrY/ && $results[0]=~/gain|loss/)
					{
						$rmdepth{$muttag}{$number}="norm";
					};
				}else
				{
					$SEX_digital=2;
					if ($results[0]=~/chrX|chrY/ && (exists $rmdepth{$muttag}{$number}) && $rmdepth{$muttag}{$number}=~/loss1|gain1/)
					{
						$rmdepth{$muttag}{$number}="norm";
					}elsif($results[0]=~/chrX|chrY/ && (exists $rmdepth{$muttag}{$number}) && $rmdepth{$muttag}{$number}=~/loss2/)
					{
						$rmdepth{$muttag}{$number}="loss";
					}elsif($results[0]=~/chrX|chrY/ && (exists $rmdepth{$muttag}{$number}) && $rmdepth{$muttag}{$number}=~/gain2/)
					{
						$rmdepth{$muttag}{$number}="gain";
					};
				};
				my $HOMO_digital;
				my $HOMO_phe="NA";
				$relation{$number}{'rea'}=~s/正常|患病|轻微表型//g;

					if ($results[0]=~/gain|loss/)
					{
						if ($k==0)
						{
							if (exists $rmdepth{$muttag}{$number})
							{
								if ($rmdepth{$muttag}{$number}=~/gain1|gain2|loss1/)
								{
									$HOMO_digital='2';
									$HOMO_phe="杂合";
								}elsif($rmdepth{$muttag}{$number}=~/loss2/)
								{
									$HOMO_digital='1';
									$HOMO_phe='纯合';
								}elsif($rmdepth{$muttag}{$number}=~/gain|loss/)
								{
									$HOMO_digital='5';
									$HOMO_phe="半合子";
								};
							}else
							{
									$rmdepth{$muttag}{$number}="norm";
									$HOMO_digital='4';
									$HOMO_phe='野生型';
									goto CASE_last;
							};
						}else
						{
							if ($rmdepth{$muttag}{$all_sam[0]}=~/loss/)
							{
								if (exists $rmdepth{$muttag}{$number} && $rmdepth{$muttag}{$number}=~/loss1/)
								{
									$HOMO_digital='2';
									$HOMO_phe="杂合";
								}elsif(exists $rmdepth{$muttag}{$number} && $rmdepth{$muttag}{$number}=~/loss2/)
								{
									$HOMO_digital='1';
									$HOMO_phe='纯合';
								}elsif(exists $rmdepth{$muttag}{$number} && $rmdepth{$muttag}{$number}=~/loss/)
								{
									$HOMO_digital='5';
									$HOMO_phe="半合子";
								}else
								{
									$rmdepth{$muttag}{$number}="norm";
									$HOMO_digital='4';
									$HOMO_phe='野生型';
								};
							}elsif($rmdepth{$muttag}{$all_sam[0]}=~/gain/)
							{
								if (exists $rmdepth{$muttag}{$number} && $rmdepth{$muttag}{$number}=~/gain1|gain2/)
								{
									$HOMO_digital='2';
									$HOMO_phe="杂合";
								}elsif(exists $rmdepth{$muttag}{$number} && $rmdepth{$muttag}{$number}=~/gain/)
								{
									$HOMO_digital='5';
									$HOMO_phe="半合子";
								}else
								{
									$rmdepth{$muttag}{$number}="norm";
									$HOMO_digital='4';
									$HOMO_phe='野生型';
								};
							}else
							{
								print STDERR "\tproband exon deletion error ! \n\n";
								die;
							};
						};
						push @results,"NA","NA","NA",$HOMO_phe,"相对可靠";

					}else
					{
						my @tmpdepth;
						if (not exists $rmdepth{$muttag}{$number})
						{
							print "not rmdupdepth $muttag\n\n";
							die;
						}elsif($rmdepth{$muttag}{$number}=~/NA/)
						{
							@tmpdepth=(0,0,0);
						}else
						{
							@tmpdepth=split /[=\/]/,$rmdepth{$muttag}{$number};
						};

						if (($SEX_digital==1) && ($arr[5]=~/chrY/))
						{
							++$reporttag;
							$HOMO_digital='4';
							$HOMO_phe='野生型';
						}elsif ($tmpdepth[2]==0)
						{
							++$reporttag;
							$HOMO_digital='3';
							$HOMO_phe='未覆盖';
							if ($k==0)
							{
								$arr[40]='NA';		#######疑似阳性那一列必须输出先证者的判定结果，如果先证者未检测到突变则，空着
								if ($all=~/no/i)
								{
									goto CASE_last;		#######说明先证者未覆盖或者野生型;
								};
							};
						}elsif ($tmpdepth[0]<0.1 || $tmpdepth[1]<2)
						{
							++$reporttag;
							$HOMO_digital='4';
							$HOMO_phe='野生型';
							if ($k==0)
							{
								$arr[40]='NA';		#######疑似阳性那一列必须输出先证者的判定结果，如果先证者未检测到突变则，空着
								if ($all=~/no/i)
								{
									goto CASE_last;		#######说明先证者未覆盖或者野生型
								};
							};
						}elsif($tmpdepth[0]>=0.85)
						{
							$HOMO_digital='1';
							$HOMO_phe='纯合';
							if (($SEX_digital==2) && ($arr[5]=~/chr[XY]/))
							{
								$HOMO_digital='5';
								$HOMO_phe="半合子";
							};
							$gene_mut{$arr[3]}{$number}{$arr[0]}=1;
						}elsif($tmpdepth[0]<0.85)
						{
							$HOMO_digital='2';
							$HOMO_phe="杂合";
							if (($SEX_digital==2) && ($arr[5]=~/chr[XY]/))
							{
								$HOMO_digital='4';
								$HOMO_phe='野生型';
								if ($k==0)
								{
									if ($all=~/no/i)
									{
										goto CASE_last;		#######说明先证者未覆盖或者野生型
									};
								};
							}else
							{
								$gene_mut{$arr[3]}{$number}{$arr[0]}=1;
							};
						};

						if ($tmpdepth[2]==1000000)
						{
								push @results,"NA","NA","NA",$HOMO_phe;
						}else
						{
								push @results,@tmpdepth,$HOMO_phe;
						};
						##############################	by luozw20161103
						if($HOMO_phe=~/野生型|正常|未覆盖/)
						{
								push @results,"NA";
						}elsif ($tmpdepth[0]>=0.1 && $tmpdepth[1]>=6)
						{
							push @results,"相对可靠";
						}else
						{
							push @results,"不可靠";
						};
						###############################
					};

					$mut_digital{$number}{homo}=$HOMO_digital;					########################为denovo检测做准备
					$mut_digital{$number}{sex}=$SEX_digital;
					$mut_digital{$number}{homo_phe}=$HOMO_phe;
					$mut_digital{$number}{dis}=$relation{$number}{path};
				++$k;
			};

		if ($reporttag>=@sampname)
		{
			print STDERR "filterer_mutation:\t$muttag\t$reporttag\n";
			next;
		};
		if ($mut_digital{$sons[0]}{dis}!=4)
		{
			if ($mut_digital{$sons[0]}{dis}==2)
			{
				$mut_digital{$sons[0]}{dis}=4;
			}else
			{
				print STDERR "\n\t\tAttention: unnormal phenotype of the proband !\n";
				die;
			};
		};
		###################################################################
		my $true_genetic;
		my @ADS;
		my $OMIM_num;
		if ($results[0]=~/gain|loss/)
		{
			&standard_family::get_revise_genetic($arr[0],\$arr[39]);
			$arr[39]=~s/X-linked/XL/g;
			$true_genetic=$arr[39];
			$true_genetic=~s/\(HPO\)//g;
			if ((($true_genetic eq 'NA') || ($true_genetic=~/^$/)) && ($arr[0]=~/chrX/))
			{
				push @ADS,"XD","XR";
			}elsif((($true_genetic eq 'NA') || ($true_genetic=~/^$/)) && ($arr[0]=~/chrY/))
			{
				push @ADS,"Y";
			}elsif(($true_genetic eq 'NA') || ($true_genetic=~/^$/))
			{
				push @ADS,"AD","AR";
			}else
			{
				@ADS=split /\,/,$true_genetic;
			};
			$OMIM_num=$arr[38];
		}else
		{
			&standard_family::get_revise_genetic($arr[5],\$arr[34]);
			$arr[34]=~s/X-linked/XL/g;
			$true_genetic=$arr[34];
			$true_genetic=~s/\(HPO\)//g;
			if ((($true_genetic eq 'NA') || ($true_genetic=~/^$/)) && ($arr[5]=~/chrX/))
			{
				push @ADS,"XD","XR";
			}elsif((($true_genetic eq 'NA') || ($true_genetic=~/^$/)) && ($arr[5]=~/chrY/))
			{
				push @ADS,"Y";
			}elsif(($true_genetic eq 'NA') || ($true_genetic=~/^$/))
			{
				push @ADS,"AD","AR";
			}else
			{
				@ADS=split /\,/,$true_genetic;
			};
			$OMIM_num=$arr[33];
		};

		###########################################################

		foreach my $ad (@ADS)
		{
			if ($ad=~/AD/)
			{
				push @{$mut_digital{00000}{ad}},1;
			}elsif($ad=~/AR/)
			{
				push @{$mut_digital{00000}{ad}},2;
			}elsif($ad=~/XD|XL/)
			{
				push @{$mut_digital{00000}{ad}},3;
			}elsif($ad=~/XR/)
			{
				push @{$mut_digital{00000}{ad}},4;
			}elsif($ad=~/Y|Y-linked/)
			{
				push @{$mut_digital{00000}{ad}},5;
			}else
			{
				print STDERR "Err:\tinherit\t$muttag\n";die;
			};
		};
###		print Dumper \%mut_digital;
		###########################################################
		my ($dep_dig,$denovo_dig,$heter_dig)=(-1,-1,-1);

##		my $genetictag22=&standard_family::get_genetic_conclusion($arr[4],$ad,$uniq,$denovo,$fuhezahe);
		my ($value,$jielun,$yiju,$totscore)=("NA","NA","NA","NA");
		my $biolevel;
		if ($results[0]!~/gain|loss/)
		{
		        $biolevel=$arr[9];
		}else
		{
		        $biolevel=$arr[14];
		};

		if($true_genetic=~/chr\_/)
		{
			push @results,"1","支持致病","染色体整倍体异常","1";
			$mut_genetic{$muttag}{$omimid}="1";
			$true_genetic=~s/chr\_//;
			$arr[39]=$true_genetic;
		}elsif ($OMIM_num eq 'NA')################无OMIM疾病的没有遗传打分
		{
			my $uniq="NA";
			my $denovo="NA";
			my $fuhezahe="NA";
			my @for_depend;
			if ($famflag<=4)
			{
				foreach my $AD (@{$mut_digital{00000}{ad}})
				{
					my (@famsample);
					push @famsample,$sons[0],@father,@mother;
					my $Muttype;
					foreach my $samnumber(@famsample)
					{
						$Muttype.=$mut_digital{$samnumber}{homo};
					};
					$Muttype.="\-$mut_digital{$sons[0]}{sex}\-$AD";
					if (exists $translation{$Muttype})
					{
						push @for_depend,"denovo突变";
						$denovo_dig=1;
					};
					################################################以下是复合杂合判定
					next if ($AD != 2);

					my $xzztag="UF".$AD.$mut_digital{$sons[0]}{homo};
					if ((exists $comp_hete[0]->{$muttag}{$omimid}) && ($comp_hete[0]->{$muttag}{$omimid}=~/(\(\d\+\d\))/))
					{
						push @for_depend,"可能构成复合杂合$1";
					}elsif((exists $comp_hete[0]->{$muttag}{$omimid}) && ($comp_hete[0]->{$muttag}{$omimid}=~/n_1/) && ($xzztag eq 'UF22'))
					{
						$uniq="YES";
					};
				};
			};

			if (@for_depend)
			{
				my %uniq;
				@for_depend=grep ++$uniq{$_}<2,@for_depend;
				$yiju=join ";", @for_depend;
			};
			###################
			my $AR_hete="NA";
			if($mut_digital{$all_sam[0]}{homo}=~/2/ && ($uniq eq 'NA'))
			{
				$AR_hete="AR_poly"
			};
			($dep_dig,$denovo_dig,$heter_dig)=&standard_family::get_separation("NA",$yiju,$fam_std,$AR_hete);
			#############################################;
			push @results,$value,$jielun,$yiju,$totscore;
			
			$mut_genetic{$muttag}{$omimid}=$value;
		}else
		{
			if (!$mut_digital{00000}{ad})
			{
				print STDERR "Err:\tinherit\t$muttag\n";
				die;
			};
			my %for_gen_score;
					for (my $i=0;$i<@{$mut_digital{00000}{ad}};$i++)
					{
						my $uniq="NA";
						my $denovo="NA";
						my $fuhezahe="NA";
						my $AD=${$mut_digital{00000}{ad}}[$i];
						my $ADori=$ADS[$i];
						my $homo=$mut_digital{$all_sam[0]}{homo};

						my($P,$F,$O)=("Perr","F3","O3");
						my (%single_person_depend);
						foreach my $number (@all_sam)
						{
							my $tmpresult="F".$AD.$mut_digital{$number}{sex}.$mut_digital{$number}{homo}.$mut_digital{$number}{dis};
							if (not exists $translation{$tmpresult})
							{
								print STDERR "Error\t$number\t$muttag\t$tmpresult\n";
								die;
							};
							$single_person_depend{$number}=$translation{$tmpresult};
						};
						##############################################################################
						my (@famsample);
						push @famsample,$sons[0],@father,@mother;
						my $Muttype;
						foreach my $samnumber(@famsample)
						{
							$Muttype.=$mut_digital{$samnumber}{homo};
						};
						$Muttype.="\-$mut_digital{$sons[0]}{sex}\-$AD";
						if (exists $translation{$Muttype})
						{
							if ($translation{$Muttype}=~/p_3/)
							{
								$denovo="YESHETE";
							}elsif($translation{$Muttype}=~/p/)
							{
								$denovo="YES";
							};
						};
						##############################################################################
						if($AD == 2)
						{
							my $xzztag="UF".$AD.$mut_digital{$sons[0]}{homo};
							if ((exists $comp_hete[0]->{$muttag}{$omimid}) && ($comp_hete[0]->{$muttag}{$omimid}=~/(\d\+\d)/))
							{
								$fuhezahe=$1;
							}elsif((exists $comp_hete[0]->{$muttag}{$omimid}) && ($comp_hete[0]->{$muttag}{$omimid}=~/n_1/) && ($xzztag eq 'UF22'))
							{
								$uniq="YES";
							};
						};
						$P=&standard_family::get_genetic_conclusion($homo,$ADori,$uniq,$denovo,$fuhezahe);
						if ($P=~/err/i)
						{
							print STDERR "$muttag\t$homo\t$ADori\t$uniq\t$denovo\t$fuhezahe\n";
							die;
						};
						########################################
						my ($three_result);
						my @real_other=@other;
							if ($famflag<=4)
							{
								for (my $j=0;$j<1;$j++)
								{
										my (@tmpcom1,@tmpcom2,@famsample);
										push @famsample,$sons[$j],@father,@mother;
										foreach my $samnumber(@famsample)
										{
											$three_result.="$single_person_depend{$samnumber};";
										};
										if (exists $translation{$Muttype})			###############################denovo判定结果
										{
											$three_result.="$translation{$Muttype};";
										};
										##############################################################################
										if ($AD == 2 && (exists $comp_hete[$j]->{$muttag}{$omimid}))#########################复合杂合判定结果
										{
											$three_result.="$comp_hete[$j]->{$muttag}{$omimid};";
										};
										#####################################
										my $result_tag;
										($result_tag,$F)=split /\|/,&standard_family::get_fam_conclusion($three_result,\%translation,$muttag);
										########################################
								};
							}else
							{
								push @real_other,@sons[1..$#sons],@father,@mother;
							};
						########################################
							if (@real_other >0)
							{
								my $other_result="##";
								foreach my $tmp_number(@sons[0..$#sons],@real_other)
								{
									$other_result.=$single_person_depend{$tmp_number};
								};
								my $other_tag;
								($other_tag,$O)=split /\|/,&standard_family::get_fam_conclusion($other_result,\%translation,$muttag);
								$O=~s/F/O/g;
#print "$other_result\n$other_tag\n$O\n";
#die;
							};
						########################################

						my ($tmp_value,$tmp_con,$tmp_yiju,$tmp_totscore)=("NA","NA","NA","NA");
						if (exists $translation{"$P:$F:$O"})
						{
							($tmp_value,$tmp_con,$tmp_yiju)=split /\|/,$translation{"$P:$F:$O"};
						}else
						{
							print STDERR "depend error ! \t$P:$F:$O\t$muttag\n\t\tthree_tag:$three_result\n";
							die;
						};

							if ($fuhezahe ne 'NA')
							{
								if ($fuhezahe eq '1+1')
								{
									$tmp_totscore=1;
								}elsif($fuhezahe eq '1+2')
								{
									$tmp_totscore=2;
								}elsif($fuhezahe eq '1+3')
								{
									$tmp_totscore=4;
								}elsif($fuhezahe eq '2+2')
								{
									$tmp_totscore=4;
								}elsif($fuhezahe eq '2+3')
								{
									$tmp_totscore=6;
								}elsif($fuhezahe eq '3+3')
								{
									$tmp_totscore=18;
								}else
								{
									print STDERR "please check the score of comphete !\n";
									die;
								};
								$tmp_yiju.="($fuhezahe)";
							}else
							{
								if ($biolevel eq '1')
								{
									$tmp_totscore=$tmp_value*1;
								}elsif($biolevel eq '2')
								{
									$tmp_totscore=$tmp_value*3;
								}elsif($biolevel eq '3')
								{
									$tmp_totscore=$tmp_value*6;
								}elsif($biolevel eq '4')
								{
									$tmp_totscore=$tmp_value*10;
								}elsif($biolevel eq '5')
								{
									$tmp_totscore=$tmp_value*20;
								}else
								{
									print STDERR "please check the bio-level of this mutation ! \t $muttag \n";
									die;
								};
							};
							push @{$for_gen_score{$tmp_totscore}},"$tmp_value\t$tmp_con\t$tmp_yiju\t$tmp_totscore\t$ADori\t$uniq\n";
					};
				############################################################
				my $uniq;
				foreach my $AA (sort {$a <=> $b} keys %for_gen_score)
				{
					($value,$jielun,$yiju,$totscore,$true_genetic,$uniq)=split /\t/,@{$for_gen_score{$AA}}[0];	###############遗传方式只输出一个，
					last;
				};


				if ($results[0]!~/gain|loss/)
				{
						if ($arr[34]=~/NA/)
						{
							my @tmp_jielun=split /；/,$yiju;
							$tmp_jielun[0]=~s/，符合/，本疾病遗传方式尚未报道，不排除其符合/;
							$tmp_jielun[0]=~s/，不符合/，本疾病遗传方式尚未报道，不排除其不符合/;
							$yiju=join "；",@tmp_jielun;
						}elsif($arr[34]=~/XL/ && $true_genetic=~/XD/)
						{
							$true_genetic="XL";
							$yiju=~s/X-linked|XD/XL/g;
						}elsif($arr[34]=~/ADIP/ && $value==4 && $yiju=~/考虑不完全外显/)
						{
							$value=1;
							$jielun="支持致病";
							$yiju=~s/AD/不完全外显/g;
							$true_genetic="ADIP";
						};
				}else
				{
						if ($arr[39]=~/NA/)
						{
							my @tmp_jielun=split /；/,$yiju;
							$tmp_jielun[0]=~s/，符合/，本疾病遗传方式尚未报道，不排除其符合/;
							$tmp_jielun[0]=~s/，不符合/，本疾病遗传方式尚未报道，不排除其不符合/;
							$yiju=join "；",@tmp_jielun;
						}elsif($arr[39]=~/XL/ && $true_genetic=~/XD/)
						{
							$true_genetic="XL";
							$yiju=~s/X-linked|XD/XL/g;
						}elsif($arr[39]=~/ADIP/ && $value==4 && $yiju=~/考虑不完全外显/)
						{
							$value=1;
							$jielun="支持致病";
							$yiju=~s/AD/不完全外显/g;
							$true_genetic="ADIP";
						};
				}

				my $only_yiju=$yiju;
				if ($only_yiju=~/(.*)\(\d+\+\d+\)/)
				{
					$only_yiju=$1;
				};
				push @results,$value,$jielun,$yiju,$totscore;

				$mut_genetic{$muttag}{$omimid}=$value;
				##########################################################
					my $AR_hete="NA";
					if($true_genetic=~/AR/ && $results[4]=~/杂合|单倍/ && ($uniq!~/YES/))
					{
						$AR_hete="AR_poly";
					};
				($dep_dig,$denovo_dig,$heter_dig)=&standard_family::get_separation($value,$yiju,$fam_std,$AR_hete);
				if ($results[0]!~/gain|loss/)
				{
					#############################################################
					###########################################################################################
					if ($value eq 1 && $yiju=~/denovo/){push @{$acmgfam{$muttag}{$omimid}},"PS2Y(denovo变异,家系共分离)"};
					if ($value eq 1 && $yiju=~/\d+\+\d+/ && ($arr[20]=~/OMIM|HGMD|SWISS/i || $arr[22]=~/Pathogenic/i))
					{
						for (my $i=0;$i<@fuhezahe ;$i++)		#########@fuhezahe
						{
							next if (not exists $fuhezahe[$i]->{"$muttag\;$omimid"});
							my @allparner=split /\=/,$fuhezahe[$i]->{"$muttag\;$omimid"};
							foreach (@allparner)
							{
								next if ($_!~/\;/);
								my ($tmp1,$tmp2)=split /\;/,$_;
								push @{$acmgfam{$tmp1}{$tmp2}},"PM3(复合杂合中的另一个变异致病,家系共分离)";
							};
						};
					};			################%fuhezahe
					if ($value eq 1){push @{$acmgfam{$muttag}{$omimid}},"PP1Y(家系共分离)"};
					if ($value eq 1 && ($arr[22]!~/benign/i))
					{
						push @{$acmgfam{$muttag}{$omimid}},"PP4Y(Clinvar无benign,家系共分离)"
					};
					if (($value eq 15) || ($value eq 30)){push @{$acmgfam{$muttag}{$omimid}},"BS4(不共分离)"};
				};
				#######################################
		};


	if ($totscore=~/\d+/ && $totscore<=8 && $results[0]!~/gain|loss/)
	{
			$arr[40]="疑似阳性";
	}elsif($results[0]!~/gain|loss/)
	{
			$arr[40]="非阳性";
	}elsif ($totscore=~/\d+/ && $totscore<=8 && $results[0]=~/gain|loss/)
	{
		$arr[45]="疑似阳性";
	}elsif($results[0]=~/gain|loss/)
	{
		$arr[45]="非阳性";
	}else
	{
		print STDERR "unknown_mut_type:$muttag\n\n";
		die;
	};


		$true_genetic=~s/X-linked/XL/g;
		if ($results[0]!~/gain|loss/)
		{
			
			###############################
			$arr[38]=(split /\|/,$arr[38])[1];
			my ($CHR,$START,$END)=split /[:-]/,$arr[5];
			if (!$END) {$END=$START};
			push @results,@arr[3..4],$CHR,$START,$END,@arr[6..40];
			##########################$score,$conclusion,$depend,$totvalue;
			push @{$add_new{$muttag}{$omimid}},@arr[41..46],$dep_dig,$denovo_dig,$heter_dig,$true_genetic,$arr[47],"NA";

			next if((exists $gene_filter{ALL}{$arr[3]}) || (exists $gene_filter{VAR}{$arr[3]}));############################出报告那一步，把HLA基因的突变过滤掉！20160901

			$resultdata{$muttag}{$omimid}=\@results;

			$gene_choice{$muttag}{$omimid}=1;
			if ((exists $panel_gene{OK}) && (not exists $panel_gene{$arr[3]}))
			{
					delete $gene_choice{$muttag}{$omimid};
			};
			if ((exists $gene_list{OK}) && (not exists $gene_list{$arr[3]}))
			{
					delete $gene_choice{$muttag}{$omimid};
			};
		}else
		{
			$arr[13]=~s/\(exon.*?\)//g;
			if (not exists $rmdepth{$muttag}{yanzh})
			{
				if($results[0]=~/_1_/)
				{
					$rmdepth{$muttag}{yanzh}="NA";
				}else
				{
					print STDERR "\n\t $muttag\n\n";
					die;
				};
			};

			next if($denovo_dig==1 && $arr[5]!~/YES/);

			push @results,@arr[6..$#arr],$dep_dig,$denovo_dig,$heter_dig,$true_genetic,$arr[11],$rmdepth{$muttag}{yanzh};

			next if((exists $gene_filter{ALL}{$arr[6]}) || (exists $gene_filter{EXON}{$arr[6]}));############################出报告那一步，把HLA基因的突变过滤掉！20160901

			$resultdata{$muttag}{$omimid}=\@results;

			$gene_choice{$muttag}{$omimid}=1;
			if ((exists $panel_gene{OK}) && (not exists $panel_gene{$arr[6]}))
			{
					delete $gene_choice{$muttag}{$omimid};
			};
			if ((exists $gene_list{OK}) && (not exists $gene_list{$arr[6]}))
			{
					delete $gene_choice{$muttag}{$omimid};
			};
			if($results[0]=~/_1_/)
			{
				$gene_choice{$muttag}{$omimid}=1;
			};
		};


		CASE_last:;
	};
};
######################################################################################

print "get ACMG value and gene high expression...\n";
my $cds="$parameters{T3}/G_RNA_expre_database/last_cds_and_50bp_nm.txt";
my $pm1="$parameters{T3}/G_RNA_expre_database/PM1.site";
my (%acmg11,%disease_hot,%MQ);
&standard_family::get_ACMG(\@bestNM,$cds,$pm1,\%mut_genetic,\%acmg11,\%disease_hot,\%MQ,\@sampname);

foreach my $KEY (sort keys %resultdata)
{
	foreach my $omimid (sort keys %{$resultdata{$KEY}}) 
	{
#		next if ($KEY!~/89052957/);
		my @results=@{$resultdata{$KEY}{$omimid}};

		if ($results[0]=~/loss|gain/)
		{
		}else
		{
			my @relys;
			if (exists $acmg11{$KEY}{$omimid})
			{
				push @relys,@{$acmg11{$KEY}{$omimid}};
			};
			if (exists $acmgfam{$KEY}{$omimid})
			{
				push @relys,@{$acmgfam{$KEY}{$omimid}};
			};
			my ($comYES,$comNO,$match,$reaYES,$reaNO)=("NA","NA","NA","NA","NA");
			&standard_family::get_acmg_result(\@relys,\$comYES,\$comNO,\$match,\$reaYES,\$reaNO);

			if (exists $disease_hot{$KEY})
			{
				push @results,$comYES,$comNO,$match,$reaYES,$reaNO,@{$disease_hot{$KEY}};		###########by lzw 20160707 =添加疾病热点信息
			}else
			{
				print STDERR "\t\tno_disease_hot\t$KEY\n";
				die;
			};
			my @tmp_added=@{$add_new{$KEY}{$omimid}};
			&standard_family::revese_cons_whx($results[-2],$results[-1],\$tmp_added[4]);
			push @results,@tmp_added;
		};

		if (exists $translation{$results[0]})
		{
			$results[0]=$translation{$results[0]};
		}else
		{
			print STDERR "no_mutation_tag:$results[0]\n";
			die;
		};
		foreach my $bef_eff (@results)
		{
			$bef_eff=&standard_family::get_effec_num($bef_eff);
		};
#		$results[0]=`echo \'$results[0]\'|md5sum |cut -d \' \' -f 1`;chomp $results[0];

		print ALL (join "\t",@results)."\n" if($level==5);
		if (exists $gene_choice{$KEY}{$omimid})
		{
			print OUT1 (join "\t",@results)."\n";
		};
	};
};
################################################
if ($bam=~/yes/i && exists $SMN1_com{$sampname[0]})
{	
	foreach my $A (sort @{$SMN1_com{$sampname[0]}})
	{
		my @results=@{$A};
	#	$results[0]=`echo \'$results[0]\'|md5sum |cut -d \' \' -f 1`;chomp $results[0];
		next if(exists $panel_gene{OK} && not exists $panel_gene{SMN1});
		if (exists $translation{$results[0]})
		{
			$results[0]=$translation{$results[0]};
		}else
		{
			print STDERR "no_mutation_tag:$results[0]\n";
			die;
		};

		print OUT1 (join "\t",@results)."\n";
		print ALL (join "\t",@results)."\n" if($level==5);
	};
};
close OUT1;

if($level==5)
{
	close ALL;
};
################################################
######################
###&input($level,\@indir,\@infile,\@bam,\@rbam,\@genecov,\@rmgenecov,\@rmdepthfile,\@sampname,\@bestNM,\@chr_cnv_res,\@exon_cnv_res);
my @chr_cnv;

##########暂时关闭，20161024

&get_chr_cnv(\@sampname,\@cnvhead,\@chr_cnv_res,\@exon_cnv_res,\@chr_cnv);


if (@chr_cnv > 1)
{
	open OUT3, ">$out\.CNV" or die;
	my @head=split /\t/,(shift @chr_cnv);
	print OUT3 (join "\t",@head)."\n";

	foreach my $res (@chr_cnv)
	{
		my @results=split /\t/,$res;
		print OUT3 (join "\t",@results)."\n";
	};
	close OUT3;
};

########################################################
######################################################################$geneinf->{$$sampname[$i]}{$arr[0]}{'cov'}=$arr[1];
foreach my $gene (sort keys %geneinf)
{
	my @results;
	next if ((not exists $geneinf{$gene}{$sampname[0]}{'cov'}) || (not exists $geneinf{$gene}{$sampname[0]}{'dep'}));

	if (exists $panel_gene{OK})
	{
		next if (not exists $panel_gene{$gene});		###############gene 过滤
	};
        if (exists $gene_list{OK})
        {
                next if (not exists $gene_list{$gene});
        };

	push @results,$gene;
	for (my $i=0;$i<@all_sam ;$i++)
	{
		my $gene_mut=0;
		if (exists $gene_mut{$gene}{$all_sam[$i]})
		{
			$gene_mut=keys %{$gene_mut{$gene}{$all_sam[$i]}};
		};
		foreach (($geneinf{$gene}{$all_sam[$i]}{'cov'},$geneinf{$gene}{$all_sam[$i]}{'dep'},$geneinf{$gene}{$all_sam[$i]}{'cov10X'}))
		{
			if (!defined $_)
			{
				$_="0";
#				print STDERR "gene_inf:$gene\n";
			}elsif ($_=~/\./)
			{
				$_=sprintf("%.2f",$_);
			};
		};
		push @results,$geneinf{$gene}{$all_sam[$i]}{'cov'},$geneinf{$gene}{$all_sam[$i]}{'dep'},$geneinf{$gene}{$all_sam[$i]}{'cov10X'},$gene_mut;
	};
	push @results,"是";
	print OUT2 (join "\t",@results)."\n";
};
close OUT2;

my $convert=$parameters{S7};
if (-f "$out\.Mutation" && -f "$out\.CNV" && -f "$out\.Quality")
{
##      `$convert -i "$od/filter_result.txt" "$od/cnv.txt" "$od/QC.txt" -code utf-8 -n Mutation CNV Quality -null -o $out`;
	`$convert -i "$out\.Mutation" "$out\.Quality" -code utf-8 -n Mutation Quality -null -o $out`;
}elsif(-f "$out\.Mutation"  && -f "$out\.Quality")
{
	`$convert -i "$out\.Mutation" "$out\.Quality" -code utf-8 -n Mutation Quality -null -o $out`;
}else
{
	print STDERR "ERR:\tplease_the_results !\n";
};

#`ln -s $out\.Mutation_allgene /share/nas01-5/zhaoery/jobs/Cluster_For_Web/family_result_link/ `;

print "done...\n\n";

###############################################################subs
###############################################################
sub Format_1{			###################&Format_1($xls);
	my $format1 = $_[0]->add_format();					########for header
	$format1->set_font('Times New Roman');
	$format1->set_bold();
	$format1->set_size('9');
	$format1->set_align('center');
	return $format1;
};

sub Format_2{
	my $format2 = $_[0]->add_format(); 
	$format2->set_font('Times New Roman');
	$format2->set_size('9');
	$format2->set_align('center');
	return $format2;
};

sub path{
	my $cur_dir=`pwd`;
	chomp($cur_dir);
	my ($in)=@_;
	my $return="";
	if(-f $in){
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;chomp $dir;
		$return="$dir/$file";
	}elsif(-d $in){
		chdir $in;$return=`pwd`;chomp $return;
	}else{
		warn "Warning just for file and dir:$in\n";
		exit;
	}
	chdir $cur_dir;
	return $return;
};

sub input	##&input($level,\@indir,\@infile,\@bam,\@rbam,\@genecov,\@rmgenecov,\@rmdepthfile,\@sampname,\@bestNM,\@chr_cnv_res,\@exon_cnv_res);
{
	my ($level,$input,$file,$bam,$rbam,$genecov,$rmgene_cov,$rmdepfile,$name,$bestnm,$chr_cnv,$exon_cnv)=@_;
	for (my $i=0;$i<@{$input} ;$i++)
	{
		my $indir;
		if (-d $$input[$i])
		{
			$indir=&path($$input[$i]);
		}elsif($file && -f $$file[$i])
		{
			$$file[$i]=&path($$file[$i]);
		}else
		{
			print STDERR "\n\tplease check your inputs !\t$$input[$i]\n";exit;
		};
		if($indir)
		{
			$$input[$i]=$indir;
			if (!$file || (! $$file[$i]) || ($$file[$i] && !-f $$file[$i]))
			{
				$$file[$i]="$indir/3.3_variation_annotation/tot_3_level.report.txt" if($level==3);
				$$file[$i]="$indir/3.3_variation_annotation/tot_5_level.report.txt" if($level==5);
			};
			$$bam[$i]="$indir/1.2_Merged_bam/sum_merged.bam";
			$$rbam[$i]="$indir/1.2_Merged_bam/sum_merged.rmdup.bam";
			$$genecov[$i]="$indir/2.3_function_region_map_stat/gene_coverage_depth.txt";
			$$rmgene_cov[$i]="$indir/2.3_function_region_map_stat/gene_coverage_depth_rmdup.txt";
			$$rmdepfile[$i]="$indir/2.2_rmdup_map_stat/bed_depth.txt";
				my $tmp=basename($indir);
			$$name[$i]=(split /[-_.]/,$tmp)[0];
			$$bestnm[$i]="$indir/3.3_variation_annotation/snp_filter.FiveMAF.dbSNP.disease.SiftSplice.classfication.genetictype.rmdepth.bestNM.Aadd_dis_path";
			$$chr_cnv[$i]="$indir/5.2_EXON_deletion/chr_UPD.txt.anno";
			$$exon_cnv[$i]="$indir/5.3_Batch_EXON_deletion/positive_cnv_region_exon_reliable_anno";
		}else
		{
			print STDERR "\n\tplease check your inputs !\t$$input[$i]\n";exit;
		};
	};
};

sub get_chr_cnv
{
	my ($name,$add_head,$chrcnv,$exoncnv,$arr)=@_;
	##################
	my $true=0;
	my %hash;
	for (my $i=1;$i<@{$name};$i++)
	{
		open K,"$$chrcnv[$i]" or next;
		++$true;
		<K>;
		while (<K>)
		{
			chomp;
			next if (/^$/);
			my @arr=split /\t/,$_;
			$hash{$arr[2]}{$$name[$i]}=$arr[8];
		};
		close K;
	};
	++$true;
	##################
	if (@{$name}==$true)
	{
		open L,"$$chrcnv[0]" or next;
		my $head=<L>;
		chomp $head;
		my @HEAD=split /\t/,$head;
		splice(@HEAD,8,1,@{$add_head});
		push @{$arr},(join "\t",@HEAD);
		while (<L>)
		{
			chomp;
			next if (/^$/);
			my @arr=split /\t/,$_;
			my @tmp_cnv;
			for (my $i=1;$i<@{$name} ;$i++)
			{
				if (exists $hash{$arr[2]}{$$name[$i]})
				{
					push @tmp_cnv,$hash{$arr[2]}{$$name[$i]};
				}else
				{
					push @tmp_cnv,"野生型";
				};
			};
			splice(@arr,9,0,@tmp_cnv);
			push @{$arr},(join "\t",@arr);
		};
		close L;
	}else
	{
			###################说明有样本整倍体没有分析
		#print STDERR "\t\tAttention:\tthe chr deletion analysis of some samples were incomplete !\n";
	};
};

sub get_similar_tag
{
	my($pro_tag,$comp_tag,$return)=@_;
	if ($comp_tag=~/$pro_tag/)
	{
		$return=$pro_tag;
	}else
	{
		$comp_tag=~s/单/双/g;
		$comp_tag=~s/双/单/g;
		$comp_tag=~s/杂/纯/g;
		$comp_tag=~s/纯/杂/g;
		if ($comp_tag=~/$pro_tag/)
		{
			$pro_tag=~s/单/双/g;
			$pro_tag=~s/双/单/g;
			$pro_tag=~s/杂/纯/g;
			$pro_tag=~s/纯/杂/g;
			$return=$pro_tag;
		}else
		{
			$comp_tag=~s/单/双/g;
			$comp_tag=~s/双/单/g;
			$comp_tag=~s/杂/纯/g;
			$comp_tag=~s/纯/杂/g;
			return (split /\;/,$comp_tag)[0];
		};
	};
};
##########################################################################
sub chr_convert
{
	my $chr=(split /0{4,5}|\./,$_[0])[1];
	if ($chr eq '23') {$chr='X'}
	elsif($chr eq '24'){$chr='Y'};
	return "chr$chr";
};
###############################################################################################
sub get_uniq
{
	my @TMP=@_;
	my (%uniq,@tmp);
	foreach my $A (@TMP)
	{
		if (not exists $uniq{$A})
		{
			push @tmp,$A;
			$uniq{$A}=1;
		};
	};
	return @tmp;
};
#######################
sub get_real_relation	#########($sons[0],\%rmdepth);
{
	my ($name,$hash,$out)=@_;
	my %all;
	foreach my $mut (sort keys %{$hash})
	{
		next if($mut=~/^X|^Y|loss|gain/);
		my $tag=0;
		for(my $i=0;$i<@{$name};$i++)
		{
			next if(not exists $hash->{$mut}{$$name[$i]});
			next if($hash->{$mut}{$$name[$i]}=~/gain|loss/);
			if ($i==0)
			{
				my($ratio,$mut_dep,$tot)=split /[=\/]/,$hash->{$mut}{$$name[$i]};
				if ($hash->{$mut}{$$name[$i]}=~/NA/)
				{
					($ratio,$mut_dep,$tot)=(0,0,0);
				};
				if ($ratio >= 0.3 && $tot>=5)
				{
					$all{$$name[$i]}{tot}+=1;
					$tag=1;
				};
			}elsif($tag==1)
			{
				my ($ratio,$mut_dep,$tot)=split /[=\/]/,$hash->{$mut}{$$name[$i]};
				if ($hash->{$mut}{$$name[$i]}=~/NA/)
				{
					($ratio,$mut_dep,$tot)=(0,0,0);
				};
				if ($tot >= 5)
				{
					$all{$$name[$i]}{Y}+=1;
				};
				if ($tot >=5 && $mut_dep >0)
				{
					$all{$$name[$i]}{YY}+=1;
				};
			};
		};
	};
	#######################
	open L,">$out" or die;
	for (my $i=1;$i<@{$name} ;$i++)
	{
		my $cover_loc=$all{$$name[$i]}{Y}/$all{$$name[0]}{tot};$cover_loc=sprintf("%.2f",$cover_loc);
		my $common_rat=$all{$$name[$i]}{YY}/$all{$$name[$i]}{Y};$common_rat=sprintf("%.2f",$common_rat);
		print L "\t$$name[0]\-$$name[$i]\n";
		print L "\tCover_mut\t$cover_loc\=$all{$$name[$i]}{Y}\/$all{$$name[0]}{tot}\n";
		print L "\tComman_mut\t$common_rat\=$all{$$name[$i]}{YY}\/$all{$$name[$i]}{Y}\n";
	};
	close L;
};
sub initialize
{
        my ($file,$hash)=@_;
        open K,"$file" or die;
        while (<K>)
        {
                chomp;
                next if (/^$/ || /^\#/);
                my @arr=split /\t/,$_;
                if (!defined $arr[2])
                {
                        $hash->{$arr[0]}=$arr[1];
                }else
                {
                        $arr[2]=~s/\#//g;
                        $hash->{$arr[0]}="$arr[1] $arr[2]";
                };
        };
        close K;
};
############

sub get_list_gene
{
	my ($file,$hash)=@_;
	open L,"$file" or die;
	while (<L>)
	{
		chomp;
		next if (/^$|^\#/);
		my @arr=split /\t/,$_;
		if ($arr[0]=~/EXON|VAR|ALL/)
		{
			$hash->{$arr[0]}{$arr[1]}=1;
		}else
		{
			$hash->{$arr[0]}=1;
		};
	};
	close L;
};

