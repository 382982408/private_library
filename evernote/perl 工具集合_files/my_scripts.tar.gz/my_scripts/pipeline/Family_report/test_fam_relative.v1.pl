#!/usr/bin/perl -w

=head1 Usage

  perl test_fam_relative.v1.pl <control_sample_dir>  <sample_dir> <out_dir>

=cut
use strict;
use Cwd;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

my $control=shift;
my $compare=shift;
my $od=shift;
die `pod2text $0`if(!defined $control || !defined $compare || !defined $od);


my @all_sam;
my %rmdepth;
&get_mutation($control,\@all_sam,\%rmdepth);
&get_mutation($compare,\@all_sam,\%rmdepth);

#print Dumper \@all_sam;
#print Dumper \%rmdepth;
#die;

my $out=(join "_",@all_sam)."_relation";

&get_real_relation(\@all_sam,\%rmdepth,$out);

sub get_mutation
{
	my ($dir,$sam,$rmdepth)=@_;
	my $name=basename $dir;
	($name)=split /\D+/,$name;
	push @{$sam},$name;
	open L,"$dir/3.3_variation_annotation/tot_5_level.report.txt" or die;
	<L>;
	while (<L>)
	{
		chomp;
		next if(/^$/);
		my @arr=split /\t/,$_;
		my $key=&get_mut_compile($arr[4],$arr[6],$arr[1]);
		my ($muttot2,$mutdep3,$mutrat4,$aftmuttot39,$aftmutdep40,$aftmutrat41,$hete11,$hetechina);
	        if ($arr[22]=~/(.*)\:(.*)\=(.*)\/(.*);(.*)\=(.*)\/(.*)/)
	         {
                	 $hete11=$1;
        	         $muttot2=$4;
	                 $mutdep3=$3;
                	 $mutrat4=$2;
        	         $aftmuttot39=$7;
	                 $aftmutdep40=$6;
        	         $aftmutrat41=$5;
	         };
		$rmdepth->{$key}{$name}="$aftmutrat41\=$aftmutdep40\/$aftmuttot39";
	};
	close L;
};

sub chr_convert
{
        my $chr=(split /0{4,5}|\./,$_[0])[1];
        if ($chr eq '23') {$chr='X'}
        elsif($chr eq '24'){$chr='Y'};
        return "chr$chr";
};

sub get_mut_compile
{
        my ($g_pos,$c_pos,$gene_inf)=@_;
        my ($gene6,$genefx7)=(split /\|/,$gene_inf);

        my @tmp_chr=split /[:-]/,$g_pos;
        if ($tmp_chr[0]=~/NC/)
        {
                $tmp_chr[0]=&chr_convert($tmp_chr[0]);
        };
        if (!$tmp_chr[2])
        {
                $tmp_chr[2]=$tmp_chr[1];
        };
        my $mut="err";
        my @c=split /[:;]/,$c_pos;
        foreach my $pos (@c)
        {
                next if($pos !~/c\./);
                if ($pos=~/.*([ATCG])\>([ATCG]).*/)
                {
                        my $bef=$1;my $aft=$2;
                        if ($genefx7=~/-/)
                        {
                                $bef=~tr/ATCG/TAGC/;$bef=reverse $bef;
                                $aft=~tr/ATCG/TAGC/;$aft=reverse $aft;
                        };
                        $mut="$bef\_$aft\_S";
                }elsif($pos=~/.*del([ATCG]+)ins([ATCG]+)$/)
                {
                        my $bef=$1;my $aft=$2;
                        if ($genefx7=~/-/)
                        {
                                $bef=~tr/ATCG/TAGC/;$bef=reverse $bef;
                                $aft=~tr/ATCG/TAGC/;$aft=reverse $aft;
                        };
                        $mut="$bef\_$aft\_D";
                }elsif($pos=~/.*del([ATCG]+)$/)
                {
                        my $aft=$1;
                        if ($genefx7=~/-/)
                        {
                                $aft=~tr/ATCG/TAGC/;$aft=reverse $aft;
                        };
                        $mut="$aft\_\-\_D";
                }elsif($pos=~/.*ins([ATCG]+)$/)
                {
                        my $aft=$1;
                        if ($genefx7=~/-/)
                        {
                                $aft=~tr/ATCG/TAGC/;$aft=reverse $aft;
                        };
                        $mut="\-\_$aft\_D";
                }else
                {
                        next;
                };
        };
        return (join "_",@tmp_chr,$mut);
};


sub get_real_relation
{
        my ($name,$hash,$out)=@_;
        my %all;
        foreach my $mut (sort keys %{$hash})
        {
                next if($mut=~/^X|^Y|loss|gain/);
                my $tag=0;
                for(my $i=0;$i<@{$name};$i++)
                {
			next if(not exists $hash->{$mut}{$$name[0]});
#                        next if(not exists $hash->{$mut}{$$name[$i]});
                        next if(exists $hash->{$mut}{$$name[$i]} && $hash->{$mut}{$$name[$i]}=~/gain|loss/);
                        if ($i==0)
                        {
                                my($ratio,$mut_dep,$tot)=split /[=\/]/,$hash->{$mut}{$$name[$i]};
                                if ($ratio >= 0.3 && $tot>=5)
                                {
                                        $all{$$name[$i]}{tot}+=1;
                                        $tag=1;
                                };
                        }elsif($tag==1)
                        {
				my ($ratio,$mut_dep,$tot);
 				if(not exists $hash->{$mut}{$$name[$i]})
				{
					($ratio,$mut_dep,$tot)=(0,0,10);
				}else
				{	
					($ratio,$mut_dep,$tot)=split /[=\/]/,$hash->{$mut}{$$name[$i]};
				};
                                if ($tot >= 5)
                                {
                                        $all{$$name[$i]}{Y}+=1;
                                };
                                if ($tot >=5 && $mut_dep >0)
                                {
                                        $all{$$name[$i]}{YY}+=1;
                                };
                        };
                };
        };
        open L,">$out" or die;
        for (my $i=1;$i<@{$name} ;$i++)
        {
                my $cover_loc=$all{$$name[$i]}{Y}/$all{$$name[0]}{tot};$cover_loc=sprintf("%.2f",$cover_loc);
                my $common_rat=$all{$$name[$i]}{YY}/$all{$$name[$i]}{Y};$common_rat=sprintf("%.2f",$common_rat);
                print L "\t$$name[0]\-$$name[$i]\n";
                print L "\tCover_mut\t$cover_loc\=$all{$$name[$i]}{Y}\/$all{$$name[0]}{tot}\n";
                print L "\tComman_mut\t$common_rat\=$all{$$name[$i]}{YY}\/$all{$$name[$i]}{Y}\n";
        };
        close L;
};

