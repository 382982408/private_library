#!/usr/bin/perl -w
use strict;
use Cwd;
use Getopt::Long;
use Data::Dumper;
use Spreadsheet::WriteExcel;
use Excel::Writer::XLSX;
use Spreadsheet::ParseExcel;
use File::Basename qw(basename dirname);
use lib "/share/nas1/luozw/bin/9.0_models/";
use exon;
###########################################################################Start_Time
my ($list,$od);
my $level=3;

GetOptions
(
	"list=s"	=>	\$list,
	"level=s"	=>	\$level,
	"od=s"	=>	\$od,
);
if (!$list || !$od)
{
	print "\n\tperl $0 -list <sample_list> -level <3|5> -od <out_dir>\n\n";exit;
};
if (!-d $od){`mkdir -p $od`};
$od=&exon::path($od);

`mkdir -p $od/Reports`;

open K,"$list" or die;
open L,">$od/sample_info.txt" or die;
open M,">$od/get_sample_report.sh" or die;
open N,">$od/sample_info.txt.err" or die;

while (<K>)
{
	chomp;
	next if ($_!~/^\d+/);
#	next if ($_!~/25907/);
#	print "BBB\n$_\n";die;
#	my $A=substr($_,0,5);
	my ($A)=split /\D+/,$_;
	my $OUT=&exon::get_fam_relative($A);
	if (!$OUT)
	{
		print STDERR "No_realname:\t$A\n";
		my $outsh=&exon::get_report_sh($A,$level,$od);
		if ($outsh ne 'NA')
		{
			print M "$outsh";
		}else
		{
			print N "NO_runsh:\t$A\n";
		};
	}else
	{
		print L "$OUT";
		my @tmp=split /\n/,$OUT;
		foreach my $BB (@tmp)
		{
			my ($CC)=split /\D+/,$BB;
			my $outsh=&exon::get_report_sh($CC,$level,$od);
			if ($outsh ne 'NA')
			{
				print M "$outsh";
			}else
			{
				print N "NO_runsh:\t$CC\n";
			};
		};
	};
};
close K;
close L;
close M;
close N;

foreach my $file ("$od/sample_info.txt","$od/get_sample_report.sh","$od/sample_info.txt.err")
{
	`mv $file $file\.bak && sort -u $file\.bak >$file && rm $file\.bak`;
};