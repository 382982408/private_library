#!/usr/bin/perl -w
=head1 Usage

	perl get_family_genetic_score.v1.pl
	-if		fam_info_config		eg:8AD102_handle.txt
	-father		mother_id		eg:/share/ofs1a/prod/sample/8AD000-8AD999/8AD102_NQB2_NT01T_b2591
	-mother		father_id		eg:/share/ofs1a/prod/sample/8AD000-8AD999/8AD103_NQB2_NT01T_b2591
	-od		outdir			eg:xx_od/
	-DD		out_report_name
	-other		other_id
=cut;
use strict;
use File::Basename;
use Getopt::Long;
use FindBin qw($Bin $Script);
use Data::Dumper;
use lib "$Bin/../pipeline/models/";
use exon;
######################################################
my %parameters;
my $file="$Bin/../db/Z_lzw_database/CONFIG_ALL.txt";
&exon::initialize($file,\%parameters);
my $get_vcf_pl="$Bin/../pipeline//Bin/get_family_group_depth.v1.pl";
my $get_table_pl="$Bin/../pipeline//Bin/3.1.1.get_vcf_depth.v1.pl";
my $Convert2Excel="$Bin/../bin/Convert2Excel";

############################
my ($relation_file,$fatherid,$motherid,$od,$look_dog,$DD,@other);
GetOptions
(
	"if=s"=>\$relation_file,
	"father=s"=>\$fatherid,
	"mother=s"=>\$motherid,
	"od=s"=>\$od,
	"DD=s"=>\$DD,
	"l=s"=>\$look_dog,
	"other=s{,}"=>\@other,
);
die `pod2text $0` if(!defined $relation_file || !defined $fatherid || !defined $motherid || !defined $od || !defined $DD || @other<1);

if($fatherid!~/NQB2|NQB3/ ||  $motherid!~/NQB2|NQB3/)
{
#	print STDERR "error:please check whether the program is NQB2 !!!!\n";
#	die;
};
#################################################################
if (!-d $od)
{
	`mkdir -p $od`;
};
$od=`readlink -f $od`;chomp $od;
$relation_file=`readlink -f $relation_file`;chomp $relation_file;
if(`readlink -f $fatherid` !~ /^$/)
{
	$fatherid=`readlink -f $fatherid`;chomp $fatherid;
};
if(`readlink -f $motherid` !~ /^$/)
{
	$motherid=`readlink -f $motherid`;chomp $motherid;
}
for (my $i=0;$i<@other ;$i++)
{
	if(`readlink -f $other[$i]` !~ /^$/)
	{
		$other[$i]=`readlink -f $other[$i]`;chomp $other[$i];
	};
};
#################################################################

my @id;
push @id,$fatherid,$motherid,@other;
print Dumper \@id;
my $sge_only=&exon::dir_sge_check(@id);

my $other=join " ",@other;
my $cmd_perl="perl $0 -if $relation_file -father $fatherid -mother $motherid -od $od -l look_dog -DD $DD -other $other ";
if (! defined $look_dog)
{
	if ($sge_only=~/yes/)
	{
		print STDOUT "sge:\t\tall samples in single one sge($sge_only)\n";
	}else
	{
		print STDOUT "ssh $parameters{sge_all} \'$cmd_perl\'";
		system "ssh $parameters{sge_all} \'$cmd_perl\'";
		exit;
	};
}else
{
	########顺利往下运行
};

#######################################
print STDOUT "work start ...\n";
########################################



my $conf_file="$fatherid/conf.txt";
&exon::initialize($conf_file,\%parameters);

my ($proband,$program,$chip_bed)=split /\_/,$parameters{sample_id};
my $DD_number;
if (exists $parameters{DD_number})
{
	$DD_number=$parameters{DD_number};
};
if(defined $DD)
{
	$DD_number=$DD;
};

########################################

print "read family relationships...\n";
my %relation;
&read_sinfo($relation_file,\%relation);
print Dumper \%relation;

my @samples =sort keys %relation;
print Dumper \@samples;

my (@father,@mother);
push @father,(split /xb|sl|zj|xj|\_|\s+/,basename($fatherid))[0];
push @mother,(split /xb|sl|zj|xj|\_|\s+/,basename($motherid))[0];

if ((@mother==1) && (@father==1))
{
		print "one father + one mother !!!!\n";
}else
{
		print "one father + one mother + other !!!! \n";
		die;
};
my (@all);
push @all,@father,@mother;

if (!defined $DD_number)
{
	$DD_number=$all[0];
};
################################################################# 
###########################################获得家系vcf

my $get_vcf_sh="perl $get_vcf_pl $relation_file $fatherid/conf.txt $od/${DD_number}_fam.vcf &\nwait\nperl $get_table_pl $od/${DD_number}_fam.vcf $fatherid/conf.txt $od/${DD_number}_fam.vcf_table\n";
&exon::write_out("$od/${DD_number}_fam.vcf.sh",$get_vcf_sh);

my %depth;
if (-f "$od/${DD_number}_fam.vcf_table")
{
	print STDOUT "file_exists:$od/${DD_number}_fam.vcf_table !\n";
	&read_table_depth("$od/${DD_number}_fam.vcf_table",\%depth);
}else
{
	print STDOUT "sh $od/${DD_number}_fam.vcf.sh ...\n";
	`sh $od/${DD_number}_fam.vcf.sh`;
	&read_table_depth("$od/${DD_number}_fam.vcf_table",\%depth);
};

############################################提取信息：每个突变，在父亲和母亲上的深度信息，生物学意义分级
my (%mut_info,%report,$report_head,%fenjilt4,%gene);

my $time=0;
foreach my $i (0..@id-1)
{
	my $dir=$id[$i];
	my $proband_report=(glob "$dir/$parameters{DIR10}/*_tot_5_level.report.txt_all.txt")[0];
	next if (!defined $proband_report);
	print STDOUT "report_file:$proband_report !\n";

	open L,"$proband_report" or die "error:can not open file: $proband_report!!!\n\n";
	my $head=<L>;
	chomp $head;
	if(!$report_head)
	{
		my @head_temp=split/\t/,$head;
		$report_head=join"\t",@head_temp[11..@head_temp-1];
	};
	while (<L>)
	{
		chomp;
		next if (/^$/ || /^\#/);
		my @arr=split /\t/,$_;
		next if($arr[67]!~/\>/);
		next if($arr[-1]=~/Reason/);		###除了野生型，该过滤的还得过滤

		my $gene=$arr[11];
		my $fenji=$arr[6];
		my $omim=$arr[42];
		my $yichun=$arr[66];
		my $NM=$arr[46];
		$arr[39]="NA";			###########与疾病相关性	此列为空
		$arr[40]="NA";			##########相关性说明	此列为空
		$arr[48]="非阳性";		##########疑似阳性/非阳性	此列事先定义为非阳性
		$arr[63]="NA";			###########是否共分离	此列为空
		$arr[64]="NA";			########是否denovo		此列为空
		$arr[65]="NA";			####是否复合杂合	此列为空


		next if($fenji>3);

		my ($ref,$alt)=split/\>/,$arr[67];
		$ref=~s/null/-/g;
		$alt=~s/null/-/g;

		my $mut="$arr[13]\_$arr[14]\_$arr[15]\_$ref\_$alt";

		$fenjilt4{"$mut\t$gene\t$NM\t$omim"}=$fenji;		#########为了将<4级的点不输出

		if(not exists $report{"$mut\t$gene\t$NM\t$omim"}{value})
		{
			$report{"$mut\t$gene\t$NM\t$omim"}{value}=join"\t",@arr[11..@arr-1]; ###########存储从基因那一列往后的内容
		};
		$report{"$mut\t$gene\t$NM\t$omim"}{muttag}=$arr[0];
		$mut_info{"$mut\t$gene\t$NM\t$omim"}{gene}=$gene;
		$mut_info{"$mut\t$gene\t$NM\t$omim"}{omim}=$omim;
		$mut_info{"$mut\t$gene\t$NM\t$omim"}{AD}=$yichun;
		$mut_info{"$mut\t$gene\t$NM\t$omim"}{NM}=$NM;
		$mut_info{"$mut\t$gene\t$NM\t$omim"}{fj}=$fenji;

		########################################
	};
	close L;
};
############################################################################################
######输出第一个文件：all_mut_depth.txt  
##one_key,gene,NM,omim,AD,depth_father,depth_mother,fenji_father|fenji_mother,突变级别；
###########################################################################################
my %fenji;
my $all_dep="$od/${DD_number}_all_mut_depth.txt";
open O,">$all_dep" or die "error:cannot write to file $all_dep!!!\n";
foreach my $key (sort keys %mut_info) 
{
	##########################xxxxxxxxxxxx将>3级别的点不输出
	my ($mut)=split /\t/,$key;
	my @last;
	push @last,$key,$mut_info{$key}{AD};
	
	if(exists $depth{$mut}{$all[0]})
	{
		$depth{$mut}{$all[0]}=~s/Uncov/未覆盖/g;
		$depth{$mut}{$all[0]}=~s/Wild/野生型/g;
		$depth{$mut}{$all[0]}=~s/Homo/纯合/g;
		$depth{$mut}{$all[0]}=~s/Hete/杂合/g;
		$depth{$mut}{$all[0]}=~s/Hemi/半合子/g;
		if ($relation{$all[0]}{sex}=~/FM/)
		{
			if ($mut=~/chrY/)
			{
				$depth{$mut}{$all[0]}="0/0=0;野生型;NA";
			};
		}elsif($relation{$all[0]}{sex}=~/^M/)
		{
			if ($mut=~/chrX|chrY/)
			{
				$depth{$mut}{$all[0]}=~s/纯合|Homo|Hemi/半合子/g;
			};
		}else
		{
			print STDERR "error:sex error:$all[0]\n";
			die;
		};
		push @last,$depth{$mut}{$all[0]};
	}else
	{
		next;
	};
	if(exists $depth{$mut}{$all[1]})
	{
		$depth{$mut}{$all[1]}=~s/Uncov/未覆盖/g;
		$depth{$mut}{$all[1]}=~s/Wild/野生型/g;
		$depth{$mut}{$all[1]}=~s/Homo/纯合/g;
		$depth{$mut}{$all[1]}=~s/Hete/杂合/g;
		$depth{$mut}{$all[1]}=~s/Hemi/半合子/g;
		if ($relation{$all[1]}{sex}=~/FM/)
		{
			if ($mut=~/chrY/)
			{
				$depth{$mut}{$all[1]}="0/0=0;野生型;NA";
			};
		}elsif($relation{$all[1]}{sex}=~/^M/)
		{
			if ($mut=~/chrX|chrY/)
			{
				$depth{$mut}{$all[1]}=~s/纯合|Homo|Hemi/半合子/g;
			};
		}else
		{
			print STDERR "error:sex error:$all[1]\n";
			die;
		};
		push @last,$depth{$mut}{$all[1]};
	}else
	{
		next;
	};
	################

	push @last,"$mut_info{$key}{fj}|$mut_info{$key}{fj}",$mut_info{$key}{fj};

	my $last=join "\t",@last;
	print O "$last\n";
};
close O;

######################################################与遗传有关
#####生成第二个文件：all_mut_genetic.txt 遗传学评分	结论(高中低)	依据（支持致病，可能致病，不支持致病）
######################################################
my $batch_f="A";
if ($fatherid=~/_b(\d+)/)
{
	$batch_f=$1;
};
my $batch_m="A";
if ($motherid=~/_b(\d+)/)
{
	$batch_m=$1;
};

my $genetic="$od/${DD_number}_all_mut_genetic.txt";
my $result="$od/${DD_number}_${program}_b${batch_f}b${batch_m}_unTrios_acmg2.0.txt";
my $result_QC="$od/${DD_number}_${program}_b${batch_f}b${batch_m}_unTrios_acmg2.0.txt_QC";


my %comp_hete=&get_comp_hete($all_dep,\%mut_info,$all[0],$all[1]); #######复合杂合致病性

&get_genetic($all_dep,$genetic,\@all,\%relation,\%comp_hete);

&get_report($genetic,$result,\%report,\@all,$report_head);

&get_QC(\%gene,$result_QC,$fatherid,$motherid,$all[0],$all[1],\%parameters);

`$Convert2Excel -i $result $result_QC -n Mutation Quality -code utf-8 -null -o $result.xlsx`;


print STDOUT "work end ...\n";
#################################################
sub read_table_depth
{
	my ($table,$hash)=@_;
	my @sample;
	open L,"$table" or die "error:can not open file $table !\n";
	while (<L>)
	{
		chomp;
		next if(/^$/);
		if ($_=~/^\#/)
		{
			@sample=(split /\t/,$_)[8,9];
		}else
		{
			my $mut=(split /\t/,$_)[5];
			my @depth=(split /\t/,$_)[8,9];
			if (@sample<2)
			{
				print STDERR "error:file error $table !\n";
				die;
			};
			foreach my $i(0..@depth-1)
			{
				($sample[$i])=split /xb|sl|zj|xj|\_|\s+/,$sample[$i];
				$hash->{$mut}{$sample[$i]}=$depth[$i];
			};
		};
	};
	close L;
};

sub get_comp_hete
{
	my ($in,$mut_info,$father_name,$mother_name)=@_;
	my (%ar_hete,%last,%score);
	##in：onekey,gene,NM,omim,AD,depth_father,depth_mother,突变级别；
	open L,"$in" or die "error:cannot not open file: $in \n\n";
	my $fhzh_content;
	while(<L>)
	{
		chomp;
		next if(/^$|^\#/);
		my @arr=split /\t/,$_;
		my $key=$arr[0];
		my $yichuan=$arr[4];
		my $gene=$arr[1];
		my $father=$arr[5];
		my $mother=$arr[6];
		my $mut_key="$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]";
		if ($yichuan=~/AR/i && $gene!~/SMN1/)
		{
			$ar_hete{$gene}{$key}{"$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]"}{father}=$father;
			$ar_hete{$gene}{$key}{"$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]"}{mother}=$mother;
		};
	};
	close L;
	foreach my $gene (keys %ar_hete)
	{
		if ((keys %{$ar_hete{$gene}}) >= 2)
		{
			foreach my $key11 (sort keys %{$ar_hete{$gene}})
			{
				foreach my $key22 (sort keys %{$ar_hete{$gene}})
				{
					next if ($key11 eq $key22);
					foreach my $only_key11 (sort keys %{$ar_hete{$gene}{$key11}})
					{
						foreach my $only_key22 (sort keys %{$ar_hete{$gene}{$key22}})
						{
							if (($ar_hete{$gene}{$key11}{$only_key11}{father}=~/杂合/) && ($ar_hete{$gene}{$key11}{$only_key11}{mother}=~/野生型/) && ($ar_hete{$gene}{$key22}{$only_key22}{father}=~/野生型/) && ($ar_hete{$gene}{$key22}{$only_key22}{mother}=~/杂合/))
							{
								my $tag="$mut_info->{$only_key11}{fj}+$mut_info->{$only_key22}{fj}";
								$score{$gene}{$only_key11}{$tag}=$only_key22;
							}elsif (($ar_hete{$gene}{$key11}{$only_key11}{father}=~/野生型/) && ($ar_hete{$gene}{$key11}{$only_key11}{mother}=~/杂合/) && ($ar_hete{$gene}{$key22}{$only_key22}{father}=~/杂合/) && ($ar_hete{$gene}{$key22}{$only_key22}{mother}=~/野生型/))
							{
								my $tag="$mut_info->{$only_key22}{fj}+$mut_info->{$only_key11}{fj}";
								$score{$gene}{$only_key11}{$tag}=$only_key22;
							};
						};
					};
				};
			};
		};
	};
	
	foreach my $xgene (sort keys %score)
	{
		foreach my $only_KEY (sort keys %{$score{$xgene}}) 
		{
			my $fenji_score="NA";
			my $fuhezahe_mut="NA";
			foreach my $temp (sort keys %{$score{$xgene}{$only_KEY}}) 
			{
				$fuhezahe_mut=$score{$xgene}{$only_KEY}{$temp};
				$fenji_score=$temp;
				last;
			};
			$fuhezahe_mut=~s/\t/;/g;
			$last{$xgene}{$only_KEY}{mut}=$fuhezahe_mut;
			$last{$xgene}{$only_KEY}{score}=$fenji_score;
		};
	};
	return %last;
};

sub get_QC
{
	my ($gene_mut,$outfile,$id_f,$id_m,$name_f,$name_m,$parameters)=@_;
	my %total;
	my $file_f="$id_f/$parameters->{DIR7}/gene_coverage_depth.txt";
	my $file_m="$id_m/$parameters->{DIR7}/gene_coverage_depth.txt";
	open F1,"$file_f" or die "error:cannot open file $file_f!!!\n";
	while(my $B=<F1>)
	{
		chomp $B;
		next if($B=~/^$/);
		my @arrb=split/\t/,$B;
		$total{$arrb[0]}{$name_f}="$arrb[1]\t$arrb[2]\t$arrb[3]";
	};
	close F1;

	open F2,"$file_m" or die "error:cannot open file $file_m!!!\n";
	while(my $B=<F2>)
	{
		chomp $B;
		next if($B=~/^$/);
		my @arrb=split/\t/,$B;
		$total{$arrb[0]}{$name_m}="$arrb[1]\t$arrb[2]\t$arrb[3]";
	};
	close F2;
	open O,">$outfile" or die"error:cannot write to file $outfile!!!\n";
	print O "基因\t覆盖度(夫正常,$name_f)\t平均深度(夫正常,$name_f)\t基因大于等于10x覆盖度(夫正常,$name_f)\t基因突变数(夫正常,$name_f)\t";
	print O "覆盖度(妻正常,$name_m)\t平均深度(妻正常,$name_m)\t基因大于等于10x覆盖度(妻正常,$name_m)\t基因突变数(妻正常,$name_m)\n";
	foreach my $gene (sort keys %total)
	{
		print O "$gene\t$total{$gene}{$name_f}\t";
		if(exists $gene_mut->{$gene}{$name_f})
		{
			my $sum=keys %{$gene_mut->{$gene}{$name_f}};
			print O "$sum\t";
		}else
		{
			print O "0\t";
		};
		print O "$total{$gene}{$name_m}\t";
		if(exists $gene_mut->{$gene}{$name_m})
		{
			my $sum=keys %{$gene_mut->{$gene}{$name_m}};
			print O "$sum\n";
		}else
		{
			print O "0\n";
		};
		
	};
	close O;
};



sub get_report
{
	my ($in,$out,$hash,$all,$head)=@_;
	open I,"$in" or die "error:cannot open file $in!!!\n";
	open U,">$out" or die "error:cannot write to file $out!!!\n";
	print U "突变编号\t总深度(夫正常,$$all[0])\t突变深度(夫正常,$$all[0])\t突变率(夫正常,$$all[0])\t杂合/纯合(夫正常,$$all[0])\t突变可靠性(夫正常,$$all[0])\t总深度(妻正常,$$all[1])\t突变深度(妻正常,$$all[1])\t突变率(妻正常,$$all[1])\t杂合/纯合(妻正常,$$all[1])\t";
	print U "突变可靠性(妻正常,$$all[1])\t突变级别\t遗传学评分\t结论\t依据\t生物学+遗传学总分\t$head\n";
	while(my $A=<I>)
	{
		chomp $A;
		next if($A=~/^$/);
#		next if($A!~/118972665/);

		my @arr=split/\t/,$A;
		my $key="$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]";
		my @results;

		my ($f_m,$f_t,$f_ratio,$f_type,$f_kekaox)=split/\/|\=|;/,$arr[5];
		my ($m_m,$m_t,$m_ratio,$m_type,$m_kekaox)=split/\/|\=|;/,$arr[6];
		my ($f_j,$m_j)=split/\|/,$arr[7];

		my ($shengwu_score,$yichuan_score,$jielun,$yiju,$total_score,$positive)=($arr[8],$arr[9],$arr[10],$arr[11],$arr[12],$arr[14]);
		if (not exists $hash->{$key}{value})
		{
			print "error:$key\tvalue\n";
			print Dumper \%{$hash};
			die;
		};
		my @value_temp=split/\t/,$hash->{$key}{value};
		$value_temp[37]=$positive;
		$value_temp[-1].=";夫级别:$f_j,妻级别:$m_j;";

		push @results,$hash->{$key}{muttag},$f_t,$f_m,$f_ratio,$f_type,$f_kekaox,$m_t,$m_m,$m_ratio,$m_type,$m_kekaox;
		push @results,$shengwu_score,$yichuan_score,$jielun,$yiju,$total_score,@value_temp;

		foreach my $i (0..@results-1)
		{
			$results[$i]=&exon::get_effec_num($results[$i]);
		};

		my $last_result=join "\t",@results;
		print U "$last_result\n";
	};
	close I;
	close U;
};

sub get_genetic
{
	my ($in,$out,$name,$relation,$comp_hete)=@_;
	my $outcontent;
	open L,"$in" or die"error:can not open file: $in \n\n";
	while(<L>)
	{
		chomp;
		next if(/^$|^\#/);
		my @arr=split /\t/,$_;
		#key,gene,NM,omim,AD,depth_father,depth_mother,f|m,突变级别；
		my $key=$arr[0];
		my $only_key="$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]";
		my $yichuan=$arr[4];
		my $gene=$arr[1];
		my $depth_f=$arr[5];
		my $depth_m=$arr[6];
		my($fenji_f,$fenji_m)=split/\|/,$arr[7];
		my ($value,$jielun,$yiju,$totscore,$fuhezahe,$positive)=("NA","NA","NA","NA","NA","非阳性");

		my $temp_jielun="$fenji_f+$fenji_m";
		if($yichuan=~/AR/ && ($depth_f=~/杂合/ && $depth_m=~/杂合/))
		{
			$value=1;
			$totscore=$value*$fenji_f*$fenji_m;
			$yiju="父亲AR杂合+母亲AR杂合，孩子25%风险为纯合，可能患病";
			$positive="疑似阳性";
		}elsif($yichuan=~/AR/ && (exists $comp_hete->{$gene}{$only_key}{mut}))
		{
			$temp_jielun=$comp_hete->{$gene}{$only_key}{score};
			($fenji_f,$fenji_m)=split/\+/,$temp_jielun;
			$fuhezahe="$comp_hete->{$gene}{$only_key}{mut}";
			$value=1;
			$totscore=$value*$fenji_f*$fenji_m;
			$yiju="父亲AR杂合+母亲AR杂合可能构成复合杂合，孩子25%风险为复合杂合，可能患病";
			$positive="疑似阳性";
		}elsif($yichuan=~/XR|XD/ && $depth_f=~/野生/ && $depth_m=~/杂合/ && $fenji_f<=3 && $fenji_m<=3)
		{
			$value=1;
			$totscore=$value*$fenji_f*$fenji_m;
			if ($yichuan=~/XR/)
			{
				$yiju="父亲X染色体野生，母亲X染色体杂合，所生男孩50%风险为半合子，可能患病；所生女孩50%风险为杂合，XR考虑X染色体失活情况则女孩25%风险可能患病。";
			}elsif($yichuan=~/XD/)
			{
				$yiju="父亲X染色体野生，母亲X染色体杂合，所生男孩50%风险为半合子，可能患病；所生女孩50%风险为杂合，XD考虑X染色体失活情况则女孩25%风险可能患病，不考虑X染色体失活情况则女孩50%风险可能患病。";
			};
			$positive="疑似阳性";
		};
		if ($value eq 1)
		{
			if($temp_jielun=~/1\+1/)
			{
				$jielun="高";
			}elsif($temp_jielun=~/1\+2/ || $temp_jielun=~/1\+3/ || $temp_jielun=~/3\+1/||  $temp_jielun=~/2\+1/)
			{
				$jielun="中";
			}elsif($temp_jielun=~/2\+3/ || $temp_jielun=~/3\+2/ || $temp_jielun=~/2\+2/)
			{
				$jielun="低";
			}else
			{
				($value,$jielun,$yiju,$totscore,$fuhezahe,$positive)=("NA","NA","NA","NA","NA","非阳性");
			};
		};
		$outcontent.="$_\t$value\t$jielun\t$yiju\t$totscore\t$fuhezahe\t$positive\n";
	};
	close L;
	&exon::write_out($out,$outcontent);
};

sub read_sinfo 
{
	my ($info,$hash)=@_;
	open L,"$info" or die;
	while (<L>)
	{
			chomp;
			next if (/^$/);
			my @arr=split /\t+/,$_;
			($arr[0])=split /xb|sl|zj|xj|\s+|\_/,$arr[0];
			$hash->{$arr[0]}{'sex'}=$arr[2];                #######性别
			$hash->{$arr[0]}{'path'}=$arr[9];               #######是否患病
			$hash->{$arr[0]}{'name_ms'}=$arr[6];            #######样本名
			$hash->{$arr[0]}{'status'}=$arr[10];            #######家系关系
	};
	close L;
};
