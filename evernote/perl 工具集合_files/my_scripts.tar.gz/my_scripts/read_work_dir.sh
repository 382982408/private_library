#!/bin/bash


if [[ ! $1 ]]
	then echo -e "\n\t"sh $0 "<inputfile>";
	echo -e "\t\t""<example:format_of_input>"
	echo -e "\t\t"74922xbycn1A
	echo -e "\t\t"75015xbycn1A
	echo -e "\t\t"75257xbycn1A"\n"
	exit;
else
	echo "#input file is ok !!!";
fi;


cat $1|while read a b;
do
	DIR="unknown";
	TWO=$(expr substr $a 1 2);
	DIR=$(readlink -f $(ls -d /share/chg2master/prod/sample/$TWO*/$a*|tail -1));
	if [[ $DIR ]]
		then echo -e $a"\t"$DIR;
	else
		echo -e $a"\t"unknown
	fi;
done;

